@echo off
setlocal
cd /d "%~dp0"
if not defined PYTHON set "PYTHON=python"
"%PYTHON%" -B "support\hydro_cryer_portable_entry_r1.py" "CaseCryerProblem_PR_symc_nu030_Def.xml" %*
set "rc=%ERRORLEVEL%"
if not "%rc%"=="0" if "%~1"=="" pause
exit /b %rc%
