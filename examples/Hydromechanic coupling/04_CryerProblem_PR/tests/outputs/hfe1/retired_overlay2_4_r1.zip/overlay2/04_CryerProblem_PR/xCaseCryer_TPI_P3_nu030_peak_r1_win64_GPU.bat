@echo off
setlocal
cd /d "%~dp0"
if not defined PYTHON set "PYTHON=python"
"%PYTHON%" -B "support\hydro_cryer_portable_entry_r1.py" "CaseCryer_TPI_P3_nu030_peak_r1_Def.xml" %*
set "rc=%ERRORLEVEL%"
if not "%rc%"=="0" if "%~1"=="" pause
exit /b %rc%
