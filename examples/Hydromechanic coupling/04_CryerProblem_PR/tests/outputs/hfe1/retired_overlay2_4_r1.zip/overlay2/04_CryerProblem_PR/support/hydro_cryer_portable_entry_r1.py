"""Run a pinned Cryer portable with its original executable, scripts, seed and receipts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

from hydro_frozen_xml_r1 import restore

HERE = Path(__file__).resolve().parent


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def byte_equal(first, second):
    while True:
        one = first.read(1 << 20)
        if one != second.read(1 << 20):
            return False
        if not one:
            return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("definition")
    parser.add_argument("options", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    options = args.options
    root = HERE.parent
    metadata = json.loads((HERE / "hydro_cryer_archive_map_r1.json").read_text())
    name = args.definition
    spec = metadata[name]
    package = root / spec["archive"]
    active = (root / name).read_bytes()
    # A template is housed in its original portable, whose archive identity is bound before use.
    with package.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    require(digest == spec["sha256"], f"Original package changed: {package}")
    stem = name.removesuffix("_Def.xml")
    legacy_bat = f"x{stem}_win64_GPU.bat"
    allowed = {
        "p3": {"--prepare-only", "--check-only", "--unattended"},
        "seed": {"--prepare-only", "--unattended"},
        "gen": {"--prepare-only", "--smoke", "--unattended"},
    }[spec["mode"]]
    require(set(options) <= allowed, "Unsupported option for the original release.")
    prepare = "--prepare-only" in options or "--check-only" in options
    require(not prepare or len(options) == 1, "Use the preparation option alone.")
    with zipfile.ZipFile(package) as bundle:
        archived = bundle.read(name)
        require(restore(name, archived, active) == archived, "Modern input differs from its frozen release.")
        run_root = root / spec["workspace"]
        if not run_root.exists():
            temporary = Path(tempfile.mkdtemp(prefix="portable_", dir=root))
            try:
                bundle.extractall(temporary)
                temporary.rename(run_root)
            finally:
                # Extraction and concurrent publication are confined to this fresh private directory.
                if temporary.exists():
                    shutil.rmtree(temporary)
        # The old release may reuse this area for peak and full. Never replace an existing file with a fresh copy.
        for item in bundle.infolist():
            if item.is_dir():
                continue
            extracted = run_root / item.filename
            require(extracted.is_file() and extracted.stat().st_size == item.file_size,
                    f"Missing or changed archived component: {item.filename}")
            with bundle.open(item) as expected, extracted.open("rb") as actual:
                require(byte_equal(expected, actual), f"Changed frozen component: {item.filename}")
    print("Original release working directory:", run_root, flush=True)
    if not prepare:
        # All old output, smoke, peak-review, previous-run, and scheduling guards stay with the original BAT.
        return subprocess.call([os.environ["COMSPEC"], "/d", "/c", legacy_bat, *options], cwd=run_root)
    if spec["mode"] == "p3":
        return subprocess.call([os.environ["COMSPEC"], "/d", "/c", legacy_bat, "--check-only"], cwd=run_root)
    out = run_root / "prepare" / stem
    out.mkdir(parents=True, exist_ok=False)
    if spec["mode"] == "seed":
        # This dedicated u-pl executable consumes the frozen seed directly; the old BAT calls no GenCase.
        for extension in (".xml", ".bi4"):
            source = run_root / "support" / "upl_seed_nu030_r1" / (stem + extension)
            shutil.copyfile(source, out / ("Case" + extension))
    else:
        subprocess.run([str(run_root / "support/bin/GenCase_win64.exe"), stem + "_Def",
                        str(out.relative_to(run_root) / "Case"), "-save:all"], cwd=run_root, check=True)
    require(all((out / ("Case" + ext)).is_file() for ext in (".xml", ".bi4")), "Incomplete actual seed")
    print("Input prepared:", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

