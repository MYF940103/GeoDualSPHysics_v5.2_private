//HEAD_DSPH
/*
 <DUALSPHYSICS>  Copyright (c) 2020 by Dr Jose M. Dominguez et al. (see http://dual.sphysics.org/index.php/developers/). 

 EPHYSLAB Environmental Physics Laboratory, Universidade de Vigo, Ourense, Spain.
 School of Mechanical, Aerospace and Civil Engineering, University of Manchester, Manchester, U.K.

 This file is part of DualSPHysics. 

 DualSPHysics is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License 
 as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version.
 
 DualSPHysics is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details. 

 You should have received a copy of the GNU Lesser General Public License along with DualSPHysics. If not, see <http://www.gnu.org/licenses/>. 
*/

//:#############################################################################
//:# Cambios:
//:# =========
//:# - Gestion de excepciones mejorada.  (15-09-2019)
//:#############################################################################

/// \file JSphGpu_ker.h \brief Declares functions and CUDA kernels for the Particle Interaction and System Update.

#ifndef _JSphGpu_ker_
#define _JSphGpu_ker_

#include "DualSphDef.h"
#include "JCellDivDataGpu.h"
#include <cuda_runtime_api.h>

class JLog2;

#define SPHBSIZE 256

/// Structure with constants stored in the constant memory of GPU for the particle interactions.
typedef struct{
  unsigned nbound;
  float massb;              ///<Reference mass of the general boundary particle [kg].
  float massf;              ///<Reference mass of the fluid particle [kg].
  float kernelh;            ///<The smoothing length of SPH kernel [m].
  float kernelsize2;        ///<Maximum interaction distance squared (KernelSize^2).
  float poscellsize;        ///<Size of cells used for coding PosCell (it is usually KernelSize).
  float awen;               ///<Wendland kernel constant (awen) to compute wab.
  float bwen;               ///<Wendland kernel constant (bwen) to compute fac (kernel derivative).
  float cs0;                ///<Speed of sound at the reference density.
  float eta2;               ///<Constant related to H (Eta2=(h*0.1)*(h*0.1)).
  float ddtkh;              ///<Constant for DDT1 & DDT2. DDTkh=DDTValue*KernelSize
  float ddtgz;              ///<Constant for DDT2.        ddtgz=RhopZero*Gravity.z/CteB
  float sdtgz;              ///<Constant for SDT.         sdtgz=RhopZero*Gravity.z
  float k0;                 ///<Constant for SDT.         k0=1-sin(Phi)
  float scell;              ///<Cell size: KernelSize/ScellDiv (KernelSize or KernelSize/2).
  float kernelsize;         ///<Maximum interaction distance between particles (KernelK*KernelH).
  float dp;                 ///<Initial distance between particles [m].
  unsigned strainsoftening; ///<Uses strain-softening DP correction when residual strength parameters are defined. //mdbr
  unsigned artificialstress; ///<Bui 2008 artificial stress for tensile instability (0:none, 1:enabled). //mdbr
  float artificialstresscoef; ///<Coefficient epsilon for Bui 2008 artificial stress. //mdbr
  float artificialstressexp;  ///<Exponent n for Bui 2008 artificial stress kernel ratio. //mdbr
  unsigned soilstressrategradcorr; ///<Applies kernel-gradient correction to stress-rate velocity gradients. //mdbr
  unsigned soildamping;     ///<Bui-Fukagawa damping for static stress initialization (0:none, 1:enabled). //mdbr
  float soildampingcoef;    ///<Non-dimensional Bui-Fukagawa damping coefficient xi. //mdbr
  float cteb;               ///<Constant used in the state equation [Pa].
  float gamma;              ///<Politropic constant for water used in the state equation.
  float rhopzero;           ///<Reference density of the fluid [kg/m3].
  float ovrhopzero;         ///<ovrhopzero=1/RhopZero
  float movlimit;
  unsigned simulate2d;  ///<Indicates a 2-D simulation for correction-matrix inversion. //mdbr
  unsigned symmetry;   //<vs_syymmetry>
  unsigned tboundary;  
  unsigned slipmode;
  unsigned periactive;
  double xperincx,xperincy,xperincz;
  double yperincx,yperincy,yperincz;
  double zperincx,zperincy,zperincz;
  double maprealposminx,maprealposminy,maprealposminz;
  double maprealsizex,maprealsizey,maprealsizez;
  //-Values depending on the assigned domain (can change). | Valores que dependen del dominio asignado (puden cambiar).
  unsigned axis;
  unsigned cellcode;
  double domposminx,domposminy,domposminz;
  //-Ctes. of Cubic Spline kernel.
  float cubic_a1,cubic_a2,cubic_aa,cubic_a24,cubic_c1,cubic_d1,cubic_c2,cubic_odwdeltap;
  //-Ctes for elastic stiffness matrix
  float modulus_E, modulus_K, modulus_G;
  unsigned hydromech;       ///<Hydromechanical u-pw support switch.
  unsigned poremdbcinterp;  ///<mDBC boundary pore-pressure interpolation mode: 0=zero-order, 1=MLS direct.
  unsigned porecompsourcemode; ///<Pore-pressure compression source: 0=pair divergence, 1=density rate.
  unsigned porecompgradcorr; ///<Applies kernel-gradient correction to pore-pressure compression source.
  unsigned poredarcysymcorr; ///<Optional symmetric soil-soil Darcy correction; zero keeps receiver correction.
  unsigned hydrotoploadmode; ///<Hydromechanical top-load mode.
  float hydrotoploadpressure; ///<Current ramped q0 for hydromechanical top load [Pa].
  float porewaterrho;       ///<Pore-water density.
  float porewaterbulkmodulus; ///<Pore-water bulk modulus.
  float porosity;           ///<Soil porosity.
  float hydraulicconductivity; ///<Hydraulic conductivity.
  float porekwn;            ///<Pore-water bulk modulus divided by porosity.
  float poreghyd;           ///<Gravity norm used in pore-water diffusion.
  float gravityx,gravityy,gravityz; ///<Gravity vector.
}StCteInteraction; 

/// Structure to collect kernel information.
typedef struct{
  int forcesbound_rg;
  int forcesbound_bs;
  int forcesbound_bsmax;
  int forcesfluid_rg;
  int forcesfluid_bs;
  int forcesfluid_bsmax;
  int forcesdem_rg;
  int forcesdem_bs;
  int forcesdem_bsmax;
}StKerInfo; 

///Structure with the parameters for particle interaction on GPU.
typedef struct StrInterParmsg{
  //-Configuration options.
  bool simulate2d;
  bool symmetry; //<vs_syymmetry>
  TpKernel tkernel;
  TpFtMode ftmode;
  bool lamsps;
  TpDensity tdensity;
  TpShifting shiftmode;
  TpMdbc2Mode mdbc2;
  //-Execution values.
  float viscob,viscof;
  unsigned bsbound,bsfluid;
  unsigned vnp,vnpb,vnpbok;
  unsigned boundini;
  unsigned fluidini;
  unsigned boundnum;
  unsigned fluidnum;         
  unsigned id;
  unsigned nstep;
  StDivDataGpu divdatag;
  //-Input data arrays.
  const unsigned *dcell;
  const double2 *posxy;
  const double *posz;
  const float4 *poscell;
  const float4 *velrhop;
  const unsigned *idp;
  const typecode *code;
  const float *ftomassp;
  const tsymatrix3f *tau;
  const float3 *dengradcorr;
  const tmatrix3d *corrmat;
  const byte *boundmode;
  const byte *boundslipmode;
  const float3 *tangenvel;
  const float3 *motionvel;
  const float3 *boundnormal;
  float4 *nopenshift;
  //=====mdbr
  const tsymatrix3d* sigma;
  tsymatrix3f* rsigma;
  const tsymatrix3f* artificialstress;
  const float *porepress;
  float *porepressrate;
  const unsigned *fstype;
  const float3 *fsnormal;
  bool hydrodrainfs;
  float3 *hydromechloadace;
  float *hydromechtoploadraw;
  const float3 *boundderivativevel;
  double *porotheta;
  const double *poroj;

  //-Output data arrays.
  float *viscdt;
  float* ar;
  float3 *ace;
  float *delta;
  tsymatrix3f *gradvel;
  float4 *shiftposfs;
  //-Other values and objects.
  cudaStream_t stm;
  StKerInfo *kerinfo;

  ///Structure constructor.
  StrInterParmsg(
     bool simulate2d_
    ,bool symmetry_ //<vs_syymmetry>
    ,TpKernel tkernel_,TpFtMode ftmode_
    ,bool lamsps_,TpDensity tdensity_,TpShifting shiftmode_
    ,TpMdbc2Mode mdbc2_
    ,float viscob_,float viscof_
    ,unsigned bsbound_,unsigned bsfluid_
    ,unsigned np_,unsigned npb_,unsigned npbok_
    ,unsigned id_,unsigned nstep_
    ,const StDivDataGpu &divdatag_,const unsigned *dcell_
    ,const double2 *posxy_,const double *posz_,const float4 *poscell_
    ,const float4 *velrhop_,const unsigned *idp_,const typecode *code_
    ,const float *ftomassp_,const tsymatrix3f *spstau_
    ,const float3 *dengradcorr_
    ,const tmatrix3d *corrmat_
    ,const byte *boundmode_
    ,const byte *boundslipmode_
    ,const float3 *tangenvel_
    ,const float3 *motionvel_
    ,const float3 *boundnormal_,float4 *nopenshift_
    ,float *viscdt_,float* ar_,float3 *ace_,float *delta_
    ,tsymatrix3f *spsgradvel_
    ,const tsymatrix3d *sigma_, tsymatrix3f* rsigma_
    ,const tsymatrix3f *artificialstress_
    ,const float *porepress_,float *porepressrate_
    ,const unsigned *fstype_,const float3 *fsnormal_
    ,bool hydrodrainfs_
    ,float3 *hydromechloadace_
    ,float *hydromechtoploadraw_
    ,float4 *shiftposfs_
    ,cudaStream_t stm_
    ,StKerInfo *kerinfo_,const float3 *boundderivativevel_=NULL,double *porotheta_=NULL,const double *poroj_=NULL)
  {
    //-Configuration options.
    simulate2d=simulate2d_;
    symmetry=symmetry_; //<vs_syymmetry>
    tkernel=tkernel_; ftmode=ftmode_;
    lamsps=lamsps_; tdensity=tdensity_; shiftmode=shiftmode_; mdbc2=mdbc2_;
    //-Execution values.
    viscob=viscob_; viscof=viscof_;
    bsbound=bsbound_; bsfluid=bsfluid_;
    vnp=np_; vnpb=npb_; vnpbok=npbok_;
    boundini=0;   boundnum=vnpbok;
    fluidini=vnpb; fluidnum=vnp-vnpb;
    id=id_; nstep=nstep_; 
    divdatag=divdatag_;
    //-Input data arrays.
    dcell=dcell_;
    posxy=posxy_; posz=posz_; poscell=poscell_;
    velrhop=velrhop_; idp=idp_; code=code_;
    ftomassp=ftomassp_; tau=spstau_;
    dengradcorr=dengradcorr_;
    corrmat=corrmat_;
    boundmode=boundmode_;
    boundslipmode=boundslipmode_;
    tangenvel=tangenvel_;
    motionvel=motionvel_;
    boundnormal=boundnormal_;
    nopenshift=nopenshift_;
    //-Output data arrays.
    viscdt=viscdt_; ar=ar_; ace=ace_; delta=delta_;
    gradvel=spsgradvel_;
    shiftposfs=shiftposfs_;
    //mdbr
    sigma=sigma_; rsigma=rsigma_;
    artificialstress=artificialstress_;
    porepress=porepress_; porepressrate=porepressrate_;
    fstype=fstype_; fsnormal=fsnormal_;
    hydrodrainfs=hydrodrainfs_;
    hydromechloadace=hydromechloadace_;
    hydromechtoploadraw=hydromechtoploadraw_;
    //-Other values and objects.
    stm=stm_;
    kerinfo=kerinfo_;
    boundderivativevel=boundderivativevel_;
    porotheta=porotheta_;
    poroj=poroj_;
  }

}StInterParmsg;


/// Implements a set of functions and CUDA kernels for the particle interaction and system update.
namespace cusph{

inline unsigned ReduMaxFloatSize(unsigned ndata){ return((ndata/SPHBSIZE+1)+(ndata/(SPHBSIZE*SPHBSIZE)+SPHBSIZE)); }
float ReduMaxFloat(unsigned ndata,unsigned inidata,float* data,float* resu);
float ReduMaxFloat_w(unsigned ndata,unsigned inidata,float4* data,float* resu);

void CteInteractionUp(const StCteInteraction *cte);
void InitArray(unsigned n,float3 *v,tfloat3 value);
void Resety(unsigned n,unsigned ini,float3 *v);
void ComputeAceMod(unsigned n,const float3 *ace,float *acemod);
void ComputeAceMod(unsigned n,const typecode *code,const float3 *ace,float *acemod);

void ComputeVelMod(unsigned n,const float4 *vel,float *velmod);
void ComputeArtificialStress(unsigned n,unsigned nbound,const typecode *code,const float4 *velrhop,const tsymatrix3d *sigma,tsymatrix3f *artificialstress,const float *porepress=NULL);
void AddSoilDamping(unsigned n,unsigned nbound,const typecode *code,const float4 *velrhop,float3 *ace,float dynamiccd=0.f);
void ComputeFreeSurfaceTracking(TpKernel tkernel,bool simulate2d,unsigned np,unsigned npb
  ,const StDivDataGpu &dvd,const unsigned *dcell,const float4 *poscell
  ,const float4 *velrhop,const typecode *code,tmatrix3d *corrmat
  ,unsigned *fstype,float3 *fsnormal,float *posdiv,bool marknearfs,const double *poroj=NULL);
void ApplyFreeSurfacePorePressure(unsigned np,unsigned npb,bool drainfs,TpHydroMechLoadMode loadmode
  ,const double2 *posxy,const typecode *code,const unsigned *fstype,float *porepress,float *rate=NULL,bool ponding=false);
void ApplyHydroMechTopLoadAcceleration(unsigned np,unsigned npb,TpHydroMechLoadMode loadmode,float accmag
  ,const double2 *posxy,const double *posz,const typecode *code,const unsigned *fstype,const float3 *fsnormal,float3 *ace,float3 *loadace);
unsigned HydroMechTopBandAuxSize(unsigned np); ///<Required scratch size in floats, not bytes.
tdouble3 ComputeHydroMechTopBandTotals(unsigned np,unsigned npb,double mass,double support
  ,const double *posz,const typecode *code,const float3 *loadace,const float *raw,float *aux,const double *poroj=NULL);
void ApplyHydroMechTopBandLoad(unsigned np,unsigned npb,double zmax,double support,double scale
  ,const double *posz,const typecode *code,const float *raw,float3 *ace,float3 *loadace);
void ExtrapolateYaoTopStripPorePressure(TpKernel tkernel,bool simulate2d,unsigned np,unsigned npb,TpHydroMechLoadMode loadmode
  ,const StDivDataGpu &dvd,const unsigned *dcell,const double2 *posxy,const double *posz
  ,const float4 *velrhop,const typecode *code,const unsigned *fstype,float *porepress);
void UpdatePorePressureVerlet(unsigned np,unsigned npb,double dt2,const typecode *code,const float *poreold,const float *porepressrate,float *porepressnew);
void UpdatePorePressureSymplectic(unsigned np,unsigned npb,double dt,const typecode *code,const float *porepresspre,const float *porepressrate,float *porepress
  ,bool drainfs=false,TpHydroMechLoadMode loadmode=HMLOAD_None,const double2 *posxy=NULL,const unsigned *fstype=NULL);
//-Non-feedback observer; dt is the already-halved predictor or full corrector step.
//-Caller initializes invalid=np and checks it before advancing any later state.
void UpdatePorosityObserver(unsigned np,unsigned npb,bool corrector,double dt,double solid0
  ,const typecode *code,const float *kplastic,const double *jn,const double *theta,double *j,unsigned *invalid);
//-Current native J-derived undrained speed squared; caller initializes maxcu2=0 and invalid=np.
void ComputePorosityWaveSpeed2(unsigned np,unsigned npb,double solid0,double rho0,double rhow,double m,double kw
  ,const typecode *code,const double *j,double *maxcu2,unsigned *invalid
  ,double khyd=0,double gamma=1,double *maxdiffusion=NULL,bool conductivity=false,double ck=0);
//-Extend only requested fields from normal-fluid native owners; caller initializes invalid=np.
void ExtendDynamicPorePeriodic(unsigned np,unsigned npb,unsigned idini,unsigned idfin
  ,const typecode *code,const unsigned *idp,const unsigned *ridp
  ,tmatrix3d *corrmat,float3 *ace,double *theta,float *rate,unsigned *invalid,float *porepress=NULL);
//-Private 2-D static mirror closure: stage0=state11,1=C9,2=finished Ace3; public guards remain separate.
//-Only npbok active fixed samples are written; caller initializes invalid=np.
void DynamicPoreWall(unsigned stage,unsigned np,unsigned npbok,float threshold,const StDivDataGpu &dvd
  ,const double2 *posxy,const double *posz,const typecode *code,const float3 *boundnormal
  ,byte *boundmode,float3 *tangenvel,float3 *derivativevel,float4 *velrhop,tsymatrix3d *sigma
  ,float *porepress,double *j,double *theta,tmatrix3d *corrmat,float3 *ace,double solid0,unsigned *invalid,TpKernel tkernel=KERNEL_Wendland,const byte *boundslipmode=NULL,const float4 *poscell=NULL);
//-Complete same-stage rate; optional smooth k(J) chain and native gradient-speed maximum.
void ComputeDynamicPorePressureRate(unsigned np,unsigned npb,const StDivDataGpu &dvd,const unsigned *dcell
  ,const double2 *posxy,const double *posz,const typecode *code,const tmatrix3d *corrmat,const float3 *ace
  ,const double *j,const double *theta,const float *porepress,float *rate
  ,double solid0,double kw,double rhow,double khyd,double gamma,double vol0,unsigned *invalid
  ,bool conductivity=false,double ck=0,double *maxspeed=NULL,bool wall=false,const byte *boundmode=NULL
  ,const unsigned *fstype=NULL,const float3 *fsnormal=NULL,bool drainfs=false,bool closedfs=false,TpHydroMechLoadMode loadmode=HMLOAD_None
  ,tdouble3 bodycentre=TDouble3(0),double bodyradius2=0,TpKernel tkernel=KERNEL_Wendland,bool freeseepage=false);
void PorePressureMdbcCorrection(TpKernel tkernel,bool simulate2d,unsigned n
  ,float mdbcthreshold,const StDivDataGpu &dvd,const tdouble3 &mapposmin
  ,const double2 *posxy,const double *posz,const float4 *poscell
  ,const typecode *code,const float4 *velrhop,const float3 *boundnormal
  ,const float *porepress0,float *porepress);
void BoundaryDerivativeVelocity(bool simulate2d,unsigned npb,unsigned npbok,float mdbcthreshold
  ,TpSlipMode slipmode,const StDivDataGpu &dvd,const double2 *posxy,const double *posz
  ,const typecode *code,const float4 *velrhop,const float3 *boundnormal
  ,const byte *boundmode,const byte *boundslipmode,float3 *boundderivativevel
  ,const unsigned *idp=NULL,const double3 *fitshift=NULL);
void ShepardRegularizePorePressure(TpKernel tkernel,bool simulate2d,unsigned np,unsigned npb
  ,bool drainfs,TpHydroMechLoadMode loadmode,const StDivDataGpu &dvd,const unsigned *dcell
  ,const double2 *posxy,const double *posz,const float4 *velrhop,const typecode *code
  ,const unsigned *fstype,const byte *boundmode,const byte *boundslipmode
  ,const float *porepress0,const float *porepress,float *porepressnew,const double *poroj=NULL);

//-Kernels for the force calculation.
void Interaction_Forces(const StInterParmsg &t);

//-Kernels for the boundary correction (mDBC).
//-Read-only marker/support query; caller initializes invalid=npbok.
void CheckHydroMechNoWallSupport(unsigned npbok,const StDivDataGpu &dvd
  ,const double2 *posxy,const double *posz,const float4 *poscell,const typecode *code,unsigned *invalid);
void Interaction_MdbcCorrection(TpKernel tkernel,bool simulate2d
  ,TpSlipMode slipmode,bool fastsingle,unsigned n,unsigned nbound
  ,float mdbcthreshold,const StDivDataGpu &dvd,const tdouble3 &mapposmin
  ,const double2 *posxy,const double *posz,const float4 *poscell
  ,const typecode *code,const unsigned *idp,const float3 *boundnormal
  ,const float3 *motionvel,float4 *velrhop,tsymatrix3d *sigma,byte *boundmode,const byte *boundslipmode,float3 *tangenvel
  ,const float *porepress0,float *porepress);

//-Kernels for the boundary treatment (cDBC).

void Interaction_CdbcCorrection(TpKernel tkernel,bool simulate2d
    ,TpSlipMode slipmode,unsigned n,unsigned nbound,float mdbcthreshold
    ,const StDivDataGpu &dvd,const double2 *posxy,const double *posz
    ,const unsigned* dcell,const float4 *poscell,const typecode *code,const unsigned *idp
    ,const float3 *motionvel,float4 *velrhop,tsymatrix3d *sigma,const byte *boundslipmode);

//-Kernels for the calculation of the DEM forces.
void Interaction_ForcesDem(unsigned bsize,unsigned nfloat
  ,const StDivDataGpu &dvd,const unsigned *dcell
  ,const unsigned *ftridp,const float4 *demdata,const float *ftomassp,float dtforce
  ,const float4 *poscell,const float4 *velrhop
  ,const typecode *code,const unsigned *idp,float *viscdt,float3 *ace,StKerInfo *kerinfo);

//-Kernels for calculating the Laminar+SPS viscosity.
void ComputeSpsTau(unsigned np,unsigned npb,float smag,float blin
  ,const float4 *velrhop,const tsymatrix3f *gradvelg,tsymatrix3f *tau,cudaStream_t stm=NULL);

//-Kernels for Delta-SPH.
void AddDelta(unsigned n,const float *delta,float *ar,cudaStream_t stm=NULL);

//-Kernels for ComputeStep (position).
void ComputeStepPos (byte periactive,bool floatings,unsigned np,unsigned npb
  ,const double2 *movxy,const double *movz,double2 *posxy,double *posz
  ,unsigned *dcell,typecode *code);
void ComputeStepPos2(byte periactive,bool floatings,unsigned np,unsigned npb
  ,const double2 *posxypre,const double *poszpre,const double2 *movxy,const double *movz
  ,double2 *posxy,double *posz,unsigned *dcell,typecode *code);

//-Kernels for Motion.
void CalcRidp(bool periactive,unsigned np,unsigned pini,unsigned idini,unsigned idfin
  ,const typecode *code,const unsigned *idp,unsigned *ridp);
void MoveLinBound(byte periactive,unsigned np,unsigned ini,tdouble3 mvpos,tfloat3 mvvel
  ,const unsigned *ridp,double2 *posxy,double *posz,unsigned *dcell,float4 *velrhop,typecode *code);
void MoveMatBound(byte periactive,bool simulate2d,unsigned np,unsigned ini,tmatrix4d m,double dt
  ,const unsigned *ridpmv,double2 *posxy,double *posz,unsigned *dcell,float4 *velrhop,typecode *code,float3 *boundnormal);
void CopyMotionVel(unsigned nmoving,const unsigned *ridpmv,const float4 *velrhop,float3 *motionvel);
void FtNormalsUpdate(unsigned np,unsigned ini,tmatrix4d m,const unsigned *ftridp,float3 *boundnormal);

//-Kernels for MLPistons motion.
void MovePiston1d(bool periactive,unsigned np,unsigned idini,double dp,double poszmin,unsigned poszcount,const byte *pistonid,const double* movx,const double* velx,const unsigned *ridpmv,double2 *posxy,double *posz,unsigned *dcell,float4 *velrhop,typecode *code);
void MovePiston2d(bool periactive,unsigned np,unsigned idini,double dp,double posymin,double poszmin,unsigned poszcount,const double* movx,const double* velx,const unsigned *ridpmv,double2 *posxy,double *posz,unsigned *dcell,float4 *velrhop,typecode *code);

//-Kernels for Floating bodies.
void FtCalcForcesSum(bool periactive,unsigned ftcount
  ,const float4 *ftodata,const double3 *ftocenter,const unsigned *ftridp
  ,const double2 *posxy,const double *posz,const float3 *ace
  ,float3 *ftoforcessum);
void FtCalcForces(unsigned ftcount,tfloat3 gravity
  ,const float *ftomass,const float3 *ftoangles
  ,const float4 *ftoinertiaini8,const float *ftoinertiaini1
  ,float3 *ftoforces);
void FtCalcForcesRes(unsigned ftcount,bool simulate2d,double dt
  ,const float3 *ftovelace,const double3 *ftocenter,const float3 *ftoforces
  ,float3 *ftoforcesres,double3 *ftocenterres);
void FtApplyConstraints(unsigned ftcount,const byte *ftoconstraints
  ,float3 *ftoforces,float3 *ftoforcesres);
void FtUpdate(bool periactive,bool predictor,unsigned ftcount,double dt
  ,const float4 *ftodatp,const float3 *ftoforcesres,double3 *ftocenterres,const unsigned *ftridp
  ,double3 *ftocenter,float3 *ftoangles,float3 *ftovelace
  ,double2 *posxy,double *posz,unsigned *dcell,float4 *velrhop,typecode *code);
void FtGetPosRef(unsigned np,const unsigned *idpref,const unsigned *ftridp //<vs_ftmottionsv>
  ,const double2 *posxy,const double *posz,double *posref);                 //<vs_ftmottionsv>

//-Kernels for periodic conditions.
void PeriodicIgnore(unsigned n,typecode *code);
unsigned PeriodicMakeList(unsigned n,unsigned pini,bool stable,unsigned nmax,tdouble3 mapposmin,tdouble3 mapposmax,tdouble3 perinc,const double2 *posxy,const double *posz,const typecode *code,unsigned *listp);
void PeriodicDuplicateVerlet(unsigned n,unsigned pini,tuint3 domcells,tdouble3 perinc
  ,const unsigned *listp,unsigned *idp,typecode *code,unsigned *dcell
  ,double2 *posxy,double *posz,float4 *velrhop,tsymatrix3f *spstau,float4 *velrhopm1,tsymatrix3d *sigma,tsymatrix3d *sigmam1
  ,float *porepress,float *porepress0,float *porepressrate,float *porepressm1,float *kplastic=NULL,float *kplasticdk=NULL,float *kplasticm1=NULL);
void PeriodicDuplicateSymplectic(unsigned n,unsigned pini
  ,tuint3 domcells,tdouble3 perinc,const unsigned *listp,unsigned *idp,typecode *code,unsigned *dcell
  ,double2 *posxy,double *posz,float4 *velrhop,tsymatrix3f *spstau,double2 *posxypre,double *poszpre,float4 *velrhoppre
  ,tsymatrix3d *sigma, tsymatrix3d *sigmapre,float *porepress,float *porepress0,float *porepressrate,float *porepresspre
  ,double *poroj=NULL,double *porotheta=NULL,double *porojpre=NULL,float *kplastic=NULL,float *kplasticdk=NULL);
void PeriodicDuplicateNormals(unsigned n,unsigned pini,const unsigned *listp,float3 *normals,float3 *motionvel,byte *boundslipmode);

//-Kernels for Damping.
void ComputeDampingPlane(double dt,double4 plane,float dist,float over
  ,float3 factorxyz,float redumax,unsigned n,unsigned pini
  ,const double2 *posxy,const double *posz,const typecode *code,float4 *velrhop);
void ComputeDampingPlaneDom(double dt,double4 plane,float dist,float over,float3 factorxyz
  ,float redumax,double zmin,double zmax,double4 pla0,double4 pla1,double4 pla2,double4 pla3
  ,unsigned n,unsigned pini,const double2 *posxy,const double *posz,const typecode *code
  ,float4 *velrhop);
void ComputeDampingBox(unsigned n,unsigned pini,double dt,float3 factorxyz,float redumax
  ,double3 limitmin1,double3 limitmin2,double3 limitmax1,double3 limitmax2
  ,double3 limitover1,double3 limitover2,double3 boxsize1,double3 boxsize2
  ,const double2 *posxy,const double *posz,const typecode *code,float4 *velrhop);
void ComputeDampingCylinder(unsigned n,unsigned pini
  ,double dt,double3 point1,double3 point2,double limitmin
  ,float dist,float over,float3 factorxyz,float redumax
  ,const double2 *posxy,const double *posz,const typecode *code
  ,float4 *velrhop);

}


#endif


