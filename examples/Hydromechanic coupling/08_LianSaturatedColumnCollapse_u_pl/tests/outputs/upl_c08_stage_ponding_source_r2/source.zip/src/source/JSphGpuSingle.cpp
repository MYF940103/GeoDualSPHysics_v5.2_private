//HEAD_DSPH
/*
 <DUALSPHYSICS>  Copyright (c) 2020 by Dr Jose M. Dominguez et al. (see http://dual.sphysics.org/index.php/developers/). 

 EPHYSLAB Environmental Physics Laboratory, Universidade de Vigo, Ourense, Spain.
 School of Mechanical, Aerospace and Civil Engineering, University of Manchester, Manchester, U.K.

 This file is part of DualSPHysics. 

 DualSPHysics is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License 
 as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version.
 
 DualSPHysics is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details. 

 You should have received a copy of the GNU Lesser General Public License along with DualSPHysics. If not, see <http://www.gnu.org/licenses/>. 
*/

/// \file JSphGpuSingle.cpp \brief Implements the class \ref JSphGpuSingle.

#include "JSphGpuSingle.h"
#include "JGravityPreloadState.h"
#include "JSphHourglassGpu.h"
#include "JCellDivGpuSingle.h"
#include "JArraysGpu.h"
#include "JSphMk.h"
#include "JPartsLoad4.h"
#include "Functions.h"
#include "JXml.h"
#include "JDsMotion.h"
#include "JDsViscoInput.h"
#include "JWaveGen.h"
#include "JMLPistons.h"
#include "JRelaxZones.h"
#include "JChronoObjects.h"
#include "JDsMooredFloatings.h"
#include "JDsFtForcePoints.h"
#include "JDsOutputTime.h"
#include "JTimeControl.h"
#include "JSphGpu_ker.h"
#include "JSphGpuSimple_ker.h"
#include "JDsGaugeSystem.h"
#include "JSphInOut.h"
#include "JFtMotionSave.h" //<vs_ftmottionsv>  
#include "JLinearValue.h"
#include "JDataArrays.h"
#include "JDebugSphGpu.h"
#include "JSphShifting.h"
#include "JDsPips.h"
#include "JDsExtraData.h"
#include "FunctionsCuda.h"

#include <climits>
#include <cfloat>
#include <cmath>
#include <map>

using namespace std;
//==============================================================================
/// Constructor.
//==============================================================================
JSphGpuSingle::JSphGpuSingle():JSphGpu(false){
  ClassName="JSphGpuSingle";
  CellDivSingle=NULL;
  HourglassGpu=NULL;
}

//==============================================================================
/// Destructor.
//==============================================================================
JSphGpuSingle::~JSphGpuSingle(){
  DestructorActive=true;
  delete CellDivSingle; CellDivSingle=NULL;
  delete HourglassGpu; HourglassGpu=NULL;
}

//==============================================================================
/// Returns the memory allocated to the CPU.
/// Devuelve la memoria reservada en CPU.
//==============================================================================
llong JSphGpuSingle::GetAllocMemoryCpu()const{  
  llong s=JSphGpu::GetAllocMemoryCpu();
  //-Allocated in other objects.
  if(CellDivSingle)s+=CellDivSingle->GetAllocMemoryCpu();
  return(s);
}

//==============================================================================
/// Returns the memory allocated to the GPU.
/// Devuelve la memoria reservada en GPU.
//==============================================================================
llong JSphGpuSingle::GetAllocMemoryGpu()const{  
  llong s=JSphGpu::GetAllocMemoryGpu();
  //-Allocated in other objects.
  if(CellDivSingle)s+=CellDivSingle->GetAllocMemoryGpu();
  if(HourglassGpu)s+=HourglassGpu->GetAllocMemory();
  return(s);
}

//==============================================================================
/// Returns the GPU memory allocated or used for particles
/// Devuelve la memoria GPU reservada o usada para particulas.
//==============================================================================
llong JSphGpuSingle::GetMemoryGpuNp()const{
  llong s=JSphGpu::GetAllocMemoryGpu();
  //-Allocated in other objects.
  if(CellDivSingle)s+=CellDivSingle->GetAllocMemoryGpuNp();
  return(s);
}

//==============================================================================
/// Returns the GPU memory allocated or used for cells.
/// Devuelve la memoria GPU reservada o usada para celdas.
//==============================================================================
llong JSphGpuSingle::GetMemoryGpuNct()const{
  llong s=CellDivSingle->GetAllocMemoryGpuNct();
  return(CellDivSingle->GetAllocMemoryGpuNct());
}

//==============================================================================
/// Updates the maximum values of memory, particles and cells.
/// Actualiza los valores maximos de memory, particles y cells.
//==============================================================================
void JSphGpuSingle::UpdateMaxValues(){
  const llong mcpu=GetAllocMemoryCpu();
  const llong mgpu=GetAllocMemoryGpu();
  MaxNumbers.memcpu=max(MaxNumbers.memcpu,mcpu);
  MaxNumbers.memgpu=max(MaxNumbers.memgpu,mgpu);
  MaxNumbers.particles=max(MaxNumbers.particles,Np);
  if(CellDivSingle)MaxNumbers.cells=max(MaxNumbers.cells,CellDivSingle->GetNct());
}

//==============================================================================
/// Loads the configuration of the execution.
/// Carga la configuracion de ejecucion.
//==============================================================================
void JSphGpuSingle::LoadConfig(const JSphCfgRun *cfg){
  //-Loads general configuration.
  JSph::LoadConfig(cfg);
  if(HydroMechDynamicSeepage){
    PorosityObserver=PorosityFeedback=DynamicPorePressure=true;
    DynamicPoreWall=(CaseNpb>0 && !DynamicPoreFreeBody);
    DynamicPoreConductivity=(HydroMechConductivityModel==1);
    DynamicPoreConductivityCk=HydroMechConductivityCk;
  }
  //-Checks compatibility of selected options.
  Log->Print("**Special case configuration is loaded");
}

//==============================================================================
/// Configuration of the current domain.
/// Configuracion del dominio actual.
//==============================================================================
void JSphGpuSingle::ConfigDomain(){
  if(SoilBoundaryDerivativeSPR){
    if(!HydroMech || TKernel!=KERNEL_Wendland || TStep!=STEP_Symplectic || Symmetry)
      Run_Exceptioon("SoilBoundaryDerivativeSPR requires hydromechanics, Wendland and Symplectic without symmetry.");
    if(PartBegin || CaseNmoving || CaseNfloat || InOut || Shifting || Damping || RelaxZones || StrainSoftening || UseDEM)
      Run_Exceptioon("SoilBoundaryDerivativeSPR supports fresh fixed-wall elastic cases only: no moving/floating bodies, in/out, shifting, relaxation or softening.");
    bool slipok=(SlipMode==SLIP_Vel0 && TMdbc2==MDBC2_None && !NoPenetration)
      || ((SlipMode==SLIP_NoSlip || SlipMode==SLIP_FreeSlip) && (TMdbc2==MDBC2_Std || TMdbc2==MDBC2_NoPen));
    if(MdbcSlipModeByMk){
      //-The derivative kernel already uses BoundSlipModeg; admit NoSlip/FreeSlip faces only.
      slipok=(SlipMode==SLIP_NoSlip || SlipMode==SLIP_FreeSlip) && (TMdbc2==MDBC2_Std || TMdbc2==MDBC2_NoPen);
      for(const auto &wall:MdbcSlipModeMk)slipok=slipok && (wall.SlipMode==SLIP_NoSlip || wall.SlipMode==SLIP_FreeSlip);
    }
    if(TBoundary!=BC_MDBC || !slipok || !UseNormals
      || TVisco!=VISCO_Artificial || TDensity!=DDT_None || ArtificialStress)
      Run_Exceptioon("SoilBoundaryDerivativeSPR requires uniform mDBC SlipMode 1/2/3 or per-mk NoSlip/FreeSlip faces, normals, artificial viscosity, DensityDT=0 and no artificial stress; NoPen requires NoSlip or FreeSlip.");
    if(!SoilStressRateGradCorr || !PoreCompressionGradCorr || PoreCompressionSourceMode!=0 || (Simulate2D && PeriY))
      Run_Exceptioon("SoilBoundaryDerivativeSPR requires corrected stress/pore gradients, PairDivergence and no y periodicity in 2-D.");
  }
  if(SoilHourglassXi>0){
    if(!Simulate2D || TKernel!=KERNEL_Wendland || TStep!=STEP_Symplectic || Symmetry)
      Run_Exceptioon("SoilHourglassXi currently requires 2-D Wendland with Symplectic integration and no symmetry plane.");
    if(PartBegin || CaseNmoving || CaseNfloat || InOut || Shifting || Damping || RelaxZones || StrainSoftening || UseDEM)
      Run_Exceptioon("SoilHourglassXi supports a fixed native elastic soil set only: no restart, moving/floating bodies, in/out, shifting, relaxation or softening.");
    if(PeriY || PeriZ || (PeriX && (PeriXinc.y!=0 || PeriXinc.z!=0 || KernelSize>=fabs(PeriXinc.x)*.5)))
      Run_Exceptioon("SoilHourglassXi requires a bounded domain or axis-aligned x periodicity with kernel support smaller than half the period.");
    HourglassGpu=new JSphHourglassGpu();
    HourglassGpu->Config(CaseNpb,CaseNfluid,SoilHourglassXi,MassFluid,(PeriX? fabs(PeriXinc.x): 0),
      CSP.kernelh,KernelSize,CSP.kwend.bwen,SoilCte.ModulusG,
      (PorosityFeedback? RhopZero: 0),(PorosityFeedback? SoilCte.PoreWaterRho: 0));
  }
  //-Configure cell map division (defines ScellDiv, Scell, Map_Cells). 
  ConfigCellDivision();
  //-Computes the number of particles.
  Np=PartsLoaded->GetCount(); Npb=CaseNpb; NpbOk=Npb;
  //-Allocates memory for arrays with fixed size (motion and floating bodies).
  AllocGpuMemoryFixed();
  //-Allocates GPU memory for particles.
  AllocGpuMemoryParticles(Np,0);
  //-Allocates memory on the CPU.
  AllocCpuMemoryFixed();
  AllocCpuMemoryParticles(Np);

  //-Copies particle data.
  memcpy(AuxPos,PartsLoaded->GetPos(),sizeof(tdouble3)*Np);
  memcpy(Idp,PartsLoaded->GetIdp(),sizeof(unsigned)*Np);
  memcpy(Velrhop,PartsLoaded->GetVelRhop(),sizeof(tfloat4)*Np);
  //========= mdbr
  if(PartBegin && PartsLoaded->GetSoilDataLoaded()){
    for(unsigned p=0;p<Np;p++)Sigma[p]=PartsLoaded->GetSigma()[p];
    memset(Kplastic,0,sizeof(float)*Np);
    Log->Print("Restart soil data: Sigma inherited, Kplastic reset for restart stage.");
  }
  else{
    memset(Sigma,0,sizeof(tsymatrix3d)*Np);
    memset(Kplastic,0,sizeof(float)*Np);
  }
  if(HydroMech){
    const bool initpore=(HydroMechInitMode!=HMINIT_None);
    if(PartBegin && !initpore){
      if(!PartsLoaded->GetPorePressureDataLoaded())
        Run_Exceptioon("Hydromechanical restart requires PorePress and PorePress0 arrays in the PART file.");
      memcpy(PorePress,PartsLoaded->GetPorePress(),sizeof(float)*Np);
      memcpy(PorePress0,PartsLoaded->GetPorePress0(),sizeof(float)*Np);
      Log->Print("Restart hydromechanical data: PorePress and PorePress0 inherited.");
    }
    else{
      memset(PorePress,0,sizeof(float)*Np);
      memset(PorePress0,0,sizeof(float)*Np);
      if(PartBegin && initpore)
        Log->Print("Restart hydromechanical data: PorePress and PorePress0 will be initialized from HydroMechInitMode.");
    }
    if(AuxHydroMechLoadAce)memset(AuxHydroMechLoadAce,0,sizeof(tfloat3)*Np);
    if(HydroMechLoadAceg)cudaMemset(HydroMechLoadAceg,0,sizeof(float3)*Np);
  }
  //========= mdbr

  //-Computes radius of floating bodies.
  if(CaseNfloat && PeriActive!=0 && !PartBegin)CalcFloatingRadius(Np,AuxPos,Idp);
  //-Configures floating motion data storage with high frequency. //<vs_ftmottionsv>  
  if(FtMotSave)ConfigFtMotionSave(Np,AuxPos,Idp);                 //<vs_ftmottionsv>  

  //-Configures Multi-Layer Pistons according particles. | Configura pistones Multi-Layer segun particulas.
  if(MLPistons)MLPistons->PreparePiston(Dp,Np,Idp,AuxPos);

  //-Loads Code of the particles.
  LoadCodeParticles(Np,Idp,Code);
  byte *boundslipmode=NULL;
  if(MdbcSlipModeByMk){
    boundslipmode=new byte[Np];
    InitMdbcSlipModeParticles(Np,Code,boundslipmode);
  }

  //-Load normals for boundary particles (fixed and moving).
  tfloat3 *boundnormal=NULL;
  if(UseNormals){
    boundnormal=new tfloat3[Np];
    LoadBoundNormals(Np,Npb,Idp,Code,boundnormal);
  }
  //-Configure initial profile----mdbr
  for (unsigned p = 0; p < Npb; p++) {
      Velrhop[p].w = RhopZero;
  }
  for (unsigned p = Npb; p < Np; p++)
  {
      //    float SolidH = 0.18f;
      Velrhop[p].w = RhopZero;
      //  if (SolidH != 0) {
      //	  Sigma[p].zz=float(RhopZero*CSP.gravity.z*(SolidH - AuxPos[p].z));
      //  }
      //  else { Sigma[p].zz = 0; }
      //  Sigma[p].xx = float((1. - sin(SoilCte.phi))*Sigma[p].zz);
      //  Sigma[p].yy = float((1. - sin(SoilCte.phi))*Sigma[p].zz);
  }

  //-Creates PartsInit object with initial particle data for automatic configurations.
  CreatePartsInit(Np,AuxPos,Code);

  //-Runs initialization operations from XML.
  RunInitialize(Np,Npb,AuxPos,Idp,Code,Velrhop,boundnormal);
  ConfigHydroMechNoWall(Np,Npb,AuxPos,Idp,Code,Velrhop);
  if(UseNormals)ConfigBoundNormals(Np,Npb,AuxPos,Idp,boundnormal);
  if(DynamicPoreWall)InitDynamicPoreWallGpu(boundnormal,boundslipmode);

  InitBoundaryDerivativeGpu(boundnormal);

  //-Computes MK domain for boundary and fluid particles.
  MkInfo->ComputeMkDomains(Np,AuxPos,Code);

  //-Sets local domain of the simulation within Map_Cells and computes DomCellCode.
  //-Establece dominio de simulacion local dentro de Map_Cells y calcula DomCellCode.
  SelecDomain(TUint3(0,0,0),Map_Cells);
  //-Computes inital cell of the particles and checks if there are unexpected excluded particles.
  //-Calcula celda inicial de particulas y comprueba si hay excluidas inesperadas.
  LoadDcellParticles(Np,Code,AuxPos,Dcell);

  //-Uploads particle data on the GPU.
  ReserveBasicArraysGpu();
  for(unsigned p=0;p<Np;p++){ Posxy[p]=TDouble2(AuxPos[p].x,AuxPos[p].y); Posz[p]=AuxPos[p].z; }
  ParticlesDataUp(Np,boundnormal,boundslipmode);
  InitPorosityObserverGpu();
  delete[] boundnormal; boundnormal=NULL;
  delete[] boundslipmode; boundslipmode=NULL;
  //-Uploads constants on the GPU.
  ConstantDataUp();

  //-Creates object for Celldiv on the GPU and selects a valid cellmode.
  //-Crea objeto para divide en GPU y selecciona un cellmode valido.
  CellDivSingle=new JCellDivGpuSingle(Stable,FtCount!=0,PeriActive,KernelSize2,PosCellSize
    ,CellDomFixed,CellMode,Scell,Map_PosMin,Map_PosMax,Map_Cells,CaseNbound,CaseNfixed,CaseNpb,DirOut);
  CellDivSingle->DefineDomain(DomCellCode,DomCelIni,DomCelFin,DomPosMin,DomPosMax);
  ConfigCellDiv((JCellDivGpu*)CellDivSingle);

  ConfigBlockSizes(false,PeriActive!=0);
  ConfigSaveData(0,1,"");

  //-Reorders particles according to cells.
  //-Reordena particulas por celda.
  BoundChanged=true;
  RunCellDivide(true);
  if(HydroMech && HydroMechInitMode!=HMINIT_None){
    ComputeFreeSurfaceTracking();
    InitHydroMechPorePressure();
    if(DynamicPorePressure && HydroMechInitMode==HMINIT_ConstantZ)ApplyPorePressureBoundaries();
  }
}

//==============================================================================
/// Resizes the allocated space for particles on the CPU and the GPU measuring
/// the time spent with TMG_SuResizeNp. At the end updates the division.
///
/// Redimensiona el espacio reservado para particulas en CPU y GPU midiendo el
/// tiempo consumido con TMG_SuResizeNp. Al terminar actualiza el divide.
//==============================================================================
void JSphGpuSingle::ResizeParticlesSize(unsigned newsize,float oversize,bool updatedivide){
  Timersg->TmStart(TMG_SuResizeNp,false);
  newsize+=(oversize>0? unsigned(oversize*newsize): 0);
  FreeCpuMemoryParticles();
  CellDivSingle->FreeMemoryGpu();
  DivData=DivDataGpuNull();
  ResizeGpuMemoryParticles(newsize);
  AllocCpuMemoryParticles(newsize);
  Timersg->TmStop(TMG_SuResizeNp,false);
  if(updatedivide)RunCellDivide(true);
}

//==============================================================================
/// Creates duplicate particles for periodic conditions.
/// Creates new periodic particles and marks the old ones to be ignored.
/// The new particles are lccated from the value of Np, first the NpbPer for 
/// boundaries and then the NpfPer for the fluids. The Np output also contains 
/// the new periodic particles.
///
/// Crea particulas duplicadas de condiciones periodicas.
/// Crea nuevas particulas periodicas y marca las viejas para ignorarlas.
/// Las nuevas periodicas se situan a partir del Np de entrada, primero las NpbPer
/// de contorno y despues las NpfPer fluidas. El Np de salida contiene tambien las
/// nuevas periodicas.
//==============================================================================
void JSphGpuSingle::RunPeriodic(){
  Timersg->TmStart(TMG_SuPeriodic,false);
  //-Stores the current number of periodic particles.
  //-Guarda numero de periodicas actuales.
  NpfPerM1=NpfPer;
  NpbPerM1=NpbPer;
  //-Marks current periodic particles to be ignored.
  //-Marca periodicas actuales para ignorar.
  cusph::PeriodicIgnore(Np,Codeg);
  //-Creates new periodic particles.
  //-Crea las nuevas periodicas.
  const unsigned npb0=Npb;
  const unsigned npf0=Np-Npb;
  const unsigned np0=Np;
  NpbPer=NpfPer=0;
  BoundChanged=true;
  for(unsigned ctype=0;ctype<2;ctype++){//-0:bound, 1:fluid+floating.
    //-Computes the particle range to be examined (bound and fluid).
    //-Calcula rango de particulas a examinar (bound o fluid).
    const unsigned pini=(ctype? npb0: 0);
    const unsigned num= (ctype? npf0: npb0);
    //-Searches for periodic zones on each axis (X, Y and Z).
    //-Busca periodicas en cada eje (X, Y e Z).
    for(unsigned cper=0;cper<3;cper++)if((cper==0 && PeriX) || (cper==1 && PeriY) || (cper==2 && PeriZ)){
      tdouble3 perinc=(cper==0? PeriXinc: (cper==1? PeriYinc: PeriZinc));
      //-First searches in the list of new periodic particles and then in the initial particle list (necessary for periodic zones in more than one axis)
      //-Primero busca en la lista de periodicas nuevas y despues en la lista inicial de particulas (necesario para periodicas en mas de un eje).
      for(unsigned cblock=0;cblock<2;cblock++){//-0:new periodic particles, 1:original periodic particles
        const unsigned nper=(ctype? NpfPer: NpbPer);  //-number of new periodic particles for the type currently computed (bound or fluid). | Numero de periodicas nuevas del tipo a procesar.
        const unsigned pini2=(cblock? pini: Np-nper);
        const unsigned num2= (cblock? num:  nper);
        //-Repeats search if the available memory was insufficient and had to be increased.
        //-Repite la busqueda si la memoria disponible resulto insuficiente y hubo que aumentarla.
        bool run=true;
        while(run && num2){
          //-Allocates memory to create the periodic particle list.
          //-Reserva memoria para crear lista de particulas periodicas.
          unsigned* listpg=ArraysGpu->ReserveUint();
          unsigned nmax=GpuParticlesSize-1; //-Maximum number of particles that can be included in the list. | Numero maximo de particulas que caben en la lista.
          //-Generates list of new periodic particles
          if(Np>=0x80000000)Run_Exceptioon("The number of particles is too big.");//-Because the last bit is used to mark the reason the new periodical is created. | Porque el ultimo bit se usa para marcar el sentido en que se crea la nueva periodica. 
          unsigned count=cusph::PeriodicMakeList(num2,pini2,Stable,nmax,Map_PosMin,Map_PosMax,perinc,Posxyg,Poszg,Codeg,listpg);
          //-Resizes the memory size for the particles if there is not sufficient space and repeats the serach process.
          //-Redimensiona memoria para particulas si no hay espacio suficiente y repite el proceso de busqueda.
          if(count>nmax || !CheckGpuParticlesSize(count+Np)){
            ArraysGpu->Free(listpg); listpg=NULL;
            Timersg->TmStop(TMG_SuPeriodic,false);
            ResizeParticlesSize(Np+count,PERIODIC_OVERMEMORYNP,false);
            Timersg->TmStart(TMG_SuPeriodic,false);
          }
          else{
            run=false;
            //-Create new periodic particles duplicating the particles from the list
            //-Crea nuevas particulas periodicas duplicando las particulas de la lista.
            if(TStep==STEP_Verlet)cusph::PeriodicDuplicateVerlet(count,Np,DomCells,perinc,listpg,Idpg,Codeg,Dcellg,Posxyg,Poszg,Velrhopg,SpsTaug,VelrhopM1g,Sigmag,SigmaM1g,PorePressg,PorePress0g,PorePressRateg,PorePressM1g,Kplasticg,KplasticDkg,KplasticM1g);
            if(TStep==STEP_Symplectic){
              if((PosxyPreg || PoszPreg || VelrhopPreg) && (!PosxyPreg || !PoszPreg || !VelrhopPreg))Run_Exceptioon("Symplectic data is invalid.") ;
              cusph::PeriodicDuplicateSymplectic(count,Np,DomCells,perinc,listpg,Idpg,Codeg,Dcellg,Posxyg,Poszg,Velrhopg,SpsTaug,PosxyPreg,PoszPreg,VelrhopPreg,Sigmag,SigmaPreg,PorePressg,PorePress0g,PorePressRateg,PorePressPreg,PoroJg,PoroThetag,PoroJPreg,Kplasticg,KplasticDkg);
            }
            if(UseNormals)cusph::PeriodicDuplicateNormals(count,Np,listpg,BoundNormalg,MotionVelg,BoundSlipModeg);

            //-Frees memory and updates the particle number.
            //-Libera lista y actualiza numero de particulas.
            ArraysGpu->Free(listpg); listpg=NULL;
            Np+=count;
            //-Updated number of new periodic particles.
            //-Actualiza numero de periodicas nuevas.
            if(!ctype)NpbPer+=count;
            else NpfPer+=count;
          }
        }
      }
    }
  }
  Timersg->TmStop(TMG_SuPeriodic,true);
  Check_CudaErroor("Failed in creation of periodic particles.");
}

//==============================================================================
/// Executes divide of particles in cells.
/// Ejecuta divide de particulas en celdas.
//==============================================================================
void JSphGpuSingle::RunCellDivide(bool updateperiodic){
  //JDebugSphGpu::SaveVtk("_DG_Divide_Pre.vtk",Nstep,0,Np,"all",this);

  DivData=DivDataGpuNull();
  //-Creates new periodic particles and marks the old ones to be ignored.
  //-Crea nuevas particulas periodicas y marca las viejas para ignorarlas.
  if(updateperiodic && PeriActive)RunPeriodic();

  //-Initiates Divide.
  CellDivSingle->Divide(Npb,Np-Npb-NpbPer-NpfPer,NpbPer,NpfPer,BoundChanged
    ,Dcellg,Codeg,Posxyg,Poszg,Idpg,Timersg);
  DivData=CellDivSingle->GetCellDivData();

  //-Sorts particle data. | Ordena datos de particulas.
  Timersg->TmStart(TMG_NlSortData,false);
  {
    unsigned* idpg=ArraysGpu->ReserveUint();
    typecode* codeg=ArraysGpu->ReserveTypeCode();
    unsigned* dcellg=ArraysGpu->ReserveUint();
    double2*  posxyg=ArraysGpu->ReserveDouble2();
    double*   poszg=ArraysGpu->ReserveDouble();
    float4*   velrhopg=ArraysGpu->ReserveFloat4();
    //==== mdbc
    tsymatrix3d* sigmag = ArraysGpu->ReserveSymatrix3d();
    float* kplasticg = ArraysGpu->ReserveFloat();
    float* kplasticdkg = ArraysGpu->ReserveFloat();
    CellDivSingle->SortBasicArrays(Idpg,Codeg,Dcellg,Posxyg,Poszg,Velrhopg,idpg,codeg,dcellg,posxyg,poszg,velrhopg);
    //==== mdbc
    CellDivSingle->SortDataArrays(Sigmag, sigmag);
    CellDivSingle->SortDataArrays(Kplasticg, kplasticg);
    CellDivSingle->SortDataArrays(KplasticDkg, kplasticdkg);
    swap(Sigmag, sigmag);   ArraysGpu->Free(sigmag);
    swap(Kplasticg, kplasticg);   ArraysGpu->Free(kplasticg);
    swap(KplasticDkg, kplasticdkg); ArraysGpu->Free(kplasticdkg);
    if(HydroMech){
      float* porepressg=ArraysGpu->ReserveFloat();
      float* porepress0g=ArraysGpu->ReserveFloat();
      float* porepressrateg=ArraysGpu->ReserveFloat();
      float3* hydromechloadaceg=ArraysGpu->ReserveFloat3();
      CellDivSingle->SortDataArrays(PorePressg,porepressg);
      CellDivSingle->SortDataArrays(PorePress0g,porepress0g);
      CellDivSingle->SortDataArrays(PorePressRateg,porepressrateg);
      CellDivSingle->SortDataArrays(HydroMechLoadAceg,hydromechloadaceg);
      swap(PorePressg,porepressg);   ArraysGpu->Free(porepressg);
      swap(PorePress0g,porepress0g); ArraysGpu->Free(porepress0g);
      swap(PorePressRateg,porepressrateg); ArraysGpu->Free(porepressrateg);
      swap(HydroMechLoadAceg,hydromechloadaceg); ArraysGpu->Free(hydromechloadaceg);
    }
    //====    
    swap(Idpg,idpg);           ArraysGpu->Free(idpg);
    swap(Codeg,codeg);         ArraysGpu->Free(codeg);
    swap(Dcellg,dcellg);       ArraysGpu->Free(dcellg);
    swap(Posxyg,posxyg);       ArraysGpu->Free(posxyg);
    swap(Poszg,poszg);         ArraysGpu->Free(poszg);
    swap(Velrhopg,velrhopg);   ArraysGpu->Free(velrhopg);
  }
  if(PoroJg){
    double *scratch=ArraysGpu->ReserveDouble();
    CellDivSingle->SortDataArrays(PoroJg,scratch);
    swap(PoroJg,scratch);ArraysGpu->Free(scratch);
    scratch=ArraysGpu->ReserveDouble();
    CellDivSingle->SortDataArrays(PoroThetag,scratch);
    swap(PoroThetag,scratch);ArraysGpu->Free(scratch);
    if(PoroJPreg){
      scratch=ArraysGpu->ReserveDouble();
      CellDivSingle->SortDataArrays(PoroJPreg,scratch);
      swap(PoroJPreg,scratch);ArraysGpu->Free(scratch);
    }
  }
  if(TStep==STEP_Verlet){
    float4* velrhopg=ArraysGpu->ReserveFloat4();
    //==== mdbc
    tsymatrix3d* sigmag = ArraysGpu->ReserveSymatrix3d();
    CellDivSingle->SortDataArrays(SigmaM1g, sigmag);
    swap(SigmaM1g, sigmag);   ArraysGpu->Free(sigmag);
    float* kplasticm1g=ArraysGpu->ReserveFloat();
    CellDivSingle->SortDataArrays(KplasticM1g,kplasticm1g);
    swap(KplasticM1g,kplasticm1g); ArraysGpu->Free(kplasticm1g);
    //
    CellDivSingle->SortDataArrays(VelrhopM1g,velrhopg);
    swap(VelrhopM1g,velrhopg);   ArraysGpu->Free(velrhopg);
    if(HydroMech && PorePressM1g){
      float* porepressm1g=ArraysGpu->ReserveFloat();
      CellDivSingle->SortDataArrays(PorePressM1g,porepressm1g);
      swap(PorePressM1g,porepressm1g); ArraysGpu->Free(porepressm1g);
    }
  }
  else if(TStep==STEP_Symplectic && (PosxyPreg || PoszPreg || VelrhopPreg)){ //-In reality, only necessary in the corrector not the predictor step??? | En realidad solo es necesario en el divide del corrector, no en el predictor??? 
    if(!PosxyPreg || !PoszPreg || !VelrhopPreg)Run_Exceptioon("Symplectic data is invalid.") ;
    double2* posxyg=ArraysGpu->ReserveDouble2();
    double* poszg=ArraysGpu->ReserveDouble();
    float4* velrhopg=ArraysGpu->ReserveFloat4();
    CellDivSingle->SortDataArrays(PosxyPreg,PoszPreg,VelrhopPreg,posxyg,poszg,velrhopg);
    swap(PosxyPreg,posxyg);      ArraysGpu->Free(posxyg);
    swap(PoszPreg,poszg);        ArraysGpu->Free(poszg);
    swap(VelrhopPreg,velrhopg);  ArraysGpu->Free(velrhopg);
    //==== mdbc
    tsymatrix3d* sigmag = ArraysGpu->ReserveSymatrix3d();
    CellDivSingle->SortDataArrays(SigmaPreg, sigmag);
    swap(SigmaPreg, sigmag);   ArraysGpu->Free(sigmag);
    if(HydroMech && PorePressPreg){
      float* porepresspreg=ArraysGpu->ReserveFloat();
      CellDivSingle->SortDataArrays(PorePressPreg,porepresspreg);
      swap(PorePressPreg,porepresspreg); ArraysGpu->Free(porepresspreg);
    }
  }
  if(TVisco==VISCO_LaminarSPS){
    tsymatrix3f *spstaug=ArraysGpu->ReserveSymatrix3f();
    CellDivSingle->SortDataArrays(SpsTaug,spstaug);
    swap(SpsTaug,spstaug);  ArraysGpu->Free(spstaug);
  }
  if(UseNormals){
    float3* boundnormalg=ArraysGpu->ReserveFloat3();
    CellDivSingle->SortDataArrays(BoundNormalg,boundnormalg);
    swap(BoundNormalg,boundnormalg); ArraysGpu->Free(boundnormalg);
    if(MotionVelg){
      float3* motionvelg=ArraysGpu->ReserveFloat3();
      CellDivSingle->SortDataArrays(MotionVelg,motionvelg);
      swap(MotionVelg,motionvelg); ArraysGpu->Free(motionvelg);
    }
    if(BoundSlipModeg){
      byte* boundslipmodeg=ArraysGpu->ReserveByte();
      CellDivSingle->SortDataArrays(BoundSlipModeg,boundslipmodeg);
      swap(BoundSlipModeg,boundslipmodeg); ArraysGpu->Free(boundslipmodeg);
    }
    if(TangenVelg){
      float3* tangenvelg=ArraysGpu->ReserveFloat3();
      CellDivSingle->SortDataArrays(TangenVelg,tangenvelg);
      swap(TangenVelg,tangenvelg); ArraysGpu->Free(tangenvelg);
    }
  }

  //-Collect divide data. | Recupera datos del divide.
  Np=CellDivSingle->GetNpFinal();
  Npb=CellDivSingle->GetNpbFinal();
  NpbOk=Npb-CellDivSingle->GetNpbIgnore();

  //-Update PosCellg[] according to current position of particles.
  cusphs::UpdatePosCell(Np,Map_PosMin,PosCellSize,Posxyg,Poszg,PosCellg,NULL);

  //-Manages excluded particles fixed, moving and floating before aborting the execution.
  if(CellDivSingle->GetNpbOut())AbortBoundOut();

  //-Collect position of floating particles. | Recupera posiciones de floatings.
  if(CaseNfloat)cusph::CalcRidp(PeriActive!=0,Np-Npb,Npb,CaseNpb,CaseNpb+CaseNfloat,Codeg,Idpg,FtRidpg);
  if(HydroMech){
    ApplyPorePressureBoundaries();
    if(!PorePressPreg && PoreShepardRegularization && PoreShepardInterval && ((Nstep+1)%PoreShepardInterval)==0){
      if(DynamicPoreWall)ComputeDynamicPoreWallStateGpu();
      else InteractionPorePressureMdbcCorrection();
      ShepardRegularizePorePressure();
      if(DynamicPoreWall)ComputeDynamicPoreWallStateGpu();
      else InteractionPorePressureMdbcCorrection();
    }
  }
  Timersg->TmStop(TMG_NlSortData,false);

  //-Control of excluded particles (only fluid because excluded boundary are checked before).
  //-Gestion de particulas excluidas (solo fluid porque las boundary excluidas se comprueban antes).
  Timersg->TmStart(TMG_NlOutCheck,false);
  unsigned npfout=CellDivSingle->GetNpfOut();
  if(npfout){
    ParticlesDataDown(npfout,Np,true,false);
    AddParticlesOut(npfout,Idp,AuxPos,AuxVel,AuxRhop,Code);
  }
  Timersg->TmStop(TMG_NlOutCheck,true);
  BoundChanged=false;
}

//------------------------------------------------------------------------------
/// Manages excluded particles fixed, moving and floating before aborting the execution.
/// Gestiona particulas excluidas fixed, moving y floating antes de abortar la ejecucion.
//------------------------------------------------------------------------------
void JSphGpuSingle::AbortBoundOut(){
  const unsigned nboundout=CellDivSingle->GetNpbOut();
  //-Get data of excluded boundary particles.
  ParticlesDataDown(nboundout,Np,true,false);
  //-Shows excluded particles information and aborts execution.
  JSph::AbortBoundOut(Log,nboundout,Idp,AuxPos,AuxVel,AuxRhop,Code);
}

//==============================================================================
/// Interaction for force computation.
/// Interaccion para el calculo de fuerzas.
//==============================================================================
void JSphGpuSingle::Interaction_Forces(TpInterStep interstep){
  if(DynamicPoreWall){
    //-Same-stage state/C closure runs below through free-surface tracking.
  }
  else if(HydroMechNoWall)CheckHydroMechNoWallSupportGpu();
  else if(TBoundary==BC_MDBC){
    if(MdbcCorrector || interstep!=INTERSTEP_SymCorrector)MdbcBoundCorrection(); //-Boundary correction for mDBC.
  }
  else CdbcBoundCorrection(); //Corrected dummy boundary condition
  InterStep=interstep;
  if(HydroMech && (HydroMechTopLoadMode==HMLOAD_FlexibleConfinement || HydroMechTopLoadMode==HMLOAD_TopKernelBand))ConstantDataUp();
  PreInteraction_Forces();
  ComputeBoundaryDerivativeVelocity();
  ComputeFreeSurfaceTracking();
  unsigned *dynamicridpg=(DynamicPorePressure? PrepareDynamicPorePeriodicGpu(): NULL);
  if(HydroMech){
    ApplyFreeSurfacePorePressure();
    if(HydroMechTopLoadMode!=HMLOAD_FlexibleConfinement)ApplyHydroMechTopLoadAcceleration();
  }
  if(ArtificialStressg && PorosityFeedback)PrepareArtificialStress();
  float3 *dengradcorr=NULL;

  Timersg->TmStart(TMG_CfForces,true);
  const bool lamsps=(TVisco==VISCO_LaminarSPS);
  unsigned bsfluid=BlockSizes.forcesfluid;
  unsigned bsbound=BlockSizes.forcesbound;

  //-Interaction Fluid-Fluid/Bound & Bound-Fluid.
  const StInterParmsg parms=StrInterParmsg(Simulate2D
    ,Symmetry //<vs_syymmetry>
    ,TKernel,FtMode
    ,lamsps,TDensity,ShiftingMode
    ,TMdbc2
    ,Visco*ViscoBoundFactor,Visco
    ,bsbound,bsfluid,Np,Npb,NpbOk
    ,0,Nstep,DivData,Dcellg
    ,Posxyg,Poszg,PosCellg,Velrhopg,Idpg,Codeg
    ,FtoMasspg,SpsTaug,dengradcorr,CorrMatg,BoundModeg,BoundSlipModeg,TangenVelg
    ,MotionVelg,BoundNormalg,NoPenShiftg
    ,ViscDtg,Arg,Aceg,Deltag
    ,SpsGradvelg
    ,Sigmag,Rsigmag
    ,ArtificialStressg
    ,PorePressg,(DynamicPorePressure? NULL: PorePressRateg)
    ,FSTypeg,FSNormalg
    ,IsHydroMechDrainageActive()
    ,HydroMechLoadAceg
    ,HydroMechTopLoadRawg
    ,ShiftPosfsg
    ,NULL,NULL,BoundDerivativeVelg,PoroThetag,PorosityFeedback? PoroJg: NULL);
  cusph::Interaction_Forces(parms);
  if(SoilDamping)cusph::AddSoilDamping(Np,Npb,Codeg,Velrhopg,Aceg,(DynamicPorePressure? GetDynamicSoilDampingRate(): 0.f));
  NormalizeHydroMechTopBandLoad();
  if(HourglassGpu){
    if(interstep==INTERSTEP_SymPredictor)
      HourglassGpu->PredictorForce(Np,Npb,Idpg,Codeg,Posxyg,Poszg,Velrhopg,Kplasticg,Aceg,SymplecticDtPre,(PorosityFeedback? PoroJg: NULL));
    else HourglassGpu->CorrectorForce(Np,Npb,Idpg,Codeg,Aceg,(PorosityFeedback? PoroJg: NULL));
  }

  //-Interaction DEM Floating-Bound & Floating-Floating. //(DEM)
  if(UseDEM)cusph::Interaction_ForcesDem(BlockSizes.forcesdem,CaseNfloat
    ,DivData,Dcellg,FtRidpg,DemDatag,FtoMasspg,float(DemDtForce)
    ,PosCellg,Velrhopg,Codeg,Idpg,ViscDtg,Aceg,NULL);

  //-For 2D simulations always overrides the 2nd component (Y axis).
  //-Para simulaciones 2D anula siempre la 2nd componente.
  if(Simulate2D)cusph::Resety(Np-Npb,Npb,Aceg);
  if(DynamicPorePressure)ComputeDynamicPorePressureRateGpu(dynamicridpg);

  //-Computes Tau for Laminar+SPS.
  if(lamsps)cusph::ComputeSpsTau(Np,Npb,SpsSmag,SpsBlin,Velrhopg,SpsGradvelg,SpsTaug);

  //-Applies DDT.
  if(Deltag)cusph::AddDelta(Np-Npb,Deltag+Npb,Arg+Npb);//-Adds the Delta-SPH correction for the density. | Anhade correccion de Delta-SPH a Arg[]. 
  cudaDeviceSynchronize();
  Check_CudaErroor("Failed while executing kernels of interaction.");

  //-Calculates maximum value of ViscDt.
  if(Np)ViscDtMax=cusph::ReduMaxFloat(Np,0,ViscDtg,CellDivSingle->GetAuxMem(cusph::ReduMaxFloatSize(Np)));
  //-Calculates maximum value of Ace (periodic particles are ignored). ViscDtg is used like auxiliary memory.
  AceMax=ComputeAceMax(ViscDtg); 

  Timersg->TmStop(TMG_CfForces,true);
  Check_CudaErroor("Failed in reduction of viscdt.");
}

//==============================================================================
/// Calculates extrapolated data on boundary particles from fluid domain for mDBC.
/// Calcula datos extrapolados en el contorno para mDBC.
//==============================================================================
void JSphGpuSingle::MdbcBoundCorrection(){
  Timersg->TmStart(TMG_CfPreForces,false);
  const unsigned n=(UseNormalsFt? Np: NpbOk);
  if(BoundModeg)cudaMemset(BoundModeg,BMODE_DBC,sizeof(byte)*Np);
  const bool fastsingle=(MdbcFastSingle && !HydroMech);
  const TpSlipMode slipmode=(MdbcSlipModeByMk? MdbcSlipModeMax: SlipMode);
  cusph::Interaction_MdbcCorrection(TKernel,Simulate2D,slipmode,fastsingle
    ,n,CaseNbound,MdbcThreshold,DivData,Map_PosMin,Posxyg,Poszg,PosCellg,Codeg
    ,Idpg,BoundNormalg,MotionVelg,Velrhopg,Sigmag,BoundModeg,BoundSlipModeg,TangenVelg
    ,(HydroMech? PorePress0g: NULL),(HydroMech? PorePressg: NULL));
  Timersg->TmStop(TMG_CfPreForces,false);
}

//<vs_cdbc_ini>
//==============================================================================
/// Calculates interpolated data on boundary particles from fluid domain for cDBC.
/// Calcula datos extrapolados en el contorno para mDBC.
//==============================================================================
void JSphGpuSingle::CdbcBoundCorrection(){
  if(HydroMech)Run_Exceptioon("Hydromechanical wall boundaries require mDBC; cDBC correction is not supported.");
  Timersg->TmStart(TMG_CfPreForces,false);
  //unsigned n=Np;
  const unsigned n=(WithFloating? Np: NpbOk);
  const TpSlipMode slipmode=(MdbcSlipModeByMk? MdbcSlipModeMax: SlipMode);
  cusph::Interaction_CdbcCorrection(TKernel,Simulate2D,slipmode,n,CaseNbound,MdbcThreshold
    ,DivData,Posxyg,Poszg,Dcellg,PosCellg,Codeg,Idpg,MotionVelg,Velrhopg,Sigmag,BoundSlipModeg);
  Timersg->TmStop(TMG_CfPreForces,false);
}
//<vs_cdbc_end>

//==============================================================================
/// Returns the maximum value of  (ace.x^2 + ace.y^2 + ace.z^2) from Acec[].
/// Devuelve valor maximo de (ace.x^2 + ace.y^2 + ace.z^2) a partir de Acec[].
//==============================================================================
double JSphGpuSingle::ComputeAceMax(float *auxmem){
  const bool check=(PeriActive!=0 || InOut!=NULL);
  float acemax=0;
  const unsigned npf=Np-Npb;
  if(!check)cusph::ComputeAceMod(npf,Aceg+Npb,auxmem);//-Without periodic conditions. | Sin condiciones periodicas.
  else cusph::ComputeAceMod(npf,Codeg+Npb,Aceg+Npb,auxmem);//-With periodic conditions ignores the periodic particles. | Con condiciones periodicas ignora las particulas periodicas.
  if(npf)acemax=cusph::ReduMaxFloat(npf,0,auxmem,CellDivSingle->GetAuxMem(cusph::ReduMaxFloatSize(npf)));
  return(sqrt(double(acemax)));
}

//<vs_ddramp_ini>
//==============================================================================
/// Applies initial DDT ramp.
//==============================================================================
void JSphGpuSingle::RunInitialDDTRamp(){
  if(TimeStep<DDTRamp.x){
    if((Nstep%10)==0){//-DDTkh value is updated every 10 calculation steps.
      if(TimeStep<=DDTRamp.y)DDTkh=KernelSize * float(DDTRamp.z);
      else{
        const double tt=TimeStep-DDTRamp.y;
        const double tr=DDTRamp.x-DDTRamp.y;
        DDTkh=KernelSize * float(((tr-tt)/tr)*(DDTRamp.z-DDTValue)+DDTValue);
      }
      ConstantDataUp(); //-Updates value in constant memory of GPU.
    }
  }
  else{
    if(DDTkh!=DDTkhCte){
      CSP.ddtkh=DDTkh=DDTkhCte;
      ConstantDataUp();
    }
    DDTRamp.x=0;
  }
}//<vs_ddramp_end>

//==============================================================================
/// Particle interaction and update of particle data according to
/// the computed forces using the Verlet time stepping scheme.
///
/// Realiza interaccion y actualizacion de particulas segun las fuerzas 
/// calculadas en la interaccion usando Verlet.
//==============================================================================
double JSphGpuSingle::ComputeStep_Ver(){
  Interaction_Forces(INTERSTEP_Verlet);    //-Interaction.
  const double dt=DtVariable(true);        //-Calculate new dt.
  if(CaseNmoving)CalcMotion(dt);           //-Calculate motion for moving bodies.
  DemDtForce=dt;                           //(DEM)
  if(Shifting)RunShifting(dt);             //-Shifting.
  ComputeVerlet(dt);                       //-Update particles using Verlet (periodic particles become invalid).
  if(CaseNfloat)RunFloating(dt,false);     //-Control of floating bodies.
  PosInteraction_Forces();                 //-Free memory used for interaction.
  if(Damping)RunDamping(dt,Np,Npb,Posxyg,Poszg,Codeg,Velrhopg); //-Aplies Damping.
  if(RelaxZones)RunRelaxZone(dt);          //-Generate waves using RZ.
  return(dt);
}

//==============================================================================
/// Particle interaction and update of particle data according to
/// the computed forces using the Symplectic time stepping scheme.
///
/// Realiza interaccion y actualizacion de particulas segun las fuerzas 
/// calculadas en la interaccion usando Symplectic.
//==============================================================================
double JSphGpuSingle::ComputeStep_Sym(){
  const double dt=SymplecticDtPre;
  if(CaseNmoving)CalcMotion(dt);               //-Calculate motion for moving bodies.
  //-Predictor
  //-----------
  DemDtForce=dt*0.5f;                          //(DEM)
  Interaction_Forces(INTERSTEP_SymPredictor);  //-Interaction.
  const double ddt_p=DtVariable(false);        //-Calculate dt of predictor step.
  if(Shifting)RunShifting(dt*.5);              //-Shifting.
  ComputeSymplecticPre(dt);                    //-Apply Symplectic-Predictor to particles (periodic particles become invalid).
  if(HourglassGpu)HourglassGpu->PredictorUpdate(dt);
  if(CaseNfloat)RunFloating(dt*.5,true);       //-Control of floating bodies.
  PosInteraction_Forces();                     //-Free memory used for interaction.
  //-Corrector
  //-----------
  DemDtForce=dt;                               //(DEM)
  RunCellDivide(true);
  Interaction_Forces(INTERSTEP_SymCorrector);  //-Interaction.
  const double ddt_c=DtVariable(true);         //-Calculate dt of corrector step.
  if(Shifting)RunShifting(dt);                 //-Shifting.
  ComputeSymplecticCorr(dt);                   //-Apply Symplectic-Corrector to particles (periodic particles become invalid).
  if(HourglassGpu)HourglassGpu->CorrectorUpdate(Np,Npb,Idpg,Codeg,Posxyg,Poszg,Velrhopg,Kplasticg,dt,(PorosityFeedback? PoroJg: NULL));
  if(CaseNfloat)RunFloating(dt,false);         //-Control of floating bodies.
  PosInteraction_Forces();                     //-Free memory used for interaction.
  if(Damping)RunDamping(dt,Np,Npb,Posxyg,Poszg,Codeg,Velrhopg); //-Aplies Damping.
  if(RelaxZones)RunRelaxZone(dt);              //-Generate waves using RZ.

  SymplecticDtPre=min(ddt_p,ddt_c);            //-Calculate dt for next ComputeStep.
  if(HourglassGpu && !FixedDt)SymplecticDtPre=min(SymplecticDtPre,HourglassGpu->GetDtLimit());
  return(dt);
}

//==============================================================================
/// Updates information in FtObjs[] copying data from GPU.
/// Actualiza informacion en FtObjs[] copiando los datos en GPU.
//==============================================================================
void JSphGpuSingle::UpdateFtObjs(){
  if(FtCount && FtObjsOutdated){
    tdouble3 *fcen=FtoAuxDouble6;
    tfloat3  *fang=FtoAuxFloat15;
    tfloat3  *fvellin=fang+FtCount;
    tfloat3  *fvelang=fvellin+FtCount;
    tfloat3  *facelin=fvelang+FtCount;
    tfloat3  *faceang=facelin+FtCount;
    cudaMemcpy(fcen,FtoCenterg,sizeof(double3)*FtCount,cudaMemcpyDeviceToHost);
    cudaMemcpy(fang,FtoAnglesg,sizeof(float3) *FtCount,cudaMemcpyDeviceToHost);
    cudaMemcpy(fvellin,FtoVelAceg,sizeof(float3)*FtCount*4,cudaMemcpyDeviceToHost);
    for(unsigned cf=0;cf<FtCount;cf++){
      FtObjs[cf].center=fcen[cf];
      FtObjs[cf].angles=fang[cf];
      FtObjs[cf].fvel  =fvellin[cf];
      FtObjs[cf].fomega=fvelang[cf];
      FtObjs[cf].facelin=facelin[cf];
      FtObjs[cf].faceang=faceang[cf];
    }
  }
  FtObjsOutdated=false;
}

//==============================================================================
/// Applies imposed velocity.
/// Aplica velocidad predefinida.
//==============================================================================
void JSphGpuSingle::FtApplyImposedVel(float3 *ftoforcesresg)const{
  tfloat3 *ftoforcesresc=NULL;
  for(unsigned cf=0;cf<FtCount;cf++)if(!FtObjs[cf].usechrono && (FtLinearVel[cf]!=NULL || FtAngularVel[cf]!=NULL)){
    const tfloat3 v1=(FtLinearVel [cf]!=NULL? FtLinearVel [cf]->GetValue3f(TimeStep): TFloat3(FLT_MAX));
    const tfloat3 v2=(FtAngularVel[cf]!=NULL? FtAngularVel[cf]->GetValue3f(TimeStep): TFloat3(FLT_MAX));
    if(!ftoforcesresc && (v1!=TFloat3(FLT_MAX) || v2!=TFloat3(FLT_MAX))){
      //-Copies data on GPU memory to CPU memory.
      ftoforcesresc=FtoAuxFloat15;
      cudaMemcpy(ftoforcesresc,ftoforcesresg,sizeof(tfloat3)*FtCount*2,cudaMemcpyDeviceToHost);
    }
    unsigned cfpos=cf*2+1;
    if(v1.x!=FLT_MAX)ftoforcesresc[cfpos].x=v1.x;
    if(v1.y!=FLT_MAX)ftoforcesresc[cfpos].y=v1.y;
    if(v1.z!=FLT_MAX)ftoforcesresc[cfpos].z=v1.z;
    cfpos--;
    if(v2.x!=FLT_MAX)ftoforcesresc[cfpos].x=v2.x;
    if(v2.y!=FLT_MAX)ftoforcesresc[cfpos].y=v2.y;
    if(v2.z!=FLT_MAX)ftoforcesresc[cfpos].z=v2.z;
  }
  //-Updates data on GPU memory.
  if(ftoforcesresc!=NULL){
    cudaMemcpy(ftoforcesresg,ftoforcesresc,sizeof(tfloat3)*FtCount*2,cudaMemcpyHostToDevice);
  }
}

//==============================================================================
/// Process floating objects.
/// Procesa floating objects.
//==============================================================================
void JSphGpuSingle::RunFloating(double dt,bool predictor){
  Timersg->TmStart(TMG_SuFloating,false);
  if(TimeStep>=FtPause){//-Operator >= is used because when FtPause=0 in symplectic-predictor, code would not enter here. | Se usa >= pq si FtPause es cero en symplectic-predictor no entraria.
    
    //-Adds external forces (ForcePoints, Moorings, external file) to FtoForces[].
    if(ForcePoints!=NULL || FtLinearForce!=NULL){
      StFtoForces *ftoforces=(StFtoForces *)FtoAuxFloat15;
      memset(ftoforces,0,sizeof(StFtoForces)*FtCount);
      //-Loads sum of linear and angular forces from ForcePoints and Moorings.
      if(ForcePoints)ForcePoints->GetFtForcesSum(ftoforces);
      //-Adds the external forces.
      if(FtLinearForce!=NULL){
        for(unsigned cf=0;cf<FtCount;cf++){
          ftoforces[cf].face     =ftoforces[cf].face     +GetFtExternalForceLin(cf,TimeStep);
          ftoforces[cf].fomegaace=ftoforces[cf].fomegaace+GetFtExternalForceAng(cf,TimeStep);
        }
      }
      //-Copies data to GPU memory.
      cudaMemcpy(FtoForcesg,ftoforces,sizeof(StFtoForces)*FtCount,cudaMemcpyHostToDevice);
    }
    else{
      //-Initialises forces of floatings when no external forces are applied.
      cudaMemset(FtoForcesg,0,sizeof(StFtoForces)*FtCount);
    }

    //-Calculate forces summation (face,fomegaace) starting from floating particles and add in FtoForcesg[].
    cusph::FtCalcForcesSum(PeriActive!=0,FtCount,FtoDatpg,FtoCenterg,FtRidpg,Posxyg,Poszg,Aceg,FtoForcesg);

    //-Computes final acceleration from particles and from external forces in FtoForcesg[].
    cusph::FtCalcForces(FtCount,Gravity,FtoMassg,FtoAnglesg,FtoInertiaini8g,FtoInertiaini1g,FtoForcesg);
    
    //-Calculate data to update floatings / Calcula datos para actualizar floatings.
    cusph::FtCalcForcesRes(FtCount,Simulate2D,dt,FtoVelAceg,FtoCenterg,FtoForcesg,FtoForcesResg,FtoCenterResg);
    //-Applies imposed velocity.
    if(FtLinearVel!=NULL)FtApplyImposedVel(FtoForcesResg);
    //-Applies motion constraints.
    if(FtConstraints)cusph::FtApplyConstraints(FtCount,FtoConstraintsg,FtoForcesg,FtoForcesResg);
    
    //-Saves face and fomegace for debug.
    if(SaveFtAce){
      StFtoForces *ftoforces=(StFtoForces *)FtoAuxFloat15;
      cudaMemcpy(ftoforces,FtoForcesg,sizeof(tfloat3)*FtCount*2,cudaMemcpyDeviceToHost);
      SaveFtAceFun(dt,predictor,ftoforces);
    }

    //-Run floating with Chrono library.
    if(ChronoObjects){      
      Timersg->TmStop(TMG_SuFloating,false);
      Timersg->TmStart(TMG_SuChrono,false);
      //-Export data / Exporta datos.
      tfloat3* ftoforces=FtoAuxFloat15;
      cudaMemcpy(ftoforces,FtoForcesg,sizeof(tfloat3)*FtCount*2,cudaMemcpyDeviceToHost);
      for(unsigned cf=0;cf<FtCount;cf++)if(FtObjs[cf].usechrono){
        ChronoObjects->SetFtData(FtObjs[cf].mkbound,ftoforces[cf*2],ftoforces[cf*2+1]);
      }
      //-Applies the external velocities to each floating body of Chrono.
      if(FtLinearVel!=NULL)ChronoFtApplyImposedVel();
      //-Calculate data using Chrono / Calcula datos usando Chrono.
      ChronoObjects->RunChrono(Nstep,TimeStep,dt,predictor);
      //-Load calculated data by Chrono / Carga datos calculados por Chrono.
      tdouble3* ftocenter=FtoAuxDouble6;
      cudaMemcpy(ftocenter,FtoCenterResg,sizeof(tdouble3)*FtCount  ,cudaMemcpyDeviceToHost);//-Necesario para cargar datos de floatings sin chrono.
      cudaMemcpy(ftoforces,FtoForcesResg,sizeof(tfloat3) *FtCount*2,cudaMemcpyDeviceToHost);//-Necesario para cargar datos de floatings sin chrono.
      for(unsigned cf=0;cf<FtCount;cf++)if(FtObjs[cf].usechrono)ChronoObjects->GetFtData(FtObjs[cf].mkbound,ftocenter[cf],ftoforces[cf*2+1],ftoforces[cf*2]);
      cudaMemcpy(FtoCenterResg,ftocenter,sizeof(tdouble3)*FtCount  ,cudaMemcpyHostToDevice);
      cudaMemcpy(FtoForcesResg,ftoforces,sizeof(float3)  *FtCount*2,cudaMemcpyHostToDevice);
      Timersg->TmStop(TMG_SuChrono,false);
      Timersg->TmStart(TMG_SuFloating,false);
    }

    //-Apply movement around floating objects / Aplica movimiento sobre floatings.
    cusph::FtUpdate(PeriActive!=0,predictor,FtCount,dt,FtoDatpg,FtoForcesResg,FtoCenterResg
      ,FtRidpg,FtoCenterg,FtoAnglesg,FtoVelAceg,Posxyg,Poszg,Dcellg,Velrhopg,Codeg);

    //-Stores floating data.
    if(!predictor){
      FtObjsOutdated=true;
      //-Updates floating normals for mDBC.
      if(UseNormalsFt){
        tdouble3 *fcen=FtoAuxDouble6;
        tfloat3  *fang=FtoAuxFloat15;
        cudaMemcpy(fcen,FtoCenterg,sizeof(double3)*FtCount,cudaMemcpyDeviceToHost);
        cudaMemcpy(fang,FtoAnglesg,sizeof(float3) *FtCount,cudaMemcpyDeviceToHost);
        for(unsigned cf=0;cf<FtCount;cf++){
          const StFloatingData fobj=FtObjs[cf];
          FtObjs[cf].center=fcen[cf];
          FtObjs[cf].angles=fang[cf];
          const tdouble3 dang=ToTDouble3(FtObjs[cf].angles-fobj.angles)*TODEG;
          const tdouble3 cen=FtObjs[cf].center;
          JMatrix4d mat;
          mat.Move(cen);
          mat.Rotate(dang);
          mat.Move(fobj.center*-1);
          cusph::FtNormalsUpdate(fobj.count,fobj.begin-CaseNpb,mat.GetMatrix(),FtRidpg,BoundNormalg);
        }
      }
      //<vs_ftmottionsv_ini>
      if(FtMotSave && FtMotSave->CheckTime(TimeStep+dt)){
        UpdateFtObjs(); //-Updates floating information on CPU memory.
        FtMotSave->SaveFtDataGpu(TimeStep+dt,Nstep+1,FtObjs,Np,Posxyg,Poszg,FtRidpg);
      }
      //<vs_ftmottionsv_end>
    }
  }
  //-Update data of points in FtForces and calculates motion data of affected floatings.
  Timersg->TmStop(TMG_SuFloating,false);
  if(!predictor && ForcePoints){
    Timersg->TmStart(TMG_SuMoorings,false);
    UpdateFtObjs(); //-Updates floating information on CPU memory.
    ForcePoints->UpdatePoints(TimeStep,dt,FtObjs);
    if(Moorings)Moorings->ComputeForces(Nstep,TimeStep,dt,ForcePoints);
    ForcePoints->ComputeForcesSum();
    Timersg->TmStop(TMG_SuMoorings,false);
  }
}

//==============================================================================
/// Runs calculations in configured gauges.
/// Ejecuta calculos en las posiciones de medida configuradas.
//==============================================================================
void JSphGpuSingle::RunGaugeSystem(double timestep,bool saveinput){
  if(!Nstep || GaugeSystem->GetCount()){
    Timersg->TmStart(TMG_SuGauges,false);
    //const bool svpart=(TimeStep>=TimePartNext);
    GaugeSystem->CalculeGpu(timestep,DivData
      ,NpbOk,Npb,Np,Posxyg,Poszg,Codeg,Idpg,Velrhopg,Sigmag,saveinput);
    Timersg->TmStop(TMG_SuGauges,false);
  }
}

//==============================================================================
/// Compute PIPS information of current particles.
/// Calcula datos de PIPS de particulas actuales.
//==============================================================================
void JSphGpuSingle::ComputePips(bool run){
  if(run || DsPips->CheckRun(Nstep)){
    TimerSim.Stop();
    const double timesim=TimerSim.GetElapsedTimeD()/1000.;
    const unsigned sauxmemg=ArraysGpu->GetArraySize();
    unsigned* auxmemg=ArraysGpu->ReserveUint();
    DsPips->ComputeGpu(Nstep,TimeStep,timesim,Np,Npb,NpbOk
      ,DivData,Dcellg,PosCellg,sauxmemg,auxmemg);
    ArraysGpu->Free(auxmemg);
  }
}

//==============================================================================
/// Uses existing host boundary ID/code buffers for the single release; no new device kernel.
//==============================================================================
void JSphGpuSingle::RunGravityPreloadRelease(){
  if(!GravityPreload || GravityPreloadReleased || unsigned(Nstep)<GravityPreloadStep)return;
  if(unsigned(Nstep)!=GravityPreloadStep || PosxyPreg || PoszPreg || VelrhopPreg || SigmaPreg || PorePressPreg || PoroJPreg
    || !GravityPreloadIdCount || Np!=CaseNp || Npb!=CaseNpb || !Idp || !Code || CpuParticlesSize<Npb)
    Run_Exceptioon("gravitypreload release requires the complete native state between full steps.");
  Log->Printf("GravityPreload: release attempt requested=%.17g actual=%.17g completed_step=%u native_range=[%u,%u).",GravityPreloadTime,TimeStep,unsigned(Nstep),GravityPreloadIdBegin,GravityPreloadIdBegin+GravityPreloadIdCount);
  const unsigned oldnp=Np,oldnb=Npb;unsigned retired=0,kept=0;
  if(GravityPreloadKeepBedOverlap && (GravityPreloadBedIds.empty() || !BoundNormalg || !BoundSlipModeg))
    Run_Exceptioon("gravitypreload bed overlap requires its planned native IDs and boundary attributes.");
  cudaMemcpy(Idp,Idpg,sizeof(unsigned)*Npb,cudaMemcpyDeviceToHost);
  cudaMemcpy(Code,Codeg,sizeof(typecode)*Npb,cudaMemcpyDeviceToHost);
  Check_CudaErroor("Failed in gravitypreload boundary ID/code download.");
  for(unsigned p=0;p<Npb;p++)if(Idp[p]>=GravityPreloadIdBegin && Idp[p]-GravityPreloadIdBegin<GravityPreloadIdCount){
    if(!CODE_IsNormal(Code[p]) || !CODE_IsFixed(Code[p]))Run_Exceptioon("gravitypreload selected an invalid fixed native ID.");
    if(GravityPreloadKeepBedOverlap && IsGravityPreloadBedId(Idp[p])){
      //-Retain the fixed native slot and primary state; only its per-particle wall role changes.
      const tfloat3 normal=TFloat3(0,0,float(Dp));const byte slip=byte(SLIP_NoSlip);
      cudaMemcpy(BoundNormalg+p,&normal,sizeof(tfloat3),cudaMemcpyHostToDevice);
      cudaMemcpy(BoundSlipModeg+p,&slip,sizeof(byte),cudaMemcpyHostToDevice);
      kept++;
    }
    else{Code[p]=CODE_SetOutIgnore(Code[p]);retired++;}
  }
  if(GravityPreloadKeepBedOverlap){
    if(retired+kept!=GravityPreloadIdCount || kept!=unsigned(GravityPreloadBedIds.size()))
      Run_Exceptioon("gravitypreload bed overlap did not match its planned native ID roles.");
    Check_CudaErroor("Failed in gravitypreload retained bed attribute upload.");
  }
  else if(retired!=GravityPreloadIdCount)Run_Exceptioon("gravitypreload did not retire its entire native MK block.");
  cudaMemcpy(Codeg,Code,sizeof(typecode)*Npb,cudaMemcpyHostToDevice);
  Check_CudaErroor("Failed in gravitypreload boundary code upload.");
  SoilDamping=false;PoreShepardRegularization=false;ConstantDataUp();
  BoundChanged=true;RunCellDivide(true);
  if(Np!=oldnp-retired || Npb!=oldnb-retired || CellDivSingle->GetNpbOutIgnore()!=retired
    || CellDivSingle->GetNpbOut() || CellDivSingle->GetNpfOut() || CellDivSingle->GetNpfOutIgnore())
    Run_Exceptioon("gravitypreload divide changed particles beyond its intentional right-wall retirement.");
  NpMinimum-=retired; //-Remove only planned fixed samples; the original fluid-loss budget is unchanged.
  GravityPreloadActualTime=TimeStep;GravityPreloadActualStep=Nstep;GravityPreloadReleased=true;
  if(GravityPreloadKeepBedOverlap){
    std::string keptids;
    for(unsigned id:GravityPreloadBedIds){if(!keptids.empty())keptids+=",";keptids+=std::to_string(id);}
    Log->Printf("GravityPreload: release policy=KeepBedOverlap original_target=%u retired=%u kept_bed=%u kept_ids=%s; coordinates/IDs/fixed MK codes retained, bed normal=+DpZ NoSlip."
      ,GravityPreloadIdCount,retired,kept,keptids.c_str());
  }
  Log->Printf("GravityPreload: phase=released actual=%.17g completed_step=%u retired=%u; damping=OFF Shepard=OFF FreeSeepage=ON.",TimeStep,unsigned(Nstep),retired);
}

//==============================================================================
/// Imports one qualified elastic full-step PRE state; this is not PART restart.
//==============================================================================
void JSphGpuSingle::RunGravityPreloadHandoffGpu(){
  if(!IsGravityPreloadHandoff())return;
  JGravityPreloadState source;LoadGravityPreloadState(source);
  if(Np!=source.Count || Npb!=source.Fixed || CpuParticlesSize<Np || PosxyPreg || PoszPreg
    || VelrhopPreg || SigmaPreg || PorePressPreg || PoroJPreg)
    Run_Exceptioon("Gravity preload handoff requires the complete fresh full-step allocation.");
  ParticlesDataDown(Np,0,true,false);
  std::vector<tfloat3> normal(Np);std::vector<byte> slip(BoundSlipModeg? Np: 0);
  cudaMemcpy(normal.data(),BoundNormalg,sizeof(tfloat3)*Np,cudaMemcpyDeviceToHost);
  if(BoundSlipModeg)cudaMemcpy(slip.data(),BoundSlipModeg,sizeof(byte)*Np,cudaMemcpyDeviceToHost);
  Check_CudaErroor("Failed downloading fresh gravity preload wall attributes.");
  std::vector<typecode> codebyid(Np);std::vector<tfloat3> normalbyid(Np);
  std::vector<byte> slipbyid(slip.size());std::vector<bool> seen(Np,false);
  for(unsigned p=0;p<Np;p++){
    const unsigned id=Idp[p];
    if(id>=Np || seen[id] || !CODE_IsNormal(Code[p]))Run_Exceptioon("Invalid fresh native ID in gravity preload handoff.");
    seen[id]=true;codebyid[id]=Code[p];normalbyid[id]=normal[p];
    if(BoundSlipModeg)slipbyid[id]=slip[p];
    const unsigned s=source.ById[id];
    if(memcmp(PorePress0+p,&source.PorePress0[s],sizeof(float))
      || (CODE_IsFixed(Code[p]) && (Posxy[p].x!=source.Pos[s].x || Posxy[p].y!=source.Pos[s].y || Posz[p]!=source.Pos[s].z)))
      Run_Exceptioon("Gravity preload fixed geometry or initial P0 differs from the fresh input.");
  }
  //-Use the source's actual slot order, with static wall attributes from this fresh input.
  for(unsigned p=0;p<Np;p++){
    const unsigned id=source.Idp[p];Idp[p]=id;Code[p]=codebyid[id];normal[p]=normalbyid[id];
    if(BoundSlipModeg)slip[p]=slipbyid[id];
  }
  const auto copystate=[&](){
    for(unsigned p=0;p<Np;p++){
      const unsigned s=source.ById[Idp[p]];
      AuxPos[p]=source.Pos[s];Posxy[p]=TDouble2(AuxPos[p].x,AuxPos[p].y);Posz[p]=AuxPos[p].z;Velrhop[p]=source.VelRhop[s];
      const tdouble3 kk=source.SigmaKK[s],ij=source.SigmaIJ[s];
      Sigma[p]=TSymMatrix3d(kk.x,ij.x,ij.z,kk.y,ij.y,kk.z);
      Kplastic[p]=source.Kplastic[s];PorePress[p]=source.PorePress[s];PorePress0[p]=source.PorePress0[s];
      PoroJ[p]=source.J[s];PoroTheta[p]=source.Theta[s];
      AuxFSType[p]=source.FSType[s];AuxFSNormal[p]=source.FSNormal[s];AuxPosDiv[p]=source.PosDiv[s];
    }
    cudaMemcpy(Posxyg,Posxy,sizeof(tdouble2)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(Poszg,Posz,sizeof(double)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(Velrhopg,Velrhop,sizeof(tfloat4)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(Sigmag,Sigma,sizeof(tsymatrix3d)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(Kplasticg,Kplastic,sizeof(float)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(PorePressg,PorePress,sizeof(float)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(PorePress0g,PorePress0,sizeof(float)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(PoroJg,PoroJ,sizeof(double)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(PoroThetag,PoroTheta,sizeof(double)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(FSTypeg,AuxFSType,sizeof(unsigned)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(FSNormalg,AuxFSNormal,sizeof(tfloat3)*Np,cudaMemcpyHostToDevice);
    cudaMemcpy(PosDivg,AuxPosDiv,sizeof(float)*Np,cudaMemcpyHostToDevice);
    Check_CudaErroor("Failed restoring gravity preload primary/FS state.");
  };
  copystate();
  LoadDcellParticles(Np,Code,AuxPos,Dcell);
  cudaMemcpy(Idpg,Idp,sizeof(unsigned)*Np,cudaMemcpyHostToDevice);
  cudaMemcpy(Codeg,Code,sizeof(typecode)*Np,cudaMemcpyHostToDevice);
  cudaMemcpy(Dcellg,Dcell,sizeof(unsigned)*Np,cudaMemcpyHostToDevice);
  cudaMemcpy(BoundNormalg,normal.data(),sizeof(tfloat3)*Np,cudaMemcpyHostToDevice);
  if(BoundSlipModeg)cudaMemcpy(BoundSlipModeg,slip.data(),sizeof(byte)*Np,cudaMemcpyHostToDevice);
  Check_CudaErroor("Failed uploading gravity preload ownership/cell data.");
  const bool shepard=PoreShepardRegularization,freeseepage=HydroMechFreeSeepage;
  PoreShepardRegularization=false;HydroMechFreeSeepage=false;
  try{BoundChanged=true;RunCellDivide(true);}
  catch(...){PoreShepardRegularization=shepard;HydroMechFreeSeepage=freeseepage;throw;}
  PoreShepardRegularization=shepard;HydroMechFreeSeepage=freeseepage;
  if(Np!=source.Count || Npb!=source.Fixed || CellDivSingle->GetNpbOut() || CellDivSingle->GetNpfOut()
    || CellDivSingle->GetNpbOutIgnore() || CellDivSingle->GetNpfOutIgnore())
    Run_Exceptioon("Gravity preload handoff cell rebuild changed native ownership.");
  //-Divide updates real PosCell/cells. Refill by its new ID order without changing that cell order.
  cudaMemcpy(Idp,Idpg,sizeof(unsigned)*Np,cudaMemcpyDeviceToHost);
  Check_CudaErroor("Failed downloading gravity preload sorted native IDs.");
  copystate();
  cudaMemset(KplasticDkg,0,sizeof(float)*Np);cudaMemset(PorePressRateg,0,sizeof(float)*Np);
  Check_CudaErroor("Failed resetting recomputed gravity preload rate diagnostics.");
  RestoreGravityPreloadClock(source);
}

//==============================================================================
/// Initialises execution of simulation.
/// Inicia ejecucion de simulacion.
//==============================================================================
void JSphGpuSingle::Run(std::string appname,const JSphCfgRun *cfg,JLog2 *log){
  if(!cfg || !log)return;
  AppName=appname; Log=log; CfgRun=cfg;

  //-Selection of GPU.
  //-------------------
  SelecDevice(cfg->GpuId);

  //-Configures timers.
  //-------------------
  Timersg->Config(cfg->SvTimers);
  Timersg->TmStart(TMG_Init,false);

  //-Load parameters and values of input. | Carga de parametros y datos de entrada.
  //--------------------------------------------------------------------------------
  LoadConfig(cfg);
  LoadCaseParticles();
  VisuConfig();
  ConfigDomain();
  ConfigRunMode();
  VisuParticleSummary();

  //-Initialisation of execution variables. | Inicializacion de variables de ejecucion.
  //------------------------------------------------------------------------------------
  InitRunGpu();
  RunGravityPreloadHandoffGpu();
  RunGaugeSystem(TimeStep,true);
  if(InOut)InOutInit(TimeStepIni);
  FreePartsInit();
  UpdateMaxValues();
  PrintAllocMemory(GetAllocMemoryCpu(),GetAllocMemoryGpu());
  if(!IsGravityPreloadHandoff())SaveData();
  Timersg->ResetTimes();
  Timersg->TmStop(TMG_Init,false);
  if(Log->WarningCount())Log->PrintWarningList("\n[WARNINGS]","");
  if(!IsGravityPreloadHandoff()){PartNstep=-1;Part++;}

  //-Main Loop.
  //------------
  JTimeControl tc("30,60,300,600");//-Shows information at 0.5, 1, 5 y 10 minutes (before first PART).
  bool partoutstop=false;
  TimerSim.Start();
  TimerPart.Start();
  Log->Print(string("\n[Initialising simulation (")+RunCode+")  "+fun::GetDateTime()+"]");
  if(DsPips)ComputePips(true);
  PrintHeadPart();
  while(TimeStep<TimeMax){
    if(GravityPreload && !GravityPreloadReleased)RunGravityPreloadRelease();
    InterStep=(TStep==STEP_Symplectic? INTERSTEP_SymPredictor: INTERSTEP_Verlet);
    if(ViscoTime)Visco=ViscoTime->GetVisco(float(TimeStep));
    if(DDTRamp.x)RunInitialDDTRamp(); //<vs_ddramp>
    double stepdt=ComputeStep();
    RunGaugeSystem(TimeStep+stepdt);
    if(CaseNmoving)RunMotion(stepdt);
    if(InOut)InOutComputeStep(stepdt);
    else RunCellDivide(true);
    TimeStep+=stepdt;
    LastDt=stepdt;
    partoutstop=(Np<NpMinimum || !Np);
    //-Retain the final native state even when TimeMax is between output events.
    if(TimeStep>=TimePartNext || partoutstop || TimeStep>=TimeMax || (NstepsBreak && Nstep+1>=NstepsBreak)
      || (GravityPreload && !GravityPreloadReleased && unsigned(Nstep+1)==GravityPreloadStep)){
      if(partoutstop){
        Log->PrintWarning("Particles OUT limit reached...");
        TimeMax=TimeStep;
      }
      SaveData();
      Part++;
      PartNstep=Nstep;
      TimeStepM1=TimeStep;
      TimePartNext=(SvAllSteps? TimeStep: OutputTime->GetNextTime(TimeStep));
      TimerPart.Start();
    }
    UpdateMaxValues();
    Nstep++;
    const bool laststep=(TimeStep>=TimeMax || (NstepsBreak && Nstep>=NstepsBreak));
    if(DsPips)ComputePips(laststep);
    if(Part<=PartIni+1 && tc.CheckTime())Log->Print(string("  ")+tc.GetInfoFinish((TimeStep-TimeStepIni)/(TimeMax-TimeStepIni)));
    if(NstepsBreak && Nstep>=NstepsBreak)break; //-For debugging.
  }
  TimerSim.Stop(); TimerTot.Stop();

  //-End of Simulation.
  //--------------------
  FinishRun(partoutstop);
}

//==============================================================================
/// Generates files with output data.
/// Genera los ficheros de salida de datos.
//==============================================================================
void JSphGpuSingle::SaveData(){
  const bool save=(SvData!=SDAT_None && SvData!=SDAT_Info);
  const unsigned npsave=Np-NpbPer-NpfPer; //-Subtracts the periodic particles if they exist. | Resta las periodicas si las hubiera.
  //-Retrieves particle data from the GPU. | Recupera datos de particulas en GPU.
  if(save){
    ComputeFreeSurfaceTracking();
    Timersg->TmStart(TMG_SuDownData,false);
    unsigned npnormal=ParticlesDataDown(Np,0,false,PeriActive!=0);
    if(npnormal!=npsave)Run_Exceptioon("The number of particles is invalid.");
    Timersg->TmStop(TMG_SuDownData,false);
  }
  //-Retrieve floating object data from the GPU. | Recupera datos de floatings en GPU.
  if(FtCount){
    Timersg->TmStart(TMG_SuDownData,false);
    UpdateFtObjs();
    Timersg->TmStop(TMG_SuDownData,false);
  }
  //-Collects additional information. | Reune informacion adicional.
  Timersg->TmStart(TMG_SuSavePart,false);
  StInfoPartPlus infoplus;
  memset(&infoplus,0,sizeof(StInfoPartPlus));
  if(SvData&SDAT_Info){
    infoplus.nct=CellDivSingle->GetNct();
    infoplus.npbin=NpbOk;
    infoplus.npbout=Npb-NpbOk;
    infoplus.npf=Np-Npb;
    infoplus.npbper=NpbPer;
    infoplus.npfper=NpfPer;
    infoplus.newnp=(InOut? InOut->GetNewNpPart(): 0);
    infoplus.memorycpualloc=this->GetAllocMemoryCpu();
    infoplus.gpudata=true;
    infoplus.memorynctalloc=infoplus.memorynctused=GetMemoryGpuNct();
    infoplus.memorynpalloc=infoplus.memorynpused=GetMemoryGpuNp();
    TimerSim.Stop();
    infoplus.timesim=TimerSim.GetElapsedTimeD()/1000.;
  }
  //-Obtains current domain limits.
  const tdouble3 vdom[2]={CellDivSingle->GetDomainLimits(true),CellDivSingle->GetDomainLimits(false)};
  //-Stores particle data. | Graba datos de particulas.
  JDataArrays arrays;
  AddBasicArrays(arrays,npsave,AuxPos,Idp,AuxVel,AuxRhop,AuxSigma_xx_yy_zz,AuxSigma_xy_yz_xz,AuxKplastic);
  if(save){
    //-Preserve double stress state; legacy float arrays remain for display.
    tdouble3 *sigmastatekk=new tdouble3[npsave];
    tdouble3 *sigmastateij=new tdouble3[npsave];
    for(unsigned p=0;p<npsave;p++){
      const tsymatrix3d s=Sigma[p];
      sigmastatekk[p]=TDouble3(s.xx,s.yy,s.zz);
      sigmastateij[p]=TDouble3(s.xy,s.yz,s.xz);
    }
    arrays.AddArray("SigmaState_kk",npsave,sigmastatekk,true);
    arrays.AddArray("SigmaState_ij",npsave,sigmastateij,true);
    arrays.AddArray("FSType",npsave,AuxFSType);
    arrays.AddArray("FSNormal",npsave,AuxFSNormal);
    if(PorosityObserver){
      double *porosity=new double[npsave];
      for(unsigned p=0;p<npsave;p++)
        porosity[p]=(HydroMechDynamicSeepage && Idp[p]<CaseNpb? 0.: 1.-(1.-double(SoilCte.Porosity))/PoroJ[p]);
      arrays.AddArray("PoroVolumeRatio",npsave,PoroJ);
      arrays.AddArray("PoroPorosity",npsave,porosity,true);
      arrays.AddArray("PoroThetaLastStage",npsave,PoroTheta);
      if(HydroMechDynamicSeepage){
        arrays.AddArray("PosDiv",npsave,AuxPosDiv);
        double *volume=new double[npsave],*density=new double[npsave],*conductivity=new double[npsave];
        const double k0=SoilCte.HydraulicConductivity;
        for(unsigned p=0;p<npsave;p++){
          //-Derive output from the same compacted saved J, not from a working GPU slot.
          const bool soil=(Idp[p]>=CaseNpb);
          volume[p]=(soil? double(MassFluid)/double(RhopZero)*PoroJ[p]: 0.);
          density[p]=(soil? double(SoilCte.PoreWaterRho)+(double(RhopZero)-double(SoilCte.PoreWaterRho))/PoroJ[p]: 0.);
          conductivity[p]=(soil? (DynamicPoreConductivity && k0>0 && PoroJ[p]!=1.?
            k0*exp((PoroJ[p]-1.)/((1.-double(SoilCte.Porosity))*DynamicPoreConductivityCk)): k0): 0.);
          if(!std::isfinite(conductivity[p]) || (soil && k0>0 && conductivity[p]<=0))
            Run_Exceptioon("Saved dynamic conductivity left its finite positive domain.");
        }
        arrays.AddArray("PoroCurrentVolume",npsave,volume,true);
        arrays.AddArray("PoroMixtureDensity",npsave,density,true);
        arrays.AddArray("PoroHydraulicConductivity",npsave,conductivity,true);
      }
    }
  }
  if(save && HydroMech && AuxPorePress && AuxPorePress0){
    float *poreexcess=new float[npsave];
    for(unsigned p=0;p<npsave;p++)poreexcess[p]=AuxPorePress[p]-AuxPorePress0[p];
    arrays.AddArray("PorePress",npsave,AuxPorePress);
    arrays.AddArray("PorePress0",npsave,AuxPorePress0);
    arrays.AddArray("ExcessPorePress",npsave,poreexcess,true);
    if(AuxHydroMechLoadAce)arrays.AddArray("HydroMechLoadAce",npsave,AuxHydroMechLoadAce);
  }
  JSph::SaveData(npsave,arrays,1,vdom,&infoplus);
  if(UseNormals && SvNormals)SaveVtkNormalsGpu("normals/Normals.vtk",Part,npsave,Npb,Posxyg,Poszg,Idpg,BoundNormalg);
  //-Save extra data.
  if(SvExtraDataBi4)SaveExtraData();
  if(KplasticDkg)cudaMemset(KplasticDkg,0,sizeof(float)*Np);
  Timersg->TmStop(TMG_SuSavePart,false);
}

//==============================================================================
/// Displays and stores final summary of the execution.
/// Muestra y graba resumen final de ejecucion.
//==============================================================================
void JSphGpuSingle::SaveExtraData(){
  const bool svextra=(BoundNormalg!=NULL);
  if(svextra && SvExtraDataBi4->CheckSave(Part)){
    SvExtraDataBi4->InitPartData(Part,TimeStep,Nstep);
    //-Saves normals of mDBC.
    unsigned *idp =NULL;
    tfloat3  *nor =NULL;
    typecode *code=NULL;
    if(BoundNormalg){
      const unsigned nsize=(UseNormalsFt? Np: Npb);
      idp=fcuda::ToHostUint  (0,nsize,Idpg);
      nor=fcuda::ToHostFloat3(0,nsize,BoundNormalg);
      if(PeriActive){
        #ifdef CODE_SIZE4
          code=fcuda::ToHostUint(0,nsize,Codeg);
        #else
          code=fcuda::ToHostWord(0,nsize,Codeg);
        #endif
      }
      SvExtraDataBi4->AddNormals(UseNormalsFt,Np,Npb,idp,code,nor);
    }
    //-Saves file.
    SvExtraDataBi4->SavePartData();
    //-Free memory.
    delete[] idp;  idp=NULL;
    delete[] nor;  nor=NULL;
    delete[] code; code=NULL;
  }
}

//==============================================================================
/// Displays and stores final summary of the execution.
/// Muestra y graba resumen final de ejecucion.
//==============================================================================
void JSphGpuSingle::FinishRun(bool stop){
  float tsim=TimerSim.GetElapsedTimeF()/1000.f,ttot=TimerTot.GetElapsedTimeF()/1000.f;
  JSph::ShowResume(stop,tsim,ttot,true,"");
  if(HourglassGpu){
    const auto& hg=HourglassGpu->GetStats();
    Log->Printf("SoilHourglass: forcecalls=%u predictorupdates=%u correctorupdates=%u ratecalls=%u",
      hg.forcecalls,hg.predictorupdates,hg.correctorupdates,hg.ratecalls);
    Log->Printf("SoilHourglass: ratecalculations=%u endpoint_rate_reuses=%u",
      hg.ratecalculations,hg.ratecachehits);
    Log->Printf((PorosityFeedback?
      "SoilHourglass: max|sum(M0*Href)|=%g max|sum(mi*deltaAce)|=%g max(dt/tau)=%g spinbound=%g":
      "SoilHourglass: max|sum(m*H)|=%g max|sum(m*deltaAce)|=%g max(dt/tau)=%g spinbound=%g"),
      hg.maxnetforce,hg.maxactualnetforce,hg.maxtauratio,hg.spinbound);
  }
  Log->Print(" ");
  string hinfo,dinfo;
  if(SvTimers){
    Timersg->ShowTimes("[GPU Timers]",Log);
    Timersg->GetTimersInfo(hinfo,dinfo);
  }
  if(SvRes)SaveRes(tsim,ttot,hinfo,dinfo);
  Log->PrintFilesList();
  Log->PrintWarningList();
  VisuRefs();
}

