//HEAD_DSPH
/*
 <DUALSPHYSICS>  Copyright (c) 2020 by Dr Jose M. Dominguez et al. (see http://dual.sphysics.org/index.php/developers/). 

 EPHYSLAB Environmental Physics Laboratory, Universidade de Vigo, Ourense, Spain.
 School of Mechanical, Aerospace and Civil Engineering, University of Manchester, Manchester, U.K.

 This file is part of DualSPHysics. 

 DualSPHysics is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License 
 as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version.
 
 DualSPHysics is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details. 

 You should have received a copy of the GNU Lesser General Public License along with DualSPHysics. If not, see <http://www.gnu.org/licenses/>. 
*/

/// \file JSphGpu.cpp \brief Implements the class \ref JSphGpu.

#include "JSphGpu.h"
#include "JException.h"
#include "JSphGpu_ker.h"
#include "JSphGpuSimple_ker.h"
#include "JCellDivGpu.h"
#include "JDsGpuInfo.h"
#include "JPartFloatBi4.h"
#include "Functions.h"
#include "FunctionsCuda.h"
#include "JDsMotion.h"
#include "JArraysGpu.h"
#include "JDsFixedDt.h"
#include "JDsSaveDt.h"
#include "JDsOutputTime.h"
#include "JWaveGen.h"
#include "JMLPistons.h"
#include "JRelaxZones.h"
#include "JChronoObjects.h"
#include "JDsFtForcePoints.h"
#include "JDsDamping.h"
#include "JDsAccInput.h"
#include "JXml.h"
#include "JDsGaugeSystem.h"
#include "JSphInOut.h"
#include "JSphShifting.h"
#include "JDataArrays.h"
#include "JVtkLib.h"

#include <cfloat>
#include <climits>
#include <cmath>
#include <limits>
#ifdef C08_STAGE_TRACE
#include "C08StageTrace.h"
#include <fstream>
#include <iomanip>
#include <stdexcept>
#endif

using namespace std;

namespace{
  inline bool IsHydroMechTrackedFreeSurface(unsigned fstype){
    return(fstype==FST_FreeSurface || fstype==FST_Isolated);
  }
}

#ifdef C08_STAGE_TRACE
#ifdef C08_CAUSAL_TRACE
namespace{
  bool C08CausalRange(unsigned step){return step>=4000000 && step<4360000;}
  bool C08CausalSelected(unsigned step){
    return C08CausalRange(step) && (!(step%40) || (step>=4316000 && step<4324000) || (step>=4332000 && step<4340000));
  }
  bool C08TraceBegin(unsigned step,double time,unsigned interstep,double dtstate,double dtop,unsigned phase
    ,const unsigned *idp,const unsigned *fstype,const float *rate,const tsymatrix3f *rsigma=NULL){
    if(!C08CausalSelected(step))return false;
    if(phase==C08_TRACE_RHS && !rsigma)throw std::runtime_error("C08_CAUSAL_TRACE observation: actual stress-rate pointer missing.");
    C08StageTraceContext context={1,phase,step,interstep,time,dtstate,dtop,idp,fstype,rate};context.rsigma=rsigma;context.emit=1;
    if(!cusph::C08StageTraceStart(context))throw std::runtime_error("C08_CAUSAL_TRACE observation: interaction buffer setup failed.");
    return true;
  }
  bool C08CausalBegin(unsigned step,double time,unsigned interstep,double dtstate,double dtop,unsigned phase
    ,const unsigned *idp,const unsigned *fstype,const float *rate,const float *pressure,const float *oldpressure
    ,const double *jbase,const double *jstage,const double *theta){
    if(!C08CausalRange(step))return false;
    if(!idp || !fstype || !rate || !pressure || !oldpressure || !jstage || !theta
      || (!jbase && !(phase==C08_TRACE_PLANE && interstep==3)))
      throw std::runtime_error("C08_CAUSAL_TRACE observation: actual pressure/J stage pointers missing.");
    C08StageTraceContext context={1,phase,step,interstep,time,dtstate,dtop,idp,fstype,rate};
    context.porepress=pressure;context.poreold=oldpressure;context.jbase=jbase;context.jstage=jstage;context.theta=theta;
    context.emit=C08CausalSelected(step);
    if(!cusphs::C08CausalTraceStart(context))throw std::runtime_error("C08_CAUSAL_TRACE observation: simple-TU buffer setup failed.");
    return context.emit!=0; //-Unselected stages still ran the cumulative device observer.
  }
  void C08TraceEnd(bool selected,const std::string& dirout,bool simple=false){
    if(!selected)return;
    C08StageTraceRecord records[3];
    if(!(simple? cusphs::C08CausalTraceRead(records): cusph::C08StageTraceRead(records)))
      throw std::runtime_error("C08_CAUSAL_TRACE observation: CUDA record copy/disable failed.");
    const unsigned wanted[3]={7011,7012,6230};
    for(unsigned q=0;q<3;q++)if(records[q].hits!=1 || records[q].native_id!=wanted[q] || (simple && records[q].cumulative.errors))
      throw std::runtime_error("C08_CAUSAL_TRACE observation: missing/duplicate ID or invalid cumulative linkage.");
    static std::ofstream file;static std::string boundpath;
    const std::string path=fun::GetDirWithSlash(dirout)+"C08CausalTrace.csv";
    if(!file.is_open()){
      std::string normal=path;for(char& c:normal)if(c=='\\')c='/';
      if(normal.find("/tests/outputs/")==std::string::npos || fun::FileExists(path))
        throw std::runtime_error("C08_CAUSAL_TRACE observation: fresh tests/outputs CSV required.");
      boundpath=path;file.open(path);file<<std::setprecision(17);
      file<<"step_start_s,nstep,interstep,event,stored_dt_s,operator_dt_s,native_id,hits,FSType,p_before_Pa,p_after_Pa,rate_before_Pa_s,rate_after_Pa_s,J,n,theta,ki,LP,divAce,lap,chain,value_double";
      for(const char* prefix:{"pos","FSNormal"})for(unsigned c=0;c<3;c++)file<<','<<prefix<<c;
      for(unsigned c=0;c<9;c++)file<<",C"<<c;
      for(const char* prefix:{"finishedAce","Lx","Gp","GpCorr","GJ"})for(unsigned c=0;c<3;c++)file<<','<<prefix<<c;
      file<<",raw_FS_branch,drainfs,closedfs,freeseepage,ponding_changed,material_status,material_commit,base_I_Pa,trial_I_Pa,returned_I_Pa,kappa_old,kappa_candidate,kappa_saved,trace_drop_roundoff_budget_Pa,actual_bulk_modulus_Pa,trial_update_identity_Pa,trial_update_roundoff_budget_Pa";
      for(const char* c:{"xx","yy","zz","xy","yz","xz"})file<<",sigma_rate_"<<c;
      file<<",sigma_rate_trace,Jbase,Jhalf,Jnew,stage_theta,pressure_base_Pa";
      for(const char* prefix:{"move_before","move_after","velocity_before","velocity_after"})for(unsigned c=0;c<3;c++)file<<','<<prefix<<c;
      file<<",plane_hit_x,plane_hit_z,plane_velocity_clamp_x,plane_velocity_clamp_z\n";
    }
    if(boundpath!=path)throw std::runtime_error("C08_CAUSAL_TRACE observation: one output path per process required.");
    for(const auto& r:records){
      const bool rhs=r.context.phase==C08_TRACE_RHS,material=r.context.phase==C08_TRACE_MATERIAL,plane=r.context.phase==C08_TRACE_PLANE;
      file<<r.context.time<<','<<r.context.nstep<<','<<r.context.interstep<<','<<r.context.phase<<','<<r.context.dt_state<<','<<r.context.dt_operator<<','<<r.native_id<<','<<r.hits<<','<<r.fstype<<','<<r.p_before<<','<<r.p_after<<','<<r.rate_before<<','<<r.rate_after;
      const auto number=[&](double v,bool applicable){file<<',';if(applicable)file<<v;};
      for(double v:{r.J,r.n,r.theta,r.ki,r.lp,r.da,r.lap,r.chain,r.value})number(v,rhs);
      for(const double* a:{r.pos,r.fsnormal})for(unsigned c=0;c<3;c++)number(a[c],rhs);
      for(double v:r.C)number(v,rhs);
      for(const double* a:{r.Ace,r.lx,r.gp,r.gpcorr,r.gJ})for(unsigned c=0;c<3;c++)number(a[c],rhs);
      for(unsigned v:{r.raw_fs,r.drainfs,r.closedfs,r.freeseepage})number(v,rhs);
      number(r.projected,r.context.phase==C08_TRACE_PONDING);
      number(r.material_status,material);number(r.material_commit,material);number(r.base_I,material);number(r.trial_I,material);
      number(r.returned_I,material && r.material_commit);
      for(double v:{r.kappa_old,r.kappa_candidate,r.kappa_saved,r.trace_drop_budget})number(v,material);
      number(r.modulus_K,rhs||material);number(r.trial_update_residual,material);number(r.trial_update_budget,material);
      for(double v:r.sigma_rate)number(v,rhs||material);number(r.sigma_rate_trace,rhs||material);
      number(r.jbase,material||plane);number(r.jhalf,material||plane);number(r.jnew,plane && r.context.interstep==3);
      number(r.stage_theta,material||plane);number(r.pressure_base,material||plane);
      for(const double* a:{r.move_before,r.move_after,r.velocity_before,r.velocity_after})for(unsigned c=0;c<3;c++)number(a[c],plane);
      for(unsigned v:r.plane_hit)number(v,plane);for(unsigned v:r.plane_velocity_clamp)number(v,plane);file<<'\n';
    }
    file.flush();if(!file)throw std::runtime_error("C08_CAUSAL_TRACE observation: CSV write failed.");
  }
  void C08CausalSaveTotals(const std::string& dirout){
    C08CausalTotals totals[3];
    if(!cusphs::C08CausalTraceTotals(totals))throw std::runtime_error("C08_CAUSAL_TRACE observation: cumulative copy failed.");
    const unsigned count=totals[0].material_cor;if(!count)return;
    static unsigned previous=0;static std::ofstream file;static std::string boundpath;
    const unsigned wanted[3]={7011,7012,6230};
    for(unsigned q=0;q<3;q++){
      const auto& c=totals[q];unsigned pre=0,cor=0;for(unsigned k=0;k<8;k++){pre+=c.status_pre[k];cor+=c.status_cor[k];}
      if(c.native_id!=wanted[q] || c.errors || c.pending_valid || c.material_cor!=count || c.material_pre!=count
        || c.plane_pre!=count || c.plane_cor!=count || pre!=count || cor!=count || count>360000
        || c.pending_step!=4000000+count-1)throw std::runtime_error("C08_CAUSAL_TRACE observation: incomplete cumulative Cor/plane/ID coverage.");
    }
    if(count<previous)throw std::runtime_error("C08_CAUSAL_TRACE observation: cumulative count regressed.");
    if(count==previous)return;
    const std::string path=fun::GetDirWithSlash(dirout)+"C08CausalTotals.csv";
    if(!file.is_open()){
      std::string normal=path;for(char& c:normal)if(c=='\\')c='/';
      if(normal.find("/tests/outputs/")==std::string::npos || fun::FileExists(path))throw std::runtime_error("C08_CAUSAL_TRACE observation: fresh cumulative CSV required.");
      boundpath=path;file.open(path);file<<std::setprecision(17);
      file<<"completed_step,native_id,last_step_start_s,last_operator_dt_s,sum_cor_dt_s,material_pre_count,material_cor_count,plane_pre_count,plane_cor_count,errors";
      for(const char* stage:{"pre","cor"})for(unsigned k=0;k<8;k++)file<<",status_"<<stage<<k;
      for(const char* stage:{"pre","cor"})for(const char* axis:{"x","z"})file<<",plane_hit_"<<stage<<'_'<<axis;
      for(const char* stage:{"pre","cor"})for(const char* axis:{"x","z"})file<<",velocity_clamp_"<<stage<<'_'<<axis;
      file<<",sum_cor_dt_rsigma_trace_Pa,sum_cor_trial_minus_returned_I_Pa,sum_cor_abs_trace_drop_Pa,sum_cor_local_trace_budget_Pa,trace_drop_sum_roundoff_budget_Pa,sum_cor_log_Jnew_over_Jbase,sum_cor_dt_theta,initial_I_Pa,last_returned_I_Pa,actual_bulk_modulus_Pa,base_trace_changes,sum_cor_trial_update_identity_Pa,sum_cor_local_trial_update_budget_Pa,sum_cor_abs_dt_rsigma_trace_Pa,endpoint_trace_closure_Pa,endpoint_trace_roundoff_budget_Pa";
      for(const char* stage:{"pre","cor"})for(unsigned k=0;k<3;k++)file<<",sum_delta_v_"<<stage<<k;
      file<<"\n";
    }
    if(boundpath!=path)throw std::runtime_error("C08_CAUSAL_TRACE observation: cumulative output path changed.");
    for(const auto& c:totals){
      file<<c.pending_step+1<<','<<c.native_id<<','<<c.last_time<<','<<c.last_dt<<','<<c.cor_dt<<','<<c.material_pre<<','<<c.material_cor<<','<<c.plane_pre<<','<<c.plane_cor<<','<<c.errors;
      for(unsigned v:c.status_pre)file<<','<<v;for(unsigned v:c.status_cor)file<<','<<v;
      for(unsigned v:c.hit_pre)file<<','<<v;for(unsigned v:c.hit_cor)file<<','<<v;
      for(unsigned v:c.velocity_clamp_pre)file<<','<<v;for(unsigned v:c.velocity_clamp_cor)file<<','<<v;
      const double u=DBL_EPSILON*.5,gamma=(double(count)*u)/(1.-double(count)*u);
      const double budget=c.cor_trace_drop_local_budget+gamma*(c.cor_abs_trace_drop+c.cor_trace_drop_local_budget);
      for(double v:{c.cor_dt_rsigma_trace,c.cor_trace_drop,c.cor_abs_trace_drop,c.cor_trace_drop_local_budget,budget,c.cor_log_j_ratio,c.cor_dt_theta})file<<','<<v;
      const double endpoint=(c.cor_dt_rsigma_trace-c.cor_trace_drop)-(c.last_returned_I-c.initial_I);
      const double local=c.cor_trial_update_local_budget+c.cor_trace_drop_local_budget;
      const double gamma4=(4.*u)/(1.-4.*u);
      const double endpointbudget=local+gamma*(c.cor_abs_dt_rsigma_trace+c.cor_abs_trace_drop+local)
        +gamma4*(fabs(c.cor_dt_rsigma_trace)+fabs(c.cor_trace_drop)+fabs(c.last_returned_I)+fabs(c.initial_I));
      for(double v:{c.initial_I,c.last_returned_I,c.modulus_K,double(c.base_trace_changes),c.cor_trial_update_residual,c.cor_trial_update_local_budget,c.cor_abs_dt_rsigma_trace,endpoint,endpointbudget})file<<','<<v;
      for(double v:c.delta_v_pre)file<<','<<v;for(double v:c.delta_v_cor)file<<','<<v;file<<'\n';
    }
    file.flush();if(!file)throw std::runtime_error("C08_CAUSAL_TRACE observation: cumulative CSV write failed.");previous=count;
  }
}
#else
namespace{
  bool C08TraceBegin(unsigned step,double time,unsigned interstep,double dtstate,double dtop,unsigned phase
    ,const unsigned *idp,const unsigned *fstype,const float *rate){
    if(step<4000000 || step>=4264000 || (step<4240000 && step%40))return false;
    const C08StageTraceContext context={1,phase,step,interstep,time,dtstate,dtop,idp,fstype,rate};
    if(!cusph::C08StageTraceStart(context))throw std::runtime_error("C08_STAGE_TRACE observation: CUDA context/buffer setup failed.");
    return true;
  }
  void C08TraceEnd(bool selected,const std::string& dirout){
    if(!selected)return;
    C08StageTraceRecord records[3];
    if(!cusph::C08StageTraceRead(records))throw std::runtime_error("C08_STAGE_TRACE observation: CUDA copy/disable failed.");
    const unsigned wanted[3]={5809,4956,4959};
    for(unsigned q=0;q<3;q++)if(records[q].hits!=1 || records[q].native_id!=wanted[q])
      throw std::runtime_error("C08_STAGE_TRACE observation: a requested native ID was missing/duplicated; no physical guard is replaced.");
    static std::ofstream file;static std::string boundpath;
    const std::string path=fun::GetDirWithSlash(dirout)+"C08StageTrace.csv";
    if(!file.is_open()){
      std::string normal=path;for(char& c:normal)if(c=='\\')c='/';
      if(normal.find("/tests/outputs/")==std::string::npos || fun::FileExists(path))
        throw std::runtime_error("C08_STAGE_TRACE observation: fresh tests/outputs CSV required.");
      boundpath=path;file.open(path);file<<std::setprecision(17);
      file<<"step_start_s,nstep,interstep,event,stored_dt_s,operator_dt_s,native_id,hits,FSType,p_before_Pa,p_after_Pa,rate_before_Pa_s,rate_after_Pa_s,J,n,theta,ki,LP,divAce,lap,chain,value_double";
      for(const char* prefix:{"pos","FSNormal"})for(unsigned c=0;c<3;c++)file<<','<<prefix<<c;
      for(unsigned c=0;c<9;c++)file<<",C"<<c;
      for(const char* prefix:{"finishedAce","Lx","Gp","GpCorr","GJ"})for(unsigned c=0;c<3;c++)file<<','<<prefix<<c;
      file<<",raw_FS_branch,drainfs,closedfs,freeseepage,ponding_changed\n";
    }
    if(boundpath!=path)throw std::runtime_error("C08_STAGE_TRACE observation: one output path per process required.");
    for(const auto& r:records){
      const bool rhs=r.context.phase==C08_TRACE_RHS;
      file<<r.context.time<<','<<r.context.nstep<<','<<r.context.interstep<<','<<r.context.phase<<','<<r.context.dt_state<<','<<r.context.dt_operator<<','<<r.native_id<<','<<r.hits<<','<<r.fstype<<','<<r.p_before<<','<<r.p_after<<','<<r.rate_before<<','<<r.rate_after;
      const auto number=[&](double v){file<<',';if(rhs)file<<v;};
      for(double v:{r.J,r.n,r.theta,r.ki,r.lp,r.da,r.lap,r.chain,r.value})number(v);
      for(const double* a:{r.pos,r.fsnormal})for(unsigned c=0;c<3;c++)number(a[c]);
      for(double v:r.C)number(v);
      for(const double* a:{r.Ace,r.lx,r.gp,r.gpcorr,r.gJ})for(unsigned c=0;c<3;c++)number(a[c]);
      for(unsigned v:{r.raw_fs,r.drainfs,r.closedfs,r.freeseepage}){file<<',';if(rhs)file<<v;}
      file<<',';if(r.context.phase==C08_TRACE_PONDING)file<<r.projected;file<<'\n';
    }
    file.flush();if(!file)throw std::runtime_error("C08_STAGE_TRACE observation: CSV write failed.");
  }
}
#endif
#endif
//==============================================================================
/// Constructor.
//==============================================================================
JSphGpu::JSphGpu(bool withmpi):JSph(false,false,withmpi),DivAxis(MGDIV_None){
  ClassName="JSphGpu";
  Idp=NULL; Code=NULL; Dcell=NULL; Posxy=NULL; Posz=NULL; Velrhop=NULL;
  Sigma=NULL; AuxSigma_xx_yy_zz=NULL;AuxSigma_xy_yz_xz=NULL;Kplastic=NULL;AuxKplastic=NULL;KplasticDk=NULL;AuxKplasticDk=NULL;//ruofeng
  PorePress=NULL; PorePress0=NULL; AuxPorePress=NULL; AuxPorePress0=NULL; AuxHydroMechLoadAce=NULL;
  PoroJ=NULL; PoroTheta=NULL;
  AuxPos=NULL; AuxVel=NULL; AuxRhop=NULL; AuxFSType=NULL; AuxFSNormal=NULL; AuxPosDiv=NULL;
  CellDiv=NULL;
  FtoAuxDouble6=NULL; FtoAuxFloat15=NULL; //-Calculates forces on floating bodies.
  GpuInfo=new JDsGpuInfo;
  ArraysGpu=new JArraysGpu;
  Timersg=new JDsTimersGpu;
  InitVars();
}

//==============================================================================
/// Destructor.
//==============================================================================
JSphGpu::~JSphGpu(){
  DestructorActive=true;
  //-Release gauge device buffers before destroying the CUDA context.
  delete GaugeSystem; GaugeSystem=NULL;
  FreeCpuMemoryParticles();
  FreeGpuMemoryParticles();
  FreeGpuMemoryFixed();
  delete ArraysGpu; ArraysGpu=NULL;
  delete GpuInfo;   GpuInfo=NULL;
  delete Timersg;    Timersg=NULL;
  cudaDeviceReset();
}

//==============================================================================
/// Throws exception related to a CUDA error from a static method.
//==============================================================================
void JSphGpu::RunExceptioonCudaStatic(const std::string &srcfile,int srcline
  ,const std::string &method
  ,cudaError_t cuerr,std::string msg)
{
  msg=msg+fun::PrintStr(" (CUDA error %d (%s)).\n",cuerr,cudaGetErrorString(cuerr));
  throw JException(srcfile,srcline,"JSphGpu",method,msg,"");
}

//==============================================================================
/// Checks CUDA error and throws exception from a static method.
//==============================================================================
void JSphGpu::CheckCudaErroorStatic(const std::string &srcfile,int srcline
  ,const std::string &method,std::string msg)
{
  const cudaError_t cuerr=cudaGetLastError();
  if(cuerr!=cudaSuccess)RunExceptioonCudaStatic(srcfile,srcline,method,cuerr,msg);
}

//==============================================================================
/// Throws exception related to a CUDA error.
//==============================================================================
void JSphGpu::RunExceptioonCuda(const std::string &srcfile,int srcline
  ,const std::string &classname,const std::string &method
  ,cudaError_t cuerr,std::string msg)const
{
  msg=msg+fun::PrintStr(" (CUDA error %d (%s)).\n",cuerr,cudaGetErrorString(cuerr));
  throw JException(srcfile,srcline,classname,method,msg,"");
}

//==============================================================================
/// Checks CUDA error and throws exception.
/// Comprueba error de CUDA y lanza excepcion si lo hubiera.
//==============================================================================
void JSphGpu::CheckCudaErroor(const std::string &srcfile,int srcline
  ,const std::string &classname,const std::string &method
  ,std::string msg)const
{
  cudaError_t cuerr=cudaGetLastError();
  if(cuerr!=cudaSuccess)RunExceptioonCuda(srcfile,srcline,classname,method,cuerr,msg);
}

//==============================================================================
/// Initialisation of variables.
//==============================================================================
void JSphGpu::InitVars(){
  RunMode="";
  memset(&BlockSizes,0,sizeof(StBlockSizes));
  BlockSizesStr="";

  DivData=DivDataGpuNull();

  Np=Npb=NpbOk=0;
  NpbPer=NpfPer=0;

  FreeCpuMemoryParticles();
  FreeCpuMemoryFixed();
  Idpg=NULL; Codeg=NULL; Dcellg=NULL; Posxyg=NULL; Poszg=NULL; PosCellg=NULL; Velrhopg=NULL;
  Sigmag=NULL; Kplasticg=NULL; KplasticDkg=NULL;//ruofeng
  PorePressg=NULL; PorePress0g=NULL; PorePressRateg=NULL;
  PorosityObserver=false;
  PorosityFeedback=false;
  DynamicPorePressure=false;
  DynamicPoreConductivity=false;DynamicPoreConductivityCk=0.;DynamicConductivitySpeedMax=0.;
  DynamicPoreWall=false;
  PoroJg=NULL; PoroThetag=NULL; PoroJPreg=NULL;
  CorrMatg=NULL; FSTypeg=NULL; FSNormalg=NULL; PosDivg=NULL; //-Free-surface tracking.
  BoundNormalg=NULL; MotionVelg=NULL; BoundModeg=NULL; BoundSlipModeg=NULL; TangenVelg=NULL; NoPenShiftg=NULL; //-mDBC
  BoundDerivativeVelg=NULL;
  BoundDerivativeFitShiftg=NULL;
  VelrhopM1g=NULL;                                 //-Verlet
  SigmaM1g=NULL; KplasticM1g=NULL;//ruofeng
  PorePressM1g=NULL;
  PosxyPreg=NULL; PoszPreg=NULL; VelrhopPreg=NULL; //-Symplectic
  SigmaPreg=NULL;//ruofeng
  PorePressPreg=NULL;
  SpsTaug=NULL; SpsGradvelg=NULL;                  //-Laminar+SPS. 
  ViscDtg=NULL; 
  Arg=NULL; Aceg=NULL; HydroMechLoadAceg=NULL; Deltag=NULL;
  HydroMechTopLoadRawg=NULL;
  Rsigmag=NULL;//ruofeng
  ArtificialStressg=NULL;//mdbr
  ShiftPosfsg=NULL;                                //-Shifting.
  RidpMoveg=NULL; MaterialErrorg=NULL;
  FtRidpg=NULL;   FtoMasspg=NULL;                  //-Floatings.
  FtoDatpg=NULL;  FtoMassg=NULL;  FtoConstraintsg=NULL;                           //-Calculates forces on floating bodies.
  FtoForcesg=NULL;  FtoForcesResg=NULL;  FtoCenterResg=NULL; //-Calculates forces on floating bodies.
  FtoCenterg=NULL; FtoAnglesg=NULL; FtoVelAceg=NULL;//-Management of floating bodies.
  FtoInertiaini8g=NULL; FtoInertiaini1g=NULL;//-Management of floating bodies.
  FtObjsOutdated=true;
  DemDatag=NULL; //(DEM)
  GpuParticlesAllocs=0;
  GpuParticlesSize=0;
  MemGpuParticles=MemGpuFixed=0;
  FreeGpuMemoryParticles();
  FreeGpuMemoryFixed();
}

//==============================================================================
/// Frees fixed memory on CPU for moving and floating bodies.
/// Libera memoria fija en CPU para moving y floating.
//==============================================================================
void JSphGpu::FreeCpuMemoryFixed(){
  MemCpuFixed=0;
  delete[] FtoAuxDouble6; FtoAuxDouble6=NULL;
  delete[] FtoAuxFloat15; FtoAuxFloat15=NULL;
}

//==============================================================================
/// Allocates memory for arrays with fixed size (motion and floating bodies).
//==============================================================================
void JSphGpu::AllocCpuMemoryFixed(){
  MemCpuFixed=0;
  if(sizeof(tfloat3)*2!=sizeof(StFtoForces))Run_Exceptioon("Error: FtoForcesg does not match float3*2.");
  if(sizeof(float)*9!=sizeof(tmatrix3f))Run_Exceptioon("Error: FtoInertiainig does not match float*9.");
  try{
    //-Allocates memory for floating bodies.
    if(CaseNfloat){
      FtoAuxDouble6=new tdouble3[FtCount*2];  MemCpuFixed+=(sizeof(tdouble3)*FtCount*2);
      FtoAuxFloat15=new tfloat3 [FtCount*5];  MemCpuFixed+=(sizeof(tfloat3) *FtCount*5);
    }
  }
  catch(const std::bad_alloc){
    Run_Exceptioon("Could not allocate the requested memory.");
  }
}

//==============================================================================
/// Frees fixed memory on the GPU for moving and floating bodies.
/// Libera memoria fija en GPU para moving y floating.
//==============================================================================
void JSphGpu::FreeGpuMemoryFixed(){
  MemGpuFixed=0;
  if(MaterialErrorg)cudaFree(MaterialErrorg); MaterialErrorg=NULL;
  if(BoundDerivativeFitShiftg)cudaFree(BoundDerivativeFitShiftg); BoundDerivativeFitShiftg=NULL;
  if(RidpMoveg)         cudaFree(RidpMoveg);          RidpMoveg=NULL;
  if(FtRidpg)           cudaFree(FtRidpg);            FtRidpg=NULL;
  if(FtoMasspg)         cudaFree(FtoMasspg);          FtoMasspg=NULL;
  if(FtoDatpg)          cudaFree(FtoDatpg);           FtoDatpg=NULL;
  if(FtoMassg)          cudaFree(FtoMassg);           FtoMassg=NULL;
  if(FtoConstraintsg)   cudaFree(FtoConstraintsg);    FtoConstraintsg=NULL;
  if(FtoForcesg)        cudaFree(FtoForcesg);         FtoForcesg=NULL;
  if(FtoForcesResg)     cudaFree(FtoForcesResg);      FtoForcesResg=NULL;
  if(FtoCenterg)        cudaFree(FtoCenterg);         FtoCenterg=NULL;
  if(FtoAnglesg)        cudaFree(FtoAnglesg);         FtoAnglesg=NULL;
  if(FtoVelAceg)        cudaFree(FtoVelAceg);         FtoVelAceg=NULL;
  if(FtoInertiaini8g)   cudaFree(FtoInertiaini8g);    FtoInertiaini8g=NULL;
  if(FtoInertiaini1g)   cudaFree(FtoInertiaini1g);    FtoInertiaini1g=NULL;
  if(DemDatag)          cudaFree(DemDatag);           DemDatag=NULL;
}

//==============================================================================
/// Allocates memory for arrays with fixed size (motion and floating bodies).
//==============================================================================
void JSphGpu::AllocGpuMemoryFixed(){
  MemGpuFixed=0;
  if(SoilCte.ModulusK>0.f && SoilCte.ModulusG>0.f){
    cudaMalloc((void**)&MaterialErrorg,sizeof(unsigned)); MemGpuFixed+=sizeof(unsigned);
  }
  //-Allocates memory for moving objects.
  if(CaseNmoving){
    size_t m=sizeof(unsigned)*CaseNmoving;
    cudaMalloc((void**)&RidpMoveg,m);   MemGpuFixed+=m;
  }
  //-Allocates memory for floating bodies.
  if(CaseNfloat){
    size_t m=0;
    m=sizeof(unsigned)*CaseNfloat;  cudaMalloc((void**)&FtRidpg           ,m);  MemGpuFixed+=m;
    m=sizeof(float)   *FtCount;     cudaMalloc((void**)&FtoMasspg         ,m);  MemGpuFixed+=m;
    m=sizeof(float4)  *FtCount;     cudaMalloc((void**)&FtoDatpg          ,m);  MemGpuFixed+=m;
    m=sizeof(float)   *FtCount;     cudaMalloc((void**)&FtoMassg          ,m);  MemGpuFixed+=m;
    m=sizeof(byte)    *FtCount;     cudaMalloc((void**)&FtoConstraintsg   ,m);  MemGpuFixed+=m;
    m=sizeof(float3)  *FtCount*2;   cudaMalloc((void**)&FtoForcesg        ,m);  MemGpuFixed+=m;
    m=sizeof(float3)  *FtCount*2;   cudaMalloc((void**)&FtoForcesResg     ,m);  MemGpuFixed+=m;
    m=sizeof(double3) *FtCount;     cudaMalloc((void**)&FtoCenterResg     ,m);  MemGpuFixed+=m;
    m=sizeof(double3) *FtCount;     cudaMalloc((void**)&FtoCenterg        ,m);  MemGpuFixed+=m;
    m=sizeof(float3)  *FtCount;     cudaMalloc((void**)&FtoAnglesg        ,m);  MemGpuFixed+=m;
    m=sizeof(float3)  *FtCount*4;   cudaMalloc((void**)&FtoVelAceg        ,m);  MemGpuFixed+=m;
    m=sizeof(float4)  *FtCount*2;   cudaMalloc((void**)&FtoInertiaini8g   ,m);  MemGpuFixed+=m;
    m=sizeof(float)   *FtCount;     cudaMalloc((void**)&FtoInertiaini1g   ,m);  MemGpuFixed+=m;
  }
  if(UseDEM){ //(DEM)
    size_t m=sizeof(float4)*DemDataSize;
    cudaMalloc((void**)&DemDatag,m);     MemGpuFixed+=m;
  }
}

//==============================================================================
/// Releases memory for the main particle data.
/// Libera memoria para datos principales de particulas.
//==============================================================================
void JSphGpu::FreeCpuMemoryParticles(){
  CpuParticlesSize=0;
  MemCpuParticles=0;
  delete[] Idp;        Idp=NULL;
  delete[] Code;       Code=NULL;
  delete[] Dcell;      Dcell=NULL;
  delete[] Posxy;      Posxy=NULL;
  delete[] Posz;       Posz=NULL;
  delete[] Velrhop;    Velrhop=NULL;
  //ruofeng
  delete[] Sigma;      Sigma = NULL;
  delete[] Kplastic;   Kplastic = NULL;
  delete[] KplasticDk; KplasticDk = NULL;
  delete[] PorePress;  PorePress = NULL;
  delete[] PorePress0; PorePress0 = NULL;
  delete[] AuxPorePress;  AuxPorePress = NULL;
  delete[] AuxPorePress0; AuxPorePress0 = NULL;
  delete[] PoroJ; PoroJ=NULL;
  delete[] PoroTheta; PoroTheta=NULL;
  delete[] AuxHydroMechLoadAce; AuxHydroMechLoadAce=NULL;
  //
  delete[] AuxPos;     AuxPos=NULL;
  delete[] AuxVel;     AuxVel=NULL;
  delete[] AuxRhop;    AuxRhop=NULL;
  delete[] AuxFSType;  AuxFSType=NULL;
  delete[] AuxFSNormal; AuxFSNormal=NULL;
  delete[] AuxPosDiv; AuxPosDiv=NULL;
  //ruofeng
  delete[] AuxSigma_xx_yy_zz;   AuxSigma_xx_yy_zz = NULL;
  delete[] AuxSigma_xy_yz_xz;   AuxSigma_xy_yz_xz = NULL;
  delete[] AuxKplastic; AuxKplastic = NULL;
  delete[] AuxKplasticDk; AuxKplasticDk = NULL;
}

//==============================================================================
/// Allocates memory for the main particle data.
/// Reserva memoria para datos principales de particulas.
//==============================================================================
void JSphGpu::AllocCpuMemoryParticles(unsigned np){
  FreeCpuMemoryParticles();
  if(np>0)np=np+PARTICLES_OVERMEMORY_MIN;
  CpuParticlesSize=np;
  if(np>0){
    try{
      Idp=new unsigned[np];      MemCpuParticles+=sizeof(unsigned)*np;
      Code=new typecode[np];     MemCpuParticles+=sizeof(typecode)*np;
      Dcell=new unsigned[np];    MemCpuParticles+=sizeof(unsigned)*np;
      Posxy=new tdouble2[np];    MemCpuParticles+=sizeof(tdouble2)*np;
      Posz=new double[np];       MemCpuParticles+=sizeof(double)*np;
      Velrhop=new tfloat4[np];   MemCpuParticles+=sizeof(tfloat4)*np;
      //=========mdbr
	  Sigma=new tsymatrix3d[np]; MemCpuParticles+=sizeof(tsymatrix3d)*np;
      Kplastic = new float[np]; MemCpuParticles += sizeof(float) * np;
      KplasticDk = new float[np]; MemCpuParticles += sizeof(float) * np;
      if(HydroMech){
        PorePress=new float[np];     MemCpuParticles+=sizeof(float)*np;
        PorePress0=new float[np];    MemCpuParticles+=sizeof(float)*np;
        AuxPorePress=new float[np];  MemCpuParticles+=sizeof(float)*np;
        AuxPorePress0=new float[np]; MemCpuParticles+=sizeof(float)*np;
        AuxHydroMechLoadAce=new tfloat3[np]; MemCpuParticles+=sizeof(tfloat3)*np;
      }
      if(PorosityObserver){
        PoroJ=new double[np]; MemCpuParticles+=sizeof(double)*np;
        PoroTheta=new double[np]; MemCpuParticles+=sizeof(double)*np;
      }
      //==========
      AuxPos=new tdouble3[np];   MemCpuParticles+=sizeof(tdouble3)*np; 
      AuxVel=new tfloat3[np];    MemCpuParticles+=sizeof(tfloat3)*np;
      AuxRhop=new float[np];     MemCpuParticles+=sizeof(float)*np;
      AuxFSType=new unsigned[np]; MemCpuParticles+=sizeof(unsigned)*np;
      AuxFSNormal=new tfloat3[np]; MemCpuParticles+=sizeof(tfloat3)*np;
      AuxPosDiv=new float[np]; MemCpuParticles+=sizeof(float)*np;
      //======mdbr
      AuxSigma_xx_yy_zz = new tfloat3[np]; MemCpuParticles+=sizeof(tfloat3)*np;
      AuxSigma_xy_yz_xz = new tfloat3[np]; MemCpuParticles+=sizeof(tfloat3)*np;
      AuxKplastic = new float[np];   MemCpuParticles += sizeof(float) *np;
      AuxKplasticDk = new float[np]; MemCpuParticles += sizeof(float) *np;
      //======
    }
    catch(const std::bad_alloc){
      Run_Exceptioon(fun::PrintStr("Could not allocate the requested memory (np=%u).",np));
    }
  }
}

//==============================================================================
/// Frees GPU memory for the particles.
/// Libera memoria en Gpu para particulas.
//==============================================================================
void JSphGpu::FreeGpuMemoryParticles(){
  //GpuParticlesAllocs=0; This values is kept.
  GpuParticlesSize=0;
  MemGpuParticles=0;
  ArraysGpu->Reset();
  KplasticM1g=NULL;
  PoroJg=NULL; PoroThetag=NULL; PoroJPreg=NULL;
}

//==============================================================================
/// Allocates GPU memory for the particles.
/// Reserva memoria en Gpu para las particulas. 
//==============================================================================
void JSphGpu::AllocGpuMemoryParticles(unsigned np,float over){
  FreeGpuMemoryParticles();
  //-Computes number of particles for which memory will be allocated.
  //-Calcula numero de particulas para las que se reserva memoria.
  const unsigned np2=(over>0? unsigned(over*np): np);
  GpuParticlesSize=np2+PARTICLES_OVERMEMORY_MIN;
  //-Define number or arrays to use. | Establece numero de arrays a usar.
  ArraysGpu->SetArraySize(GpuParticlesSize);
  #ifdef CODE_SIZE4
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,2);  //-code,code2
  #else
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_2B,2);  //-code,code2
  #endif
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,6);  //-idp,ar,viscdt,dcell,FSTypeg,PosDivg
  if(DDTArray)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,1);  //-delta
  if(HydroMechTopLoadMode==HMLOAD_TopKernelBand)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,1); //-raw top-band load
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_12B,2); //-ace,FSNormalg
  if(SoilBoundaryDerivativeSPR || DynamicPoreWall)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_12B,1);
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_16B,5); //-velrhop,posxy,poscell
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_8B,2);  //-posz
  if(PorosityObserver){
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_8B,4); //-J, theta, Jpre, sequential sort scratch.
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,1); //-Observer validity flag.
  }
  if(DynamicPorePressure)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,1); //-Force-stage native-ID map.
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_72B,1); //-CorrMatg
  //====== mdbr
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_48B, 2);//-sigma and its sort buffer
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_24B, 1);//-rsigma
  if(ArtificialStress)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_24B,1);//-artificialstress
  ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B, 4);//-kplastic,kplasticdk and sort buffers
  if(HydroMech){
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,6);//-PorePress,PorePress0,PorePressRate and sort buffers
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_12B,2);//-HydroMechLoadAce and sort buffer; diagnostic layout only.
  }
  if(TStep==STEP_Verlet){
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_16B,1); //-velrhopm1
    //====mdbr
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_48B, 1);//-sigmam1
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,1); //-kplasticm1; reuses existing float sort scratch.
    if(HydroMech)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,2);//-PorePressM1 and sort buffer
  }
  else if(TStep==STEP_Symplectic){
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_8B,1);  //-poszpre
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_16B,2); //-posxypre,velrhoppre
    //====mdbr
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_48B, 1);//-sigmapre
    if(HydroMech)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,2);//-PorePressPre and sort buffer
  }
  if(TVisco==VISCO_LaminarSPS){     
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_24B,2); //-SpsTau,SpsGradvel
  }
  if(CaseNfloat){
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,4);  //-FtMasspg
  }
  if(Shifting){
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_16B,1); //-shiftposfs
  }
  if(UseNormals){
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_12B,1); //-BoundNormal
    if(MdbcSlipModeMax!=SLIP_Vel0)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_12B,1); //-MotionVel
    if(MdbcSlipModeMax>=SLIP_NoSlip)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_1B,1); //-BoundMode
    if(MdbcSlipModeByMk)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_1B,2); //-BoundSlipMode and sort buffer
    if(MdbcSlipModeMax>=SLIP_NoSlip)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_12B,1); //-TangenVel
    if(TMdbc2==MDBC2_NoPen)ArraysGpu->AddArrayCount(JArraysGpu::SIZE_16B,1); //-NoPenShift
  }
  if(InOut){
    //ArraysGpu->AddArrayCount(JArraysGpu::SIZE_4B,1);  //-InOutPartg
    ArraysGpu->AddArrayCount(JArraysGpu::SIZE_1B,2);  //-newizone,zsurfok
  }

  //-Shows the allocated memory.
  MemGpuParticles=ArraysGpu->GetAllocMemoryGpu();
  PrintSizeNp(GpuParticlesSize,MemGpuParticles,GpuParticlesAllocs);
  Check_CudaErroor("Failed GPU memory allocation.");
}

//==============================================================================
/// Resizes space in GPU memory for particles.
//==============================================================================
void JSphGpu::ResizeGpuMemoryParticles(unsigned npnew){
  npnew=npnew+PARTICLES_OVERMEMORY_MIN;
  //-Saves current data from GPU.
  unsigned    *idp        =SaveArrayGpu(Np,Idpg);
  typecode    *code       =SaveArrayGpu(Np,Codeg);
  unsigned    *dcell      =SaveArrayGpu(Np,Dcellg);
  double2     *posxy      =SaveArrayGpu(Np,Posxyg);
  double      *posz       =SaveArrayGpu(Np,Poszg);
  float4      *poscell    =SaveArrayGpu(Np,PosCellg);
  float4      *velrhop    =SaveArrayGpu(Np,Velrhopg);
  float4      *velrhopm1  =SaveArrayGpu(Np,VelrhopM1g);
  double2     *posxypre   =SaveArrayGpu(Np,PosxyPreg);
  double      *poszpre    =SaveArrayGpu(Np,PoszPreg);
  float4      *velrhoppre =SaveArrayGpu(Np,VelrhopPreg);
  tsymatrix3f *spstau     =SaveArrayGpu(Np,SpsTaug);
  float3      *boundnormal=SaveArrayGpu(Np,BoundNormalg);
  float3      *motionvel  =SaveArrayGpu(Np,MotionVelg);
  byte        *boundmode  =SaveArrayGpu(Np,BoundModeg);
  byte        *boundslipmode=SaveArrayGpu(Np,BoundSlipModeg);
  float3      *tangenvel  =SaveArrayGpu(Np,TangenVelg);
  tmatrix3d   *corrmat    =SaveArrayGpu(Np,CorrMatg);
  unsigned    *fstype     =SaveArrayGpu(Np,FSTypeg);
  float3      *fsnormal   =SaveArrayGpu(Np,FSNormalg);
  float       *posdiv     =SaveArrayGpu(Np,PosDivg);
  float3      *hydromechloadace=SaveArrayGpu(Np,HydroMechLoadAceg);
  //==mdbr
  tsymatrix3d* sigma = SaveArrayGpu(Np, Sigmag);
  float* kplastic = SaveArrayGpu(Np, Kplasticg);
  float* kplasticdk = SaveArrayGpu(Np, KplasticDkg);
  float* porepress = SaveArrayGpu(Np, PorePressg);
  float* porepress0 = SaveArrayGpu(Np, PorePress0g);
  float* porepressrate = SaveArrayGpu(Np, PorePressRateg);
  float* porepressm1 = SaveArrayGpu(Np, PorePressM1g);
  float* porepresspre = SaveArrayGpu(Np, PorePressPreg);
  double* poroj=SaveArrayGpu(Np,PoroJg);
  double* porotheta=SaveArrayGpu(Np,PoroThetag);
  double* porojpre=SaveArrayGpu(Np,PoroJPreg);
  tsymatrix3d* sigmapre = SaveArrayGpu(Np, SigmaPreg);
  tsymatrix3d* sigmam1 = SaveArrayGpu(Np, SigmaM1g);
  float* kplasticm1 = SaveArrayGpu(Np, KplasticM1g);
  // 
  //-Frees pointers.
  ArraysGpu->Free(Idpg);
  ArraysGpu->Free(Codeg);
  ArraysGpu->Free(Dcellg);
  ArraysGpu->Free(Posxyg);
  ArraysGpu->Free(Poszg);
  ArraysGpu->Free(PosCellg);
  ArraysGpu->Free(Velrhopg);
  ArraysGpu->Free(VelrhopM1g);
  ArraysGpu->Free(PosxyPreg);
  ArraysGpu->Free(PoszPreg);
  ArraysGpu->Free(VelrhopPreg);
  ArraysGpu->Free(SpsTaug);
  ArraysGpu->Free(BoundNormalg);
  ArraysGpu->Free(MotionVelg);
  ArraysGpu->Free(BoundModeg);
  ArraysGpu->Free(BoundSlipModeg);
  ArraysGpu->Free(TangenVelg);
  ArraysGpu->Free(CorrMatg);
  ArraysGpu->Free(FSTypeg);
  ArraysGpu->Free(FSNormalg);
  ArraysGpu->Free(PosDivg);
  ArraysGpu->Free(HydroMechLoadAceg);
  //-mdbr
  ArraysGpu->Free(Sigmag);
  ArraysGpu->Free(Kplasticg);
  ArraysGpu->Free(KplasticDkg);
  ArraysGpu->Free(PorePressg);
  ArraysGpu->Free(PorePress0g);
  ArraysGpu->Free(PorePressRateg);
  ArraysGpu->Free(PorePressM1g);
  ArraysGpu->Free(PorePressPreg);
  ArraysGpu->Free(PoroJg);
  ArraysGpu->Free(PoroThetag);
  ArraysGpu->Free(PoroJPreg);
  ArraysGpu->Free(SigmaPreg);
  ArraysGpu->Free(SigmaM1g);
  ArraysGpu->Free(KplasticM1g);
  // 
  //-Resizes GPU memory allocation.
  const double mbparticle=(double(MemGpuParticles)/(1024*1024))/GpuParticlesSize; //-MB por particula.
  Log->Printf("**JSphGpu: Requesting gpu memory for %u particles: %.1f MB.",npnew,mbparticle*npnew);
  ArraysGpu->SetArraySize(npnew);
  //-Reserve pointers.
  Idpg    =ArraysGpu->ReserveUint();
  Codeg   =ArraysGpu->ReserveTypeCode();
  Dcellg  =ArraysGpu->ReserveUint();
  Posxyg  =ArraysGpu->ReserveDouble2();
  Poszg   =ArraysGpu->ReserveDouble();
  PosCellg=ArraysGpu->ReserveFloat4();
  Velrhopg=ArraysGpu->ReserveFloat4();
  if(velrhopm1)  VelrhopM1g  =ArraysGpu->ReserveFloat4();
  if(posxypre)   PosxyPreg   =ArraysGpu->ReserveDouble2();
  if(poszpre)    PoszPreg    =ArraysGpu->ReserveDouble();
  if(velrhoppre) VelrhopPreg =ArraysGpu->ReserveFloat4();
  if(spstau)     SpsTaug     =ArraysGpu->ReserveSymatrix3f();
  if(boundnormal)BoundNormalg=ArraysGpu->ReserveFloat3();
  if(motionvel)  MotionVelg  =ArraysGpu->ReserveFloat3();
  if(boundmode)  BoundModeg  =ArraysGpu->ReserveByte();
  if(boundslipmode)BoundSlipModeg=ArraysGpu->ReserveByte();
  if(tangenvel)  TangenVelg  =ArraysGpu->ReserveFloat3();
  if(corrmat)    CorrMatg    =ArraysGpu->ReserveMatrix3d();
  if(fstype)     FSTypeg     =ArraysGpu->ReserveUint();
  if(fsnormal)   FSNormalg   =ArraysGpu->ReserveFloat3();
  if(posdiv)     PosDivg     =ArraysGpu->ReserveFloat();
  if(hydromechloadace)HydroMechLoadAceg=ArraysGpu->ReserveFloat3();
  //--mdbr
  if(sigma)      Sigmag = ArraysGpu->ReserveSymatrix3d();
  if(kplastic)   Kplasticg = ArraysGpu->ReserveFloat();
  if(kplasticdk) KplasticDkg = ArraysGpu->ReserveFloat();
  if(porepress)  PorePressg = ArraysGpu->ReserveFloat();
  if(porepress0) PorePress0g = ArraysGpu->ReserveFloat();
  if(porepressrate) PorePressRateg = ArraysGpu->ReserveFloat();
  if(porepressm1) PorePressM1g = ArraysGpu->ReserveFloat();
  if(porepresspre) PorePressPreg = ArraysGpu->ReserveFloat();
  if(poroj)PoroJg=ArraysGpu->ReserveDouble();
  if(porotheta)PoroThetag=ArraysGpu->ReserveDouble();
  if(porojpre)PoroJPreg=ArraysGpu->ReserveDouble();
  if(sigmapre)   SigmaPreg = ArraysGpu->ReserveSymatrix3d();
  if(sigmam1)      SigmaM1g = ArraysGpu->ReserveSymatrix3d();
  if(kplasticm1) KplasticM1g = ArraysGpu->ReserveFloat();
  // 
  //-Restore data in GPU memory.
  RestoreArrayGpu(Np,idp,Idpg);
  RestoreArrayGpu(Np,code,Codeg);
  RestoreArrayGpu(Np,dcell,Dcellg);
  RestoreArrayGpu(Np,posxy,Posxyg);
  RestoreArrayGpu(Np,posz,Poszg);
  RestoreArrayGpu(Np,poscell,PosCellg);
  RestoreArrayGpu(Np,velrhop,Velrhopg);
  RestoreArrayGpu(Np,velrhopm1,VelrhopM1g);
  RestoreArrayGpu(Np,posxypre,PosxyPreg);
  RestoreArrayGpu(Np,poszpre,PoszPreg);
  RestoreArrayGpu(Np,velrhoppre,VelrhopPreg);
  RestoreArrayGpu(Np,spstau,SpsTaug);
  RestoreArrayGpu(Np,boundnormal,BoundNormalg);
  RestoreArrayGpu(Np,motionvel,MotionVelg);
  RestoreArrayGpu(Np,boundmode,BoundModeg);
  RestoreArrayGpu(Np,boundslipmode,BoundSlipModeg);
  RestoreArrayGpu(Np,tangenvel,TangenVelg);
  RestoreArrayGpu(Np,corrmat,CorrMatg);
  RestoreArrayGpu(Np,fstype,FSTypeg);
  RestoreArrayGpu(Np,fsnormal,FSNormalg);
  RestoreArrayGpu(Np,posdiv,PosDivg);
  RestoreArrayGpu(Np,hydromechloadace,HydroMechLoadAceg);
  //---mdbr
  RestoreArrayGpu(Np,sigma,Sigmag);
  RestoreArrayGpu(Np,kplastic,Kplasticg);
  RestoreArrayGpu(Np,kplasticdk,KplasticDkg);
  RestoreArrayGpu(Np,porepress,PorePressg);
  RestoreArrayGpu(Np,porepress0,PorePress0g);
  RestoreArrayGpu(Np,porepressrate,PorePressRateg);
  RestoreArrayGpu(Np,porepressm1,PorePressM1g);
  RestoreArrayGpu(Np,porepresspre,PorePressPreg);
  RestoreArrayGpu(Np,poroj,PoroJg);
  RestoreArrayGpu(Np,porotheta,PoroThetag);
  RestoreArrayGpu(Np,porojpre,PoroJPreg);
  RestoreArrayGpu(Np,sigmam1,SigmaM1g);
  RestoreArrayGpu(Np,kplasticm1,KplasticM1g);
  RestoreArrayGpu(Np,sigmapre,SigmaPreg);
  //
  //-Updates values.
  GpuParticlesAllocs++;
  GpuParticlesSize=npnew;
  MemGpuParticles=ArraysGpu->GetAllocMemoryGpu();
}

//==============================================================================
/// Saves a GPU array in CPU memory. 
//==============================================================================
template<class T> T* JSphGpu::TSaveArrayGpu(unsigned np,const T *datasrc)const{
  T *data=NULL;
  if(datasrc){
    try{
      data=new T[np];
    }
    catch(const std::bad_alloc){
      Run_Exceptioon("Could not allocate the requested memory.");
    }
    cudaMemcpy(data,datasrc,sizeof(T)*np,cudaMemcpyDeviceToHost);
  }
  return(data);
}

//==============================================================================
/// Restores a GPU array (generic) from CPU memory. 
//==============================================================================
template<class T> void JSphGpu::TRestoreArrayGpu(unsigned np,T *data,T *datanew)const{
  if(data&&datanew)cudaMemcpy(datanew,data,sizeof(T)*np,cudaMemcpyHostToDevice);
  delete[] data;
}

//==============================================================================
/// Arrays for basic particle data.
/// Arrays para datos basicos de las particulas. 
//==============================================================================
void JSphGpu::ReserveBasicArraysGpu(){
  Idpg=ArraysGpu->ReserveUint();
  Codeg=ArraysGpu->ReserveTypeCode();
  Dcellg=ArraysGpu->ReserveUint();
  Posxyg=ArraysGpu->ReserveDouble2();
  Poszg=ArraysGpu->ReserveDouble();
  PosCellg=ArraysGpu->ReserveFloat4();
  Velrhopg=ArraysGpu->ReserveFloat4();
  CorrMatg=ArraysGpu->ReserveMatrix3d();
  FSTypeg=ArraysGpu->ReserveUint();
  FSNormalg=ArraysGpu->ReserveFloat3();
  PosDivg=ArraysGpu->ReserveFloat();
  if(PorosityObserver){
    PoroJg=ArraysGpu->ReserveDouble();
    PoroThetag=ArraysGpu->ReserveDouble();
  }
  //mdbr
  Sigmag = ArraysGpu->ReserveSymatrix3d();
  Kplasticg = ArraysGpu->ReserveFloat();
  KplasticDkg = ArraysGpu->ReserveFloat();
  if(HydroMech){
    PorePressg=ArraysGpu->ReserveFloat();
    PorePress0g=ArraysGpu->ReserveFloat();
    PorePressRateg=ArraysGpu->ReserveFloat();
    HydroMechLoadAceg=ArraysGpu->ReserveFloat3();
  }
  if(TStep==STEP_Verlet){VelrhopM1g=ArraysGpu->ReserveFloat4();
    SigmaM1g = ArraysGpu->ReserveSymatrix3d();//mdbr
    KplasticM1g=ArraysGpu->ReserveFloat();
    if(HydroMech)PorePressM1g=ArraysGpu->ReserveFloat();
  }
  if(TVisco==VISCO_LaminarSPS)SpsTaug=ArraysGpu->ReserveSymatrix3f();
  if(UseNormals){
    BoundNormalg=ArraysGpu->ReserveFloat3();
    if(MdbcSlipModeMax!=SLIP_Vel0)MotionVelg=ArraysGpu->ReserveFloat3();
    if(MdbcSlipModeMax>=SLIP_NoSlip)BoundModeg=ArraysGpu->ReserveByte();
    if(MdbcSlipModeByMk)BoundSlipModeg=ArraysGpu->ReserveByte();
    if(MdbcSlipModeMax>=SLIP_NoSlip)TangenVelg=ArraysGpu->ReserveFloat3();
  }
}

//==============================================================================
/// Returns the allocated memory on the CPU.
/// Devuelve la memoria reservada en CPU.
//==============================================================================
llong JSphGpu::GetAllocMemoryCpu()const{  
  llong s=JSph::GetAllocMemoryCpu();
  //-Allocated in AllocCpuMemoryFixed().
  s+=MemCpuFixed;
  //-Allocated in AllocMemoryParticles().
  s+=MemCpuParticles;
  //-Allocated in other objects.
  if(MLPistons)s+=MLPistons->GetAllocMemoryCpu();
  return(s);
}

//==============================================================================
/// Returns the allocated memory in the GPU.
/// Devuelve la memoria reservada en GPU.
//==============================================================================
llong JSphGpu::GetAllocMemoryGpu()const{  
  llong s=0;
  //-Allocated in AllocGpuMemoryParticles().
  s+=MemGpuParticles;
  //-Allocated in AllocGpuMemoryFixed().
  s+=MemGpuFixed;
  //-Allocated in ther objects.
  if(MLPistons)s+=MLPistons->GetAllocMemoryGpu();
  return(s);
}

//==============================================================================
/// Displays the allocated memory.
/// Visualiza la memoria reservada.
//==============================================================================
void JSphGpu::PrintAllocMemory(llong mcpu,llong mgpu)const{
  Log->Printf("Allocated memory in CPU: %lld (%.2f MB)",mcpu,double(mcpu)/(1024*1024));
  Log->Printf("Allocated memory in GPU: %lld (%.2f MB)",mgpu,double(mgpu)/(1024*1024));
}

//==============================================================================
/// Uploads constants to the GPU.
/// Copia constantes a la GPU.
//==============================================================================
void JSphGpu::ConstantDataUp(){
  StCteInteraction ctes;
  memset(&ctes,0,sizeof(StCteInteraction));
  ctes.nbound=CaseNbound;
  ctes.massb=MassBound; ctes.massf=MassFluid;
  ctes.kernelh=KernelH;
  ctes.kernelsize2=KernelSize2; 
  ctes.poscellsize=PosCellSize; 
  //-Wendland constants are always computed since this kernel is used in some parts where other kernels are not defined (e.g. mDBC, inlet/outlet...).
  ctes.awen=KWend.awen; ctes.bwen=KWend.bwen;
  //-Copies constants for other kernels.
  if(TKernel==KERNEL_Cubic){
    ctes.cubic_a1=KCubic.a1; ctes.cubic_a2=KCubic.a2; ctes.cubic_aa=KCubic.aa; ctes.cubic_a24=KCubic.a24;
    ctes.cubic_c1=KCubic.c1; ctes.cubic_c2=KCubic.c2; ctes.cubic_d1=KCubic.d1; ctes.cubic_odwdeltap=KCubic.od_wdeltap;
  }
  ctes.cs0=float(Cs0); ctes.eta2=Eta2;
  ctes.ddtkh=DDTkh;
  ctes.ddtgz=DDTgz;
  ctes.sdtgz=RhopZero*Gravity.z;//mdbr
  ctes.k0=1.f-sin(SoilCte.phi);//mdbr
  ctes.scell=Scell; 
  ctes.kernelsize=KernelSize;
  ctes.dp=float(Dp);
  ctes.strainsoftening=(StrainSoftening? 1: 0);
  ctes.artificialstress=(ArtificialStress? 1: 0);
  ctes.artificialstresscoef=ArtificialStressCoef;
  ctes.artificialstressexp=ArtificialStressExp;
  ctes.soilstressrategradcorr=(SoilStressRateGradCorr? 1: 0);
  ctes.soildamping=(SoilDamping? 1: 0);
  ctes.soildampingcoef=SoilDampingCoef;
  ctes.cteb=CteB; ctes.gamma=Gamma;
  ctes.rhopzero=RhopZero;
  ctes.ovrhopzero=1.f/RhopZero;
  ctes.movlimit=MovLimit;
  ctes.maprealposminx=MapRealPosMin.x; ctes.maprealposminy=MapRealPosMin.y; ctes.maprealposminz=MapRealPosMin.z;
  ctes.maprealsizex=MapRealSize.x; ctes.maprealsizey=MapRealSize.y; ctes.maprealsizez=MapRealSize.z;
  ctes.simulate2d=(Simulate2D? 1: 0);
  ctes.symmetry=Symmetry;   //<vs_syymmetry>
  ctes.tboundary=unsigned(TBoundary);
  ctes.slipmode=unsigned(SlipMode);
  ctes.periactive=PeriActive;
  ctes.xperincx=PeriXinc.x; ctes.xperincy=PeriXinc.y; ctes.xperincz=PeriXinc.z;
  ctes.yperincx=PeriYinc.x; ctes.yperincy=PeriYinc.y; ctes.yperincz=PeriYinc.z;
  ctes.zperincx=PeriZinc.x; ctes.zperincy=PeriZinc.y; ctes.zperincz=PeriZinc.z;
  ctes.axis=MGDIV_Z;//-Necessary to avoid errors in KerGetInteraction_Cells().
  ctes.cellcode=DomCellCode;
  ctes.domposminx=DomPosMin.x; ctes.domposminy=DomPosMin.y; ctes.domposminz=DomPosMin.z;
  ctes.modulus_E=SoilCte.ModulusE; ctes.modulus_K=SoilCte.ModulusK; ctes.modulus_G=SoilCte.ModulusG;
  ctes.hydromech=(HydroMech? 1: 0);
  ctes.poremdbcinterp=PoreMdbcInterpolationMode;
  ctes.porecompsourcemode=PoreCompressionSourceMode;
  ctes.porecompgradcorr=(PoreCompressionGradCorr? 1u: 0u);
  ctes.poredarcysymcorr=(PoreDarcySymmetricCorr? 1u: 0u);
  ctes.hydrotoploadmode=unsigned(HydroMechTopLoadMode);
  ctes.hydrotoploadpressure=0.f;
  if(HydroMech && (HydroMechTopLoadMode==HMLOAD_FlexibleConfinement || HydroMechTopLoadMode==HMLOAD_TopKernelBand) && HydroMechTopLoadQ0>0.f){
    const double tramp=HydroMechTopLoadRampTime;
    const double q0=double(HydroMechTopLoadQ0);
    const double q=(tramp>0 && TimeStep<tramp? q0*max(0.0,TimeStep)/tramp: q0);
    ctes.hydrotoploadpressure=float(max(0.0,q));
  }
  ctes.porewaterrho=SoilCte.PoreWaterRho;
  ctes.porewaterbulkmodulus=SoilCte.PoreWaterBulkModulus;
  ctes.porosity=SoilCte.Porosity;
  ctes.hydraulicconductivity=SoilCte.HydraulicConductivity;
  ctes.porekwn=(SoilCte.Porosity>0.f? SoilCte.PoreWaterBulkModulus/SoilCte.Porosity: 0.f);
  {
    const double gnorm=sqrt(double(Gravity.x)*Gravity.x+double(Gravity.y)*Gravity.y+double(Gravity.z)*Gravity.z);
    ctes.poreghyd=float(gnorm>0? gnorm: 9.80665);
  }
  ctes.gravityx=Gravity.x; ctes.gravityy=Gravity.y; ctes.gravityz=Gravity.z;
  cusph::CteInteractionUp(&ctes);
  cusphs::CteInteractionUpTStep(&SoilCte,(StrainSoftening? 1: 0),(PartBegin? 1: 0));//mbdr
  Check_CudaErroor("Failed copying constants to GPU.");
}

//==============================================================================
/// Uploads particle data to the GPU.
/// Sube datos de particulas a la GPU.
//==============================================================================
void JSphGpu::ParticlesDataUp(unsigned n,const tfloat3 *boundnormal,const byte *boundslipmode){
  cudaMemcpy(Idpg    ,Idp    ,sizeof(unsigned)*n,cudaMemcpyHostToDevice);
  cudaMemcpy(Codeg   ,Code   ,sizeof(typecode)*n,cudaMemcpyHostToDevice);
  cudaMemcpy(Dcellg  ,Dcell  ,sizeof(unsigned)*n,cudaMemcpyHostToDevice);
  cudaMemcpy(Posxyg  ,Posxy  ,sizeof(double2)*n ,cudaMemcpyHostToDevice);
  cudaMemcpy(Poszg   ,Posz   ,sizeof(double)*n  ,cudaMemcpyHostToDevice);
  cudaMemcpy(Velrhopg,Velrhop,sizeof(float4)*n  ,cudaMemcpyHostToDevice);
  //===mdbr
  cudaMemcpy(Sigmag, Sigma, sizeof(tsymatrix3d)*n, cudaMemcpyHostToDevice);
  cudaMemcpy(Kplasticg, Kplastic, sizeof(float)*n, cudaMemcpyHostToDevice);
  if(KplasticM1g)cudaMemcpy(KplasticM1g,Kplastic,sizeof(float)*n,cudaMemcpyHostToDevice);
  cudaMemset(KplasticDkg,0,sizeof(float)*n);
  if(HydroMech){
    cudaMemcpy(PorePressg,PorePress,sizeof(float)*n,cudaMemcpyHostToDevice);
    cudaMemcpy(PorePress0g,PorePress0,sizeof(float)*n,cudaMemcpyHostToDevice);
    cudaMemset(PorePressRateg,0,sizeof(float)*n);
    if(PorePressM1g)cudaMemcpy(PorePressM1g,PorePress,sizeof(float)*n,cudaMemcpyHostToDevice);
  }
  //====
  if(UseNormals)cudaMemcpy(BoundNormalg,boundnormal,sizeof(float3)*n,cudaMemcpyHostToDevice);
  if(BoundSlipModeg && boundslipmode)cudaMemcpy(BoundSlipModeg,boundslipmode,sizeof(byte)*n,cudaMemcpyHostToDevice);
  Check_CudaErroor("Failed copying data to GPU.");
}

//==============================================================================
/// Recovers particle data from the GPU and returns the particle number that
/// are less than n if the paeriodic particles are removed.
/// - code: Recovers data of Codeg.
/// - onlynormal: Onlly retains the normal particles, removes the periodic ones.
///
/// Recupera datos de particulas de la GPU y devuelve el numero de particulas que
/// sera menor que n si se eliminaron las periodicas.
/// - code: Recupera datos de Codeg.
/// - onlynormal: Solo se queda con las normales, elimina las particulas periodicas.
//==============================================================================
unsigned JSphGpu::ParticlesDataDown(unsigned n,unsigned pini,bool code,bool onlynormal){
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  if(Nstep>=4000000 && Nstep<=4360000)C08CausalSaveTotals(DirOut);
#endif
  unsigned num=n;
  cudaMemcpy(Idp    ,Idpg    +pini,sizeof(unsigned)*n,cudaMemcpyDeviceToHost);
  cudaMemcpy(Posxy  ,Posxyg  +pini,sizeof(double2) *n,cudaMemcpyDeviceToHost);
  cudaMemcpy(Posz   ,Poszg   +pini,sizeof(double)  *n,cudaMemcpyDeviceToHost);
  cudaMemcpy(Velrhop,Velrhopg+pini,sizeof(float4)  *n,cudaMemcpyDeviceToHost);
  if(AuxFSType && FSTypeg)cudaMemcpy(AuxFSType,FSTypeg+pini,sizeof(unsigned)*n,cudaMemcpyDeviceToHost);
  if(AuxFSNormal && FSNormalg)cudaMemcpy(AuxFSNormal,FSNormalg+pini,sizeof(tfloat3)*n,cudaMemcpyDeviceToHost);
  if(AuxPosDiv && PosDivg)cudaMemcpy(AuxPosDiv,PosDivg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  if(PoroJ && PoroJg)cudaMemcpy(PoroJ,PoroJg+pini,sizeof(double)*n,cudaMemcpyDeviceToHost);
  if(PoroTheta && PoroThetag)cudaMemcpy(PoroTheta,PoroThetag+pini,sizeof(double)*n,cudaMemcpyDeviceToHost);
  if(AuxHydroMechLoadAce && HydroMechLoadAceg)cudaMemcpy(AuxHydroMechLoadAce,HydroMechLoadAceg+pini,sizeof(tfloat3)*n,cudaMemcpyDeviceToHost);
  if(HydroMech && PorePressg && PorePress0g){
    cudaMemcpy(PorePress,PorePressg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
    cudaMemcpy(PorePress0,PorePress0g+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  }
  if(code || onlynormal)cudaMemcpy(Code,Codeg+pini,sizeof(typecode)*n,cudaMemcpyDeviceToHost);
  //==mdbr
  cudaMemcpy(Sigma,Sigmag+pini,sizeof(tsymatrix3d)*n,cudaMemcpyDeviceToHost);
  cudaMemcpy(Kplastic,Kplasticg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  cudaMemcpy(KplasticDk,KplasticDkg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  //
  Check_CudaErroor("Failed copying data from GPU.");
  //-Eliminates abnormal particles (periodic and others). | Elimina particulas no normales (periodicas y otras).
  if(onlynormal){
    unsigned ndel=0;
    for(unsigned p=0;p<n;p++){
      const bool normal=CODE_IsNormal(Code[p]);
      if(ndel && normal){
        Idp[p-ndel]    =Idp[p];
        Posxy[p-ndel]  =Posxy[p];
        Posz[p-ndel]   =Posz[p];
        Velrhop[p-ndel]=Velrhop[p];
        Code[p-ndel]   =Code[p];
        if(AuxFSType)AuxFSType[p-ndel]=AuxFSType[p];
        if(AuxFSNormal)AuxFSNormal[p-ndel]=AuxFSNormal[p];
        if(AuxPosDiv)AuxPosDiv[p-ndel]=AuxPosDiv[p];
        if(PoroJ)PoroJ[p-ndel]=PoroJ[p];
        if(PoroTheta)PoroTheta[p-ndel]=PoroTheta[p];
        if(AuxHydroMechLoadAce)AuxHydroMechLoadAce[p-ndel]=AuxHydroMechLoadAce[p];
        if(HydroMech && PorePress && PorePress0){
          PorePress[p-ndel]=PorePress[p];
          PorePress0[p-ndel]=PorePress0[p];
        }
        //==== mdbr
		Sigma[p-ndel]  =Sigma[p];
        Kplastic[p-ndel] = Kplastic[p];
        KplasticDk[p-ndel] = KplasticDk[p];
      }
      if(!normal)ndel++;
    }
    num-=ndel;
  }
  //-Converts data to a simple format. | Convierte datos a formato simple.
  for(unsigned p=0;p<n;p++){
    AuxPos[p]=TDouble3(Posxy[p].x,Posxy[p].y,Posz[p]);
    AuxVel[p]=TFloat3(Velrhop[p].x,Velrhop[p].y,Velrhop[p].z);
    AuxRhop[p]=Velrhop[p].w;
    //==== mdbr
    AuxSigma_xx_yy_zz[p]=TFloat3(float(Sigma[p].xx),float(Sigma[p].yy),float(Sigma[p].zz));
    AuxSigma_xy_yz_xz[p]=TFloat3(float(Sigma[p].xy),float(Sigma[p].yz),float(Sigma[p].xz));
    AuxKplastic[p]=Kplastic[p];
    AuxKplasticDk[p]=KplasticDk[p];
    if(HydroMech && AuxPorePress && AuxPorePress0 && PorePress && PorePress0){
      AuxPorePress[p]=PorePress[p];
      AuxPorePress0[p]=PorePress0[p];
    }
  }
  return(num);
}

//==============================================================================
/// Initialises CUDA device.
/// Inicializa dispositivo CUDA.
//==============================================================================
void JSphGpu::SelecDevice(int gpuid){
  //-Shows information on available GPUs.
  JDsGpuInfo::ShowGpusInfo(Log);
  //-GPU selection.
  Log->Print("[GPU Hardware]");
  GpuInfo->SelectGpu(gpuid);
  GpuInfo->ShowSelectGpusInfo(Log);
  cudaSetDevice(GpuInfo->GetGpuId());
}

//==============================================================================
/// Configures BlockSize for main interaction CUDA kernels.
//==============================================================================
void JSphGpu::ConfigBlockSizes(bool usezone,bool useperi){
  Log->Print(" ");
  BlockSizesStr="";
  if(CellMode==CELLMODE_Full || CellMode==CELLMODE_Half){
    const bool lamsps=(TVisco==VISCO_LaminarSPS);
    BlockSizes.forcesbound=BlockSizes.forcesfluid=BlockSizes.forcesdem=BSIZE_FORCES;
    //-Collects kernel information.
    StKerInfo kerinfo;
    memset(&kerinfo,0,sizeof(StKerInfo));
    StDivDataGpu divdatag;
    memset(&divdatag,0,sizeof(StDivDataGpu));
    #ifndef DISABLE_BSMODES
      const StInterParmsg parms=StrInterParmsg(Simulate2D
        ,Symmetry  //<vs_syymmetry>
        ,TKernel,FtMode
        ,lamsps,TDensity,ShiftingMode
        ,TMdbc2
        ,0,0,0,0,100,0,0
        ,0,0,divdatag,NULL
        ,NULL,NULL,NULL,NULL,NULL,NULL
        ,NULL,NULL
        ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
        ,NULL,NULL,NULL,NULL
        ,NULL
        ,NULL,NULL
        ,NULL
        ,NULL,NULL
        ,NULL,NULL
        ,false
        ,NULL
        ,NULL
        ,NULL
        ,NULL,&kerinfo);
      cusph::Interaction_Forces(parms);
      if(UseDEM)cusph::Interaction_ForcesDem(BlockSizes.forcesdem,CaseNfloat,divdatag,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,&kerinfo);
    #endif
    //Log->Printf("====> bound -> rg:%d  bs:%d  bsmax:%d",kerinfo.forcesbound_rg,kerinfo.forcesbound_bs,kerinfo.forcesbound_bsmax);
    //Log->Printf("====> fluid -> rg:%d  bs:%d  bsmax:%d",kerinfo.forcesfluid_rg,kerinfo.forcesfluid_bs,kerinfo.forcesfluid_bsmax);
    //Log->Printf("====> dem   -> rg:%d  bs:%d  bsmax:%d",kerinfo.forcesdem_rg  ,kerinfo.forcesdem_bs  ,kerinfo.forcesdem_bsmax);
    Log->Printf("BlockSize calculation mode: Fixed.");
    const string txb=fun::PrintStr("BsForcesBound=%d ",BlockSizes.forcesbound)+(kerinfo.forcesbound_rg? fun::PrintStr("(%d regs)",kerinfo.forcesbound_rg): string("(? regs)"));
    const string txf=fun::PrintStr("BsForcesFluid=%d ",BlockSizes.forcesfluid)+(kerinfo.forcesfluid_rg? fun::PrintStr("(%d regs)",kerinfo.forcesfluid_rg): string("(? regs)"));
    const string txd=fun::PrintStr("BsForcesDem=%d "  ,BlockSizes.forcesdem)  +(kerinfo.forcesdem_rg  ? fun::PrintStr("(%d regs)",kerinfo.forcesdem_rg  ): string("(? regs)"));
    Log->Print(string("  ")+txb);
    Log->Print(string("  ")+txf);
    if(UseDEM)Log->Print(string("  ")+txd);
    if(!BlockSizesStr.empty())BlockSizesStr=BlockSizesStr+" - ";
    BlockSizesStr=BlockSizesStr+txb+" - "+txf;
    if(UseDEM)BlockSizesStr=BlockSizesStr+" - "+txd;
  }
  else Run_Exceptioon("CellMode unrecognised.");
  Log->Print(" ");
}

//==============================================================================
/// Configures execution mode in the GPU.
/// Configura modo de ejecucion en GPU.
//==============================================================================
void JSphGpu::ConfigRunMode(){
  Hardware=GpuInfo->GetHardware();
  //-Defines RunMode.
  RunMode="";
  if(Stable)RunMode=RunMode+(!RunMode.empty()? " - ": "")+"Stable";
  RunMode=RunMode+(!RunMode.empty()? " - ": "")+"Pos-Cell";
  RunMode=RunMode+(!RunMode.empty()? " - ": "")+"Single-GPU";
  //-Shows RunMode.
  Log->Print(" ");
  Log->Print(fun::VarStr("RunMode",RunMode));
  Log->Print(" ");
}

//==============================================================================
/// Adjusts variables of particles of floating bodies.
//==============================================================================
void JSphGpu::InitFloating(){
  if(PartBegin){
    JPartFloatBi4Load ftdata;
    ftdata.LoadFile(PartBeginDir);
    //-Checks if the constant data match.
    //-Comprueba coincidencia de datos constantes.
    for(unsigned cf=0;cf<FtCount;cf++){
      const StFloatingData &ft=FtObjs[cf];
      ftdata.CheckHeadData(cf,ft.mkbound,ft.begin,ft.count,ft.mass,ft.massp);
    }
    //-Loads PART data.
    ftdata.LoadPart(PartBegin);
    for(unsigned cf=0;cf<FtCount;cf++){
      FtObjs[cf].center=ftdata.GetPartCenter(cf);
      FtObjs[cf].fvel  =ftdata.GetPartVelLin(cf);
      FtObjs[cf].fomega=ftdata.GetPartVelAng(cf);
      FtObjs[cf].radius=ftdata.GetHeadRadius(cf);
    }
    DemDtForce=ftdata.GetPartDemDtForce();
  }
  //-Copies massp values to GPU.
  {
    float *massp=new float[FtCount];
    for(unsigned cf=0;cf<FtCount;cf++)massp[cf]=FtObjs[cf].massp;
    cudaMemcpy(FtoMasspg,massp,sizeof(float)*FtCount,cudaMemcpyHostToDevice);
    delete[] massp;
  }
  //-Copies floating values to GPU.
  {
    typedef struct{
      unsigned pini;
      unsigned np;
      float radius;
      float massp;
    }stdata;

    stdata   *datp  =new stdata  [FtCount];
    float    *ftmass=new float   [FtCount];
    byte     *constr=new byte    [FtCount];
    tdouble3 *center=new tdouble3[FtCount];
    tfloat3  *angles=new tfloat3 [FtCount];
    tfloat3  *velace=new tfloat3 [FtCount*4];
    tfloat4  *inert8=new tfloat4 [FtCount*2];
    float    *inert1=new float   [FtCount];
    memset(velace,0,sizeof(tfloat3)*FtCount*4);
    for(unsigned cf=0;cf<FtCount;cf++){
      const StFloatingData &fobj=FtObjs[cf];
      datp[cf].pini=fobj.begin-CaseNpb;
      datp[cf].np=fobj.count;
      datp[cf].radius=fobj.radius;
      datp[cf].massp=fobj.massp;
      ftmass[cf]=fobj.mass;
      constr[cf]=fobj.constraints;
      center[cf]=fobj.center;
      angles[cf]=fobj.angles;
      velace[cf]=fobj.fvel;
      velace[FtCount+cf]=fobj.fomega;
      const tmatrix3f v=fobj.inertiaini;
      inert8[cf*2]  =TFloat4(v.a11,v.a12,v.a13,v.a21);
      inert8[cf*2+1]=TFloat4(v.a22,v.a23,v.a31,v.a32);
      inert1[cf]    =v.a33;
    }
    cudaMemcpy(FtoDatpg       ,datp  ,sizeof(float4)   *FtCount  ,cudaMemcpyHostToDevice);
    cudaMemcpy(FtoMassg       ,ftmass,sizeof(float)    *FtCount  ,cudaMemcpyHostToDevice);
    cudaMemcpy(FtoConstraintsg,constr,sizeof(byte)     *FtCount  ,cudaMemcpyHostToDevice);
    cudaMemcpy(FtoCenterg     ,center,sizeof(double3)  *FtCount  ,cudaMemcpyHostToDevice);
    cudaMemcpy(FtoAnglesg     ,angles,sizeof(float3)   *FtCount  ,cudaMemcpyHostToDevice);
    cudaMemcpy(FtoVelAceg     ,velace,sizeof(float3)   *FtCount*4,cudaMemcpyHostToDevice);
    cudaMemcpy(FtoInertiaini8g,inert8,sizeof(float4)   *FtCount*2,cudaMemcpyHostToDevice);
    cudaMemcpy(FtoInertiaini1g,inert1,sizeof(float)    *FtCount  ,cudaMemcpyHostToDevice);
    delete[] datp;
    delete[] ftmass;
    delete[] center;
    delete[] angles;
    delete[] velace;
    delete[] inert8;
    delete[] inert1;
  }
  //-Copies data object for DEM to GPU.
  if(UseDEM){ //(DEM)
    float4 *data=new float4[DemDataSize];
    for(unsigned c=0;c<DemDataSize;c++){
      data[c].x=DemData[c].mass;
      data[c].y=DemData[c].tau;
      data[c].z=DemData[c].kfric;
      data[c].w=DemData[c].restitu;
    }
    cudaMemcpy(DemDatag,data,sizeof(float4)*DemDataSize,cudaMemcpyHostToDevice);
    delete[] data;
  }
}

//==============================================================================
/// Initialises arrays and variables for the execution.
/// Inicializa vectores y variables para la ejecucion.
//==============================================================================
void JSphGpu::InitRunGpu(){
  ParticlesDataDown(Np,0,false,false);
  InitRun(Np,Idp,AuxPos);

  if(TStep==STEP_Verlet){cudaMemcpy(VelrhopM1g,Velrhopg,sizeof(float4)*Np,cudaMemcpyDeviceToDevice);
  //======mdbr
  cudaMemcpy(SigmaM1g,Sigmag,sizeof(tsymatrix3d)*Np,cudaMemcpyDeviceToDevice);
  cudaMemcpy(KplasticM1g,Kplasticg,sizeof(float)*Np,cudaMemcpyDeviceToDevice);
  if(HydroMech && PorePressM1g)cudaMemcpy(PorePressM1g,PorePressg,sizeof(float)*Np,cudaMemcpyDeviceToDevice);
  }
  if(HydroMech && PorePressRateg)cudaMemset(PorePressRateg,0,sizeof(float)*Np);
  if(TVisco==VISCO_LaminarSPS)cudaMemset(SpsTaug,0,sizeof(tsymatrix3f)*Np);
  if(CaseNfloat)InitFloating();
  if(MotionVelg)cudaMemset(MotionVelg,0,sizeof(float3)*Np);
  if(BoundModeg)cudaMemset(BoundModeg,BMODE_DBC,sizeof(byte)*Np);
  if(TangenVelg)cudaMemset(TangenVelg,0,sizeof(float3)*Np);
  if(CorrMatg)cudaMemset(CorrMatg,0,sizeof(tmatrix3d)*Np);
  if(FSTypeg)cudaMemset(FSTypeg,0,sizeof(unsigned)*Np);
  if(FSNormalg)cudaMemset(FSNormalg,0,sizeof(float3)*Np);
  if(PosDivg)cudaMemset(PosDivg,0,sizeof(float)*Np);
  Check_CudaErroor("Failed initializing variables for execution.");
}

//==============================================================================
/// Computes free-surface classification with the lightweight umbrella algorithm.
//==============================================================================
void JSphGpu::ComputeFreeSurfaceTracking(){
  if(!Np || !DivData.beginendcell || !CorrMatg || !FSTypeg || !FSNormalg || !PosDivg)return;
  if(DynamicPoreWall)ComputeDynamicPoreWallStateGpu();
  const bool marknearfs=false; //-Near-free-surface search is retained but disabled for the global pair-wise confinement path.
  cusph::ComputeFreeSurfaceTracking(TKernel,Simulate2D,Np,Npb,DivData,Dcellg,PosCellg,Velrhopg,Codeg,CorrMatg,FSTypeg,FSNormalg,PosDivg,marknearfs,PorosityFeedback? PoroJg: NULL);
  Check_CudaErroor("Failed computing free-surface tracking.");
  if(DynamicPoreWall){
    //-The wall fit reads fluid images: native C must be extended first.
    unsigned *ridpg=PrepareDynamicPorePeriodicGpu();
    if(ridpg)ArraysGpu->Free(ridpg);
    ComputeDynamicPoreWallMatrixGpu();
  }
}

//==============================================================================
/// Returns true when the drained pore-pressure boundary is active.
//==============================================================================
bool JSphGpu::IsHydroMechDrainageActive()const{
  if(!HydroMech || !HydroMechDrainage)return(false);
  if(TimeStep>=HydroMechDrainageStartTime)return(true);
  if(!HydroMechDrainageFixedGrid)return(false);
  //-Match CPU at the nominal event step, correcting accumulated-time roundoff only.
  const double event=HydroMechDrainageStartTime;
  const double eps=std::numeric_limits<double>::epsilon();
  const double grid=double(Nstep)*FixedDt->GetFixedValue();
  return(fabs(grid-event)<=4*eps*event && event-TimeStep<=8*eps*double(Nstep)*event);
}

//==============================================================================
/// Enforces drained pore pressure on selected boundary particles.
//==============================================================================
void JSphGpu::ApplyFreeSurfacePorePressure(){
  if(!HydroMech || !PorePressg || !FSTypeg)return;
  const bool drainfs=IsHydroMechDrainageActive();
  cusph::ApplyFreeSurfacePorePressure(Np,Npb,drainfs,HydroMechTopLoadMode,Posxyg,Codeg,FSTypeg,PorePressg,DynamicPorePressure? PorePressRateg: NULL);
  if(DynamicPorePressure && drainfs && PeriActive){
    //-Projection changes native p after cloning; refresh before any wall/neighbour read.
    unsigned *ridpg=PrepareDynamicPorePeriodicGpu();
    if(ridpg)ArraysGpu->Free(ridpg);
  }
  ApplyYaoTopStripPorePressureExtrapolation();
  Check_CudaErroor("Failed applying free-surface pore pressure.");
}

//==============================================================================
/// Extrapolates pore pressure to the impermeable Yao strip contact surface.
//==============================================================================
void JSphGpu::ApplyYaoTopStripPorePressureExtrapolation(){
  if((HydroMechTopLoadMode!=HMLOAD_TopStripVertical && HydroMechTopLoadMode!=HMLOAD_LianFlexibleStrip) || !PorePressg || !FSTypeg || !DivData.beginendcell)return;
  cusph::ExtrapolateYaoTopStripPorePressure(TKernel,Simulate2D,Np,Npb,HydroMechTopLoadMode,DivData,Dcellg
    ,Posxyg,Poszg,Velrhopg,Codeg,FSTypeg,PorePressg);
  Check_CudaErroor("Failed extrapolating strip contact pore pressure.");
}

//==============================================================================
/// Applies q0 ramp surcharge as an acceleration on selected free-surface soil.
//==============================================================================
void JSphGpu::ApplyHydroMechTopLoadAcceleration(){
  if(!HydroMech || HydroMechTopLoadMode==HMLOAD_None || HydroMechTopLoadMode==HMLOAD_FlexibleConfinement || !Aceg || !FSTypeg || !FSNormalg)return;
  if(HydroMechTopLoadMode!=HMLOAD_TopVertical && HydroMechTopLoadMode!=HMLOAD_TopStripVertical && HydroMechTopLoadMode!=HMLOAD_LianFlexibleStrip && HydroMechTopLoadMode!=HMLOAD_TopKernelBand)return;
  const double q0=double(HydroMechTopLoadQ0);
  if(q0<=0)return;
  const double tramp=HydroMechTopLoadRampTime;
  const double q=(tramp>0 && TimeStep<tramp? q0*max(0.0,TimeStep)/tramp: q0);
  if(q<=0)return;
  const double por=double(SoilCte.Porosity);
  const double rhol=double(SoilCte.PoreWaterRho);
  const double rhos=((1.0-por)>0? (double(RhopZero)-por*rhol)/(1.0-por): double(RhopZero));
  const double rhomix=(rhos>0? (1.0-por)*rhos+por*rhol: double(RhopZero));
  const double denom=rhomix*double(Dp);
  if(denom<=0)return;
  const float accmag=float(q/denom);
  cusph::ApplyHydroMechTopLoadAcceleration(Np,Npb,HydroMechTopLoadMode,accmag
    ,Posxyg,Poszg,Codeg,FSTypeg,FSNormalg,Aceg,HydroMechLoadAceg);
  Check_CudaErroor("Failed applying hydromechanical top load.");
}

//==============================================================================
/// Redistributes the existing top load over its vertical kernel-support band.
//==============================================================================
void JSphGpu::NormalizeHydroMechTopBandLoad(){
  if(!HydroMech || HydroMechTopLoadMode!=HMLOAD_TopKernelBand)return;
  const tdouble3 totals=cusph::ComputeHydroMechTopBandTotals(Np,Npb,double(MassFluid),double(KernelSize)
    ,Poszg,Codeg,HydroMechLoadAceg,HydroMechTopLoadRawg,CellDiv->GetAuxMem(cusph::HydroMechTopBandAuxSize(Np)),PorosityFeedback? PoroJg: NULL);
  Check_CudaErroor("Failed reducing hydromechanical top-band load.");
  if(totals.y==0)return;
  if(!(totals.z<0))Run_Exceptioon("TopKernelBand requires a negative raw vertical load on the top support band.");
  cusph::ApplyHydroMechTopBandLoad(Np,Npb,totals.x,double(KernelSize),totals.y/totals.z
    ,Poszg,Codeg,HydroMechTopLoadRawg,Aceg,HydroMechLoadAceg);
  Check_CudaErroor("Failed applying normalized hydromechanical top-band load.");
}

//==============================================================================
/// Updates free-surface tracking and applies drained pore pressure.
//==============================================================================
void JSphGpu::ApplyPorePressureBoundaries(){
  if(!HydroMech || !PorePressg || !DivData.beginendcell)return;
  ComputeFreeSurfaceTracking();
  ApplyFreeSurfacePorePressure();
  if(HydroMechFreeSeepage && !PorePressPreg){
#ifdef C08_STAGE_TRACE
    const bool c08traceponding=C08TraceBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,0.,C08_TRACE_PONDING,Idpg,FSTypeg,PorePressRateg);
#endif
    //-Completed geometry only; predictor pressure/rate are not constrained by this policy.
    cusph::ApplyFreeSurfacePorePressure(Np,Npb,false,HydroMechTopLoadMode,Posxyg,Codeg,FSTypeg,PorePressg,NULL,true);
    Check_CudaErroor("Failed applying completed-step free-seepage ponding.");
#ifdef C08_STAGE_TRACE
    C08TraceEnd(c08traceponding,DirOut);
#endif
    //-The next force/save refreshes wall state before consuming its pressure samples.
  }
}

//==============================================================================
/// Applies Shepard regularization to the excess pore-pressure field.
//==============================================================================
void JSphGpu::ShepardRegularizePorePressure(){
  if(!HydroMech || !PoreShepardRegularization || !PorePressg || !PorePress0g || !PoreShepardInterval || !DivData.beginendcell)return;
  float *porepressnew=ArraysGpu->ReserveFloat();
  cudaMemcpy(porepressnew,PorePressg,sizeof(float)*Np,cudaMemcpyDeviceToDevice);
  cusph::ShepardRegularizePorePressure(TKernel,Simulate2D,Np,Npb,IsHydroMechDrainageActive()
    ,HydroMechTopLoadMode,DivData,Dcellg,Posxyg,Poszg,Velrhopg,Codeg,FSTypeg,BoundModeg,BoundSlipModeg,PorePress0g,PorePressg,porepressnew,(DynamicPorePressure && PorosityFeedback? PoroJg: NULL));
  cudaMemcpy(PorePressg+Npb,porepressnew+Npb,sizeof(float)*(Np-Npb),cudaMemcpyDeviceToDevice);
  ArraysGpu->Free(porepressnew); porepressnew=NULL;
  ApplyFreeSurfacePorePressure();
  if(HydroMechFreeSeepage && !PorePressPreg){
    cusph::ApplyFreeSurfacePorePressure(Np,Npb,false,HydroMechTopLoadMode,Posxyg,Codeg,FSTypeg,PorePressg,NULL,true);
    Check_CudaErroor("Failed applying completed-step free-seepage ponding.");
  }
  Check_CudaErroor("Failed applying pore-pressure Shepard regularization.");
}

//==============================================================================
/// Initialises total/gauge pore-water pressure from a hydrostatic water table.
//==============================================================================
void JSphGpu::InitHydroMechPorePressure(){
  if(!HydroMech || !PorePressg || !PorePress0g || !PorePress || !PorePress0)return;
  if(HydroMechInitMode==HMINIT_None)return;
  cudaMemcpy(Posxy,Posxyg,sizeof(double2)*Np,cudaMemcpyDeviceToHost);
  cudaMemcpy(Posz,Poszg,sizeof(double)*Np,cudaMemcpyDeviceToHost);
  cudaMemcpy(Code,Codeg,sizeof(typecode)*Np,cudaMemcpyDeviceToHost);
  cudaMemcpy(AuxFSType,FSTypeg,sizeof(unsigned)*Np,cudaMemcpyDeviceToHost);
  tfloat3 *bnormal=NULL;
  if(HydroMechInitMode==HMINIT_AnalyticalSelfWeight1D && BoundNormalg){
    try{ bnormal=new tfloat3[Np]; }
    catch(const std::bad_alloc){ Run_Exceptioon("Could not allocate the requested memory."); }
    cudaMemcpy(bnormal,BoundNormalg,sizeof(float3)*Np,cudaMemcpyDeviceToHost);
  }
  Check_CudaErroor("Failed copying data for hydromechanical pore-pressure initialization.");

  const double gnorm=sqrt(double(Gravity.x)*Gravity.x+double(Gravity.y)*Gravity.y+double(Gravity.z)*Gravity.z);
  const double gzabs=fabs(double(Gravity.z));
  const double gammaw=double(SoilCte.PoreWaterRho)*(gzabs>0? gzabs: gnorm);
  unsigned nfs=0;
  unsigned *fsp=NULL;
  if(HydroMechInitMode==HMINIT_FreeSurface){
    for(unsigned p=Npb;p<Np;p++)if(CODE_IsNormal(Code[p]) && CODE_IsFluid(Code[p]) && IsHydroMechTrackedFreeSurface(AuxFSType[p]))nfs++;
    if(!nfs)Run_Exceptioon("No free-surface particles were found for hydromechanical pore-pressure initialization.");
    try{
      fsp=new unsigned[nfs];
    }
    catch(const std::bad_alloc){
      Run_Exceptioon("Could not allocate the requested memory.");
    }
    unsigned c=0;
    for(unsigned p=Npb;p<Np;p++)if(CODE_IsNormal(Code[p]) && CODE_IsFluid(Code[p]) && IsHydroMechTrackedFreeSurface(AuxFSType[p]))fsp[c++]=p;
  }

  double pmin=DBL_MAX,pmax=-DBL_MAX;
  double smin=DBL_MAX,smax=-DBL_MAX;
  double topz=-DBL_MAX;
  bool analyticgravityoff=false;
  double analyticg=gnorm;
  if(HydroMechInitMode==HMINIT_AnalyticalSelfWeight1D){
    analyticgravityoff=(gnorm<=1e-12);
    if(analyticgravityoff)analyticg=9.80665;
    for(unsigned p=Npb;p<Np;p++)if(CODE_IsFluid(Code[p]))topz=max(topz,Posz[p]);
    if(topz==-DBL_MAX)Run_Exceptioon("HydroMechInitMode=AnalyticalSelfWeight1D requires soil particles.");
    topz+=double(Dp)*0.5;
  }
  for(unsigned p=0;p<Np;p++){
    double zwt=HydroMechInitZ;
    if(HydroMechInitMode==HMINIT_FreeSurface){
      const double psx=Posxy[p].x;
      const double psy=Posxy[p].y;
      double distmin=DBL_MAX;
      unsigned pnear=fsp[0];
      for(unsigned c=0;c<nfs;c++){
        const unsigned pfid=fsp[c];
        const double dx=psx-Posxy[pfid].x;
        const double dy=(Simulate2D? 0: psy-Posxy[pfid].y);
        const double dist2=dx*dx+dy*dy;
        if(dist2<distmin){
          distmin=dist2;
          pnear=pfid;
        }
      }
      zwt=Posz[pnear];
    }
    if(HydroMechInitMode==HMINIT_AnalyticalSelfWeight1D){
      double zhydro=Posz[p];
      double zexcess=Posz[p];
      if(!CODE_IsFluid(Code[p]) && bnormal && (bnormal[p].x!=0 || bnormal[p].y!=0 || bnormal[p].z!=0)){
        tdouble3 pposexcess=TDouble3(Posxy[p].x+bnormal[p].x,Posxy[p].y+bnormal[p].y,Posz[p]+bnormal[p].z);
        if(PeriActive)pposexcess=UpdatePeriodicPos(pposexcess);
        zexcess=pposexcess.z;
      }
      const double depthhydro=max(0.,topz-zhydro);
      const double depthghost=max(0.,topz-zexcess);
      const double kwn=double(SoilCte.PoreWaterBulkModulus)/double(SoilCte.Porosity);
      const double mcon=double(SoilCte.ModulusK)+4.0*double(SoilCte.ModulusG)/3.0;
      const double undrained_ratio=kwn/(mcon+kwn);
      const double effective_ratio=mcon/(mcon+kwn);
      const double rhosw=(analyticgravityoff? double(RhopZero): max(0.,double(RhopZero)-double(SoilCte.PoreWaterRho)));
      const double hydroactual=double(SoilCte.PoreWaterRho)*analyticg*depthhydro;
      const double excessghost=undrained_ratio*rhosw*analyticg*depthghost;
      float hydro=(analyticgravityoff? 0.f: float(hydroactual));
      float pw=(analyticgravityoff? float(excessghost): float(hydroactual+excessghost));
      if(p>=Npb && CODE_IsFluid(Code[p]) && IsHydroMechTrackedFreeSurface(AuxFSType[p])){
        hydro=0.f;
        pw=0.f;
      }
      PorePress[p]=pw;
      PorePress0[p]=hydro;
      if(Sigma){
        const float szz=float(-effective_ratio*rhosw*analyticg*depthghost);
        const float k0=float(SoilCte.PRvs/(1.f-SoilCte.PRvs));
        tsymatrix3f sig={k0*szz,0.f,0.f,k0*szz,0.f,szz};
        Sigma[p]=ToTSymMatrix3d(sig);
        smin=min(smin,double(szz));
        smax=max(smax,double(szz));
      }
    }
    else{
      float pw=float(gammaw*max(0.,zwt-Posz[p]));
      if(DynamicPorePressure && HydroMechInitMode==HMINIT_ConstantZ && p<Npb && CODE_IsFixed(Code[p]))
        pw=float(gammaw*(zwt-Posz[p])); //-Affine wall baseline, including samples above the water table.
      if(HydroMechInitMode==HMINIT_FreeSurface && p>=Npb && CODE_IsFluid(Code[p]) && IsHydroMechTrackedFreeSurface(AuxFSType[p]))pw=0.f;
      PorePress[p]=pw;
      PorePress0[p]=pw;
    }
    pmin=min(pmin,double(PorePress[p]));
    pmax=max(pmax,double(PorePress[p]));
  }
  delete[] fsp; fsp=NULL;
  delete[] bnormal; bnormal=NULL;
  cudaMemcpy(PorePressg,PorePress,sizeof(float)*Np,cudaMemcpyHostToDevice);
  cudaMemcpy(PorePress0g,PorePress0,sizeof(float)*Np,cudaMemcpyHostToDevice);
  if(PorePressRateg)cudaMemset(PorePressRateg,0,sizeof(float)*Np);
  if(PorePressM1g)cudaMemcpy(PorePressM1g,PorePress,sizeof(float)*Np,cudaMemcpyHostToDevice);
  if(HydroMechInitMode==HMINIT_AnalyticalSelfWeight1D && Sigma)cudaMemcpy(Sigmag,Sigma,sizeof(tsymatrix3d)*Np,cudaMemcpyHostToDevice);
  Check_CudaErroor("Failed uploading hydromechanical pore-pressure data.");
  Log->Printf("Hydromechanics: initial pore pressure assigned to %u particles (%s, min=%g, max=%g)."
    ,Np,GetHydroMechInitModeName(HydroMechInitMode).c_str(),pmin,pmax);
  if(HydroMechInitMode==HMINIT_AnalyticalSelfWeight1D){
    Log->Printf("Hydromechanics: analytical 1D self-weight mode=%s, reference gravity=%g, hydrostatic baseline=%s."
      ,(analyticgravityoff? "gravity-off dissipation": "gravity-on self-weight"),analyticg,(analyticgravityoff? "zero": "retained"));
    Log->Printf("Hydromechanics: analytical 1D self-weight effective stress initialized (sigma_zz min=%g, max=%g).",smin,smax);
  }
}

//==============================================================================
/// Prepares variables for interaction.
/// Prepara variables para interaccion.
//==============================================================================
void JSphGpu::PreInteractionVars_Forces(unsigned np,unsigned npb){
  //-Initialise arrays.
  const unsigned npf=np-npb;
  cudaMemset(ViscDtg,0,sizeof(float)*np);                                //ViscDtg[]=0
  cudaMemset(Arg,0,sizeof(float)*np);                                    //Arg[]=0
  if(Deltag)cudaMemset(Deltag,0,sizeof(float)*np);                       //Deltag[]=0
  cudaMemset(Aceg,0,sizeof(tfloat3)*np);                                 //Aceg[]=(0,0,0)
  if(HydroMechLoadAceg)cudaMemset(HydroMechLoadAceg,0,sizeof(float3)*np); //HydroMechLoadAceg[]=(0,0,0)
  if(HydroMechTopLoadRawg)cudaMemset(HydroMechTopLoadRawg,0,sizeof(float)*np);
  if(NoPenShiftg)cudaMemset(NoPenShiftg,0,sizeof(float4)*np);             //NoPenShiftg[]=(0,0,0,0)
  if(SpsGradvelg)cudaMemset(SpsGradvelg+npb,0,sizeof(tsymatrix3f)*npf);  //SpsGradvelg[]=(0,0,0,0,0,0).
  //====mdbr
  cudaMemset(Rsigmag,0,sizeof(tsymatrix3f)*np);
  if(HydroMech && PorePressRateg && !DynamicPorePressure)cudaMemset(PorePressRateg,0,sizeof(float)*np);
  if(PoroThetag)cudaMemset(PoroThetag,0,sizeof(double)*np);
  //======
  //-Select particles for shifting.
  if(ShiftPosfsg)Shifting->InitGpu(npf,npb,Posxyg,Poszg,ShiftPosfsg);

  //-Apply the extra forces to the correct particle sets.
  if(AccInput)AccInput->RunGpu(TimeStep,Gravity,npf,npb,Codeg,Posxyg,Poszg,Velrhopg,Aceg);
}

//==============================================================================
/// Prepares variables for interaction.
/// Prepara variables para interaccion.
//==============================================================================
void JSphGpu::PreInteraction_Forces(){
  Timersg->TmStart(TMG_CfPreForces,false);
  //-Assign memory.
  ViscDtg=ArraysGpu->ReserveFloat();
  Arg=ArraysGpu->ReserveFloat();
  Aceg=ArraysGpu->ReserveFloat3();
  Rsigmag=ArraysGpu->ReserveSymatrix3f();//ruofeng
  if(SoilBoundaryDerivativeSPR || DynamicPoreWall)BoundDerivativeVelg=ArraysGpu->ReserveFloat3();
  if(HydroMechTopLoadMode==HMLOAD_TopKernelBand)HydroMechTopLoadRawg=ArraysGpu->ReserveFloat();
  if(ArtificialStress)ArtificialStressg=ArraysGpu->ReserveSymatrix3f();
  if(DDTArray)Deltag=ArraysGpu->ReserveFloat();
  if(Shifting)ShiftPosfsg=ArraysGpu->ReserveFloat4();
  if(TVisco==VISCO_LaminarSPS)SpsGradvelg=ArraysGpu->ReserveSymatrix3f();
  if(TMdbc2==MDBC2_NoPen)NoPenShiftg=ArraysGpu->ReserveFloat4();

  //-Initialise arrays.
  PreInteractionVars_Forces(Np,Npb);
  if(ArtificialStressg && !PorosityFeedback)cusph::ComputeArtificialStress(Np,Npb,Codeg,Velrhopg,Sigmag,ArtificialStressg);

  //-Computes VelMax: Includes the particles from floating bodies and does not affect the periodic conditions.
  //-Calcula VelMax: Se incluyen las particulas floatings y no afecta el uso de condiciones periodicas.
  const unsigned pini=(DtAllParticles? 0: Npb);
  cusph::ComputeVelMod(Np-pini,Velrhopg+pini,ViscDtg);
  float velmax=cusph::ReduMaxFloat(Np-pini,0,ViscDtg,CellDiv->GetAuxMem(cusph::ReduMaxFloatSize(Np-pini)));
  VelMax=sqrt(velmax);
  cudaMemset(ViscDtg,0,sizeof(float)*Np);           //ViscDtg[]=0
  ViscDtMax=0;
  Timersg->TmStop(TMG_CfPreForces,true);
  Check_CudaErroor("Failed calculating VelMax.");
}

//==============================================================================
/// Uses current wall and projected surface pressure for J-based artificial stress.
//==============================================================================
void JSphGpu::PrepareArtificialStress(){
  if(!PorosityFeedback || !ArtificialStressg)return;
  //-The certified gravity preload keeps the original AS=0 operator.
  if(GravityPreload && !GravityPreloadReleased)cudaMemset(ArtificialStressg,0,sizeof(tsymatrix3f)*Np);
  else cusph::ComputeArtificialStress(Np,Npb,Codeg,Velrhopg,Sigmag,ArtificialStressg,PorePressg);
  Check_CudaErroor("Failed preparing current-J artificial stress.");
}

//==============================================================================
/// Frees memory allocated for ArraysGpu.
/// Libera memoria asignada de ArraysGpu.
//==============================================================================
void JSphGpu::PosInteraction_Forces(){
  //-Frees memory allocated in PreInteraction_Forces().
  ArraysGpu->Free(Arg);          Arg=NULL;
  ArraysGpu->Free(Aceg);         Aceg=NULL;
  ArraysGpu->Free(ViscDtg);      ViscDtg=NULL;
  ArraysGpu->Free(Deltag);       Deltag=NULL;
  ArraysGpu->Free(ShiftPosfsg);  ShiftPosfsg=NULL;
  ArraysGpu->Free(SpsGradvelg);  SpsGradvelg=NULL;
  ArraysGpu->Free(NoPenShiftg);  NoPenShiftg=NULL;
  ArraysGpu->Free(Rsigmag);      Rsigmag=NULL;//ruofeng
  ArraysGpu->Free(ArtificialStressg); ArtificialStressg=NULL;//mdbr
  ArraysGpu->Free(HydroMechTopLoadRawg); HydroMechTopLoadRawg=NULL;
  ArraysGpu->Free(BoundDerivativeVelg); BoundDerivativeVelg=NULL;
}

//==============================================================================
/// Updates particles according to forces and dt using Verlet.
/// Actualizacion de particulas segun fuerzas y dt usando Verlet.
//==============================================================================
void JSphGpu::ComputeVerlet(double dt){  //pdtedom
  Timersg->TmStart(TMG_SuComputeStep,false);
  const bool shift=(ShiftingMode!=SHIFT_None);
  const bool inout=(InOut!=NULL);
  const float3 *indirvel=(inout? InOut->GetDirVelg(): NULL);
  VerletStep++;
  //-Allocates memory to compute the displacement.
  //-Asigna memoria para calcular el desplazamiento.
  double2 *movxyg=ArraysGpu->ReserveDouble2();
  double *movzg=ArraysGpu->ReserveDouble();
  //-Computes displacement, velocity and density.
  //-Calcula desplazamiento, velocidad y densidad.
  if(MaterialErrorg)cudaMemset(MaterialErrorg,0,sizeof(unsigned));
  const bool fullstep=(VerletStep<VerletSteps);
  if(fullstep){
    cusphs::ComputeStepVerlet(WithFloating,shift,inout,DPCtes,TMdbc2,Np,Npb,Velrhopg,VelrhopM1g,SigmaM1g,KplasticM1g,Kplasticg,Rsigmag,Arg
      ,Aceg,ShiftPosfsg,indirvel,NoPenShiftg,dt,dt+dt,RhopZero,RhopOutMin,RhopOutMax,Gravity,Codeg,movxyg,movzg,VelrhopM1g,SigmaM1g,KplasticM1g,KplasticDkg,NULL,MaterialErrorg,RequireElasticGravityPreload());
  }
  else{
    cusphs::ComputeStepVerlet(WithFloating,shift,inout,DPCtes,TMdbc2,Np,Npb,Velrhopg,Velrhopg,Sigmag,Kplasticg,Kplasticg,Rsigmag,Arg
      ,Aceg,ShiftPosfsg,indirvel,NoPenShiftg,dt,dt,RhopZero,RhopOutMin,RhopOutMax,Gravity,Codeg,movxyg,movzg,VelrhopM1g,SigmaM1g,KplasticM1g,KplasticDkg,NULL,MaterialErrorg,RequireElasticGravityPreload());
  }
  if(MaterialErrorg){
    try{
      unsigned materialerror=0;
      cudaMemcpy(&materialerror,MaterialErrorg,sizeof(unsigned),cudaMemcpyDeviceToHost);
      Check_CudaErroor("Failed checking GPU material Verlet return.");
      if(materialerror)Run_Exceptioon(fun::PrintStr("GPU material Verlet return rejected the stage (status bits %u).",materialerror));
    }
    catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
  }
  if(HydroMech && PorePressg && PorePressM1g && PorePressRateg){
    if(fullstep)cusph::UpdatePorePressureVerlet(Np,Npb,dt+dt,Codeg,PorePressM1g,PorePressRateg,PorePressM1g);
    else cusph::UpdatePorePressureVerlet(Np,Npb,dt,Codeg,PorePressg,PorePressRateg,PorePressM1g);
  }
  if(!fullstep)VerletStep=0;
  //-The new values are calculated in VelRhopM1g.
  //-Los nuevos valores se calculan en VelrhopM1g.
  swap(Velrhopg,VelrhopM1g);   //-Exchanges Velrhopg and VelrhopM1g. | Intercambia Velrhopg y VelrhopM1g.
  //==== mdbr
  swap(Sigmag,SigmaM1g);
  swap(Kplasticg,KplasticM1g);
  if(HydroMech && PorePressg && PorePressM1g){
    swap(PorePressg,PorePressM1g);
    ApplyFreeSurfacePorePressure();
  }
  //-Applies displacement to non-periodic fluid particles.
  //-Aplica desplazamiento a las particulas fluid no periodicas.
  cusph::ComputeStepPos(PeriActive,WithFloating,Np,Npb,movxyg,movzg,Posxyg,Poszg,Dcellg,Codeg);
  //-Frees memory allocated for the diplacement.
  ArraysGpu->Free(movxyg);   movxyg=NULL;
  ArraysGpu->Free(movzg);    movzg=NULL;
  Timersg->TmStop(TMG_SuComputeStep,false);
}

//==============================================================================
/// Updates particles according to forces and dt using Symplectic-Predictor.
/// Actualizacion de particulas segun fuerzas y dt usando Symplectic-Predictor.
//==============================================================================
void JSphGpu::ComputeSymplecticPre(double dt){
  Timersg->TmStart(TMG_SuComputeStep,false);
  const double dt05=dt*.5;
  const bool shift=false; //(ShiftingMode!=SHIFT_None); //-We strongly recommend running the shifting correction only for the corrector. If you want to re-enable shifting in the predictor, change the value here to "true".
  const bool inout=(InOut!=NULL);
  //-Allocates memory to PRE variables.
  PosxyPreg=ArraysGpu->ReserveDouble2();
  PoszPreg=ArraysGpu->ReserveDouble();
  VelrhopPreg=ArraysGpu->ReserveFloat4();
  //==== mdbr
  SigmaPreg=ArraysGpu->ReserveSymatrix3d();
  if(HydroMech)PorePressPreg=ArraysGpu->ReserveFloat();
  //-Changes data of PRE variables for calculating the new data.
  //-Cambia datos a variables PRE para calcular nuevos datos.
  swap(PosxyPreg,Posxyg);      //-PosxyPre[] <= Posxy[]
  swap(PoszPreg,Poszg);        //-PoszPre[] <= Posz[]
  swap(VelrhopPreg,Velrhopg);  //-VelrhopPre[] <= Velrhop[]
  //==== mdbr
  swap(SigmaPreg,Sigmag);
  if(HydroMech && PorePressPreg)swap(PorePressPreg,PorePressg);
#ifdef C08_STAGE_TRACE
  const bool c08traceupdate=(HydroMech && PorePressg && PorePressPreg && PorePressRateg
    ? C08TraceBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,dt05,C08_TRACE_UPDATE,Idpg,FSTypeg,PorePressRateg): false);
#endif
  if(HydroMech && PorePressg && PorePressPreg && PorePressRateg)
    cusph::UpdatePorePressureSymplectic(Np,Npb,dt05,Codeg,PorePressPreg,PorePressRateg,PorePressg
      ,DynamicPorePressure && IsHydroMechDrainageActive(),HydroMechTopLoadMode,PosxyPreg,FSTypeg);
#ifdef C08_STAGE_TRACE
  C08TraceEnd(c08traceupdate,DirOut);
#endif
  ComputeSymplecticPorosity(false,dt05);
  //-Boundary conditions follow cell division, with matching geometry and neighbours.
  //-Allocate memory to compute the diplacement.
  double2 *movxyg=ArraysGpu->ReserveDouble2();
  double *movzg=ArraysGpu->ReserveDouble();
  //-Compute displacement, velocity and density.
  const float3 *indirvel=(InOut? InOut->GetDirVelg(): NULL);
  if(MaterialErrorg)cudaMemset(MaterialErrorg,0,sizeof(unsigned));
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  bool c08material=false;
  try{c08material=C08CausalBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,dt05,C08_TRACE_MATERIAL
    ,Idpg,FSTypeg,PorePressRateg,PorePressg,PorePressPreg,PoroJPreg,PoroJg,PoroThetag);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif
  cusphs::ComputeStepSymplecticPre(WithFloating,shift,inout,DPCtes,Np,Npb,VelrhopPreg,Arg
    ,Aceg,ShiftPosfsg,SigmaPreg,Kplasticg,Rsigmag,indirvel,dt05,RhopZero,RhopOutMin,RhopOutMax,Gravity
    ,Codeg,movxyg,movzg,Velrhopg,Sigmag,Kplasticg,KplasticDkg,NULL,cusphs::StPorosityRhopState{PorosityFeedback? PoroJg: NULL,PoroJPreg,PoroThetag},MaterialErrorg,RequireElasticGravityPreload());
  if(MaterialErrorg){
    try{
      unsigned materialerror=0;
      cudaMemcpy(&materialerror,MaterialErrorg,sizeof(unsigned),cudaMemcpyDeviceToHost);
      Check_CudaErroor("Failed checking GPU material predictor return.");
      if(materialerror)Run_Exceptioon(fun::PrintStr("GPU material predictor return rejected the stage (status bits %u).",materialerror));
    }
    catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
  }
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  try{C08TraceEnd(c08material,DirOut,true);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif

  //-Applies displacement to non-periodic fluid particles.
  //-Aplica desplazamiento a las particulas fluid no periodicas.
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  bool c08plane=false;
  try{c08plane=(UseDynamicPorePlaneContact()? C08CausalBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,dt05,C08_TRACE_PLANE
    ,Idpg,FSTypeg,PorePressRateg,PorePressg,PorePressPreg,PoroJPreg,PoroJg,PoroThetag): false);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif
  if(UseDynamicPorePlaneContact())cusphs::ProjectFixedPlaneContact(Np,Npb,Codeg,PosxyPreg,PoszPreg
    ,movxyg,movzg,Velrhopg,DynamicPoreContactPlane.x,DynamicPoreContactPlane.z,NULL);
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  try{C08TraceEnd(c08plane,DirOut,true);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif
  cusph::ComputeStepPos2(PeriActive,WithFloating,Np,Npb,PosxyPreg,PoszPreg
    ,movxyg,movzg,Posxyg,Poszg,Dcellg,Codeg);
  //-Frees memory allocated for the displacement.
  ArraysGpu->Free(movxyg);   movxyg=NULL;
  ArraysGpu->Free(movzg);    movzg=NULL;
  //-Copies previous position of the boundaries.
  //-Copia posicion anterior del contorno.
  cudaMemcpy(Posxyg,PosxyPreg,sizeof(double2)*Npb,cudaMemcpyDeviceToDevice);
  cudaMemcpy(Poszg,PoszPreg,sizeof(double)*Npb,cudaMemcpyDeviceToDevice);
  Timersg->TmStop(TMG_SuComputeStep,false);
}

//==============================================================================
/// Updates particles according to forces and dt using Symplectic-Corrector.
/// Actualizacion de particulas segun fuerzas y dt usando Symplectic-Corrector.
//==============================================================================
void JSphGpu::ComputeSymplecticCorr(double dt){
  Timersg->TmStart(TMG_SuComputeStep,false);
  const bool shift=(ShiftingMode!=SHIFT_None);
  const bool inout=(InOut!=NULL);
  //-Allocates memory to calculate the displacement.
  double2 *movxyg=ArraysGpu->ReserveDouble2();
  double *movzg=ArraysGpu->ReserveDouble();
  //-Computes displacement, velocity and density.
  const double dt05=dt*.5;
  const float3 *indirvel=(InOut? InOut->GetDirVelg(): NULL);
  if(MaterialErrorg)cudaMemset(MaterialErrorg,0,sizeof(unsigned));
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  bool c08material=false;
  try{c08material=C08CausalBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,dt,C08_TRACE_MATERIAL
    ,Idpg,FSTypeg,PorePressRateg,PorePressg,PorePressPreg,PoroJPreg,PoroJg,PoroThetag);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif
  cusphs::ComputeStepSymplecticCor(WithFloating,shift,inout,DPCtes,(UseDynamicPorePlaneContact()? MDBC2_Std: TMdbc2),Np,Npb,VelrhopPreg
    ,Arg,Aceg,ShiftPosfsg,SigmaPreg,Kplasticg,Rsigmag,indirvel,NoPenShiftg,dt05,dt,RhopZero,RhopOutMin,RhopOutMax,Gravity
    ,Codeg,movxyg,movzg,Velrhopg,Sigmag,Kplasticg,KplasticDkg,NULL,cusphs::StPorosityRhopState{PorosityFeedback? PoroJg: NULL,PoroJPreg,PoroThetag},MaterialErrorg,RequireElasticGravityPreload());
  if(MaterialErrorg){
    try{
      unsigned materialerror=0;
      cudaMemcpy(&materialerror,MaterialErrorg,sizeof(unsigned),cudaMemcpyDeviceToHost);
      Check_CudaErroor("Failed checking GPU material corrector return.");
      if(materialerror)Run_Exceptioon(fun::PrintStr("GPU material corrector return rejected the stage (status bits %u).",materialerror));
    }
    catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
  }
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  try{C08TraceEnd(c08material,DirOut,true);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif
  if(HydroMech && !DynamicPorePressure && PorePressg && PorePressPreg && PorePressRateg)
    cusph::UpdatePorePressureSymplectic(Np,Npb,dt,Codeg,PorePressPreg,PorePressRateg,PorePressg);
  ComputeSymplecticPorosity(true,dt);
  //-Boundary conditions follow cell division, with matching geometry and neighbours.
  //-Applies displacement to non-periodic fluid particles.
  //-Aplica desplazamiento a las particulas fluid no periodicas.
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  bool c08plane=false;
  try{c08plane=(UseDynamicPorePlaneContact()? C08CausalBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,dt,C08_TRACE_PLANE
    ,Idpg,FSTypeg,PorePressRateg,PorePressg,PorePressPreg,NULL,PoroJg,PoroThetag): false);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif
  if(UseDynamicPorePlaneContact())cusphs::ProjectFixedPlaneContact(Np,Npb,Codeg,PosxyPreg,PoszPreg
    ,movxyg,movzg,Velrhopg,DynamicPoreContactPlane.x,DynamicPoreContactPlane.z,NULL);
#if defined(C08_STAGE_TRACE) && defined(C08_CAUSAL_TRACE)
  try{C08TraceEnd(c08plane,DirOut,true);}
  catch(...){ArraysGpu->Free(movxyg);ArraysGpu->Free(movzg);throw;}
#endif
  cusph::ComputeStepPos2(PeriActive,WithFloating,Np,Npb,PosxyPreg,PoszPreg
    ,movxyg,movzg,Posxyg,Poszg,Dcellg,Codeg);
#ifdef C08_STAGE_TRACE
  const bool c08traceupdate=(HydroMech && DynamicPorePressure && PorePressg && PorePressPreg && PorePressRateg
    ? C08TraceBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,dt,C08_TRACE_UPDATE,Idpg,FSTypeg,PorePressRateg): false);
#endif
  if(HydroMech && DynamicPorePressure && PorePressg && PorePressPreg && PorePressRateg)
    cusph::UpdatePorePressureSymplectic(Np,Npb,dt,Codeg,PorePressPreg,PorePressRateg,PorePressg
      ,IsHydroMechDrainageActive(),HydroMechTopLoadMode,Posxyg,FSTypeg);
#ifdef C08_STAGE_TRACE
  C08TraceEnd(c08traceupdate,DirOut);
#endif
  //-Frees memory allocated for diplacement.
  ArraysGpu->Free(movxyg);   movxyg=NULL;
  ArraysGpu->Free(movzg);    movzg=NULL;
  //-Frees memory allocated for the predictor variables in ComputeSymplecticPre().
  ArraysGpu->Free(PosxyPreg);    PosxyPreg=NULL;
  ArraysGpu->Free(PoszPreg);     PoszPreg=NULL;
  ArraysGpu->Free(VelrhopPreg);  VelrhopPreg=NULL;
  //==== mdbr
  ArraysGpu->Free(SigmaPreg);	SigmaPreg = NULL;
  ArraysGpu->Free(PorePressPreg); PorePressPreg=NULL;
  //====
  Timersg->TmStop(TMG_SuComputeStep,false);
}

//==============================================================================
/// Initialises private J state on bounded GPU fixtures; feedback is separately gated.
//==============================================================================
void JSphGpu::InitPorosityObserverGpu(){
  if(DynamicPoreWall && (!DynamicPorePressure || !CaseNpb))
    Run_Exceptioon("GPU dynamic wall requires the private complete model and fixed boundary particles.");
  if(DynamicPoreConductivity && (!DynamicPorePressure || !std::isfinite(DynamicPoreConductivityCk) || DynamicPoreConductivityCk<=0))
    Run_Exceptioon("GPU variable conductivity requires the private dynamic model and finite Ck>0.");
  if(DynamicPorePressure && (!PorosityObserver || !PorosityFeedback))
    Run_Exceptioon("GPU dynamic pore pressure requires the J observer and feedback together.");
  if(PorosityFeedback && !PorosityObserver)
    Run_Exceptioon("GPU porosity feedback requires the J observer state.");
  if(!PorosityObserver)return;
  const bool loadedcolumn=(DynamicPorePressure && Simulate2D && DynamicPoreWall
    && !DynamicPoreConductivity && !Gravity.x && !Gravity.y && !Gravity.z
    && HydroMechInitMode==HMINIT_None && HydroMechTopLoadMode==HMLOAD_TopKernelBand
    && HydroMechDrainage && HydroMechDrainageFixedGrid);
  const bool allowcolumnstabilization=(HydroMechDynamicSeepage && PorosityFeedback && loadedcolumn
    && PeriX && !PeriY && !PeriZ && !ViscoTime);
  const bool freebody=(HydroMechDynamicSeepage && DynamicPoreFreeBody);
  const bool container=IsDynamicPoreContainerConfig();
  const bool allowartvisco=(allowcolumnstabilization || freebody || container);
  if(SoilHourglassXi!=0 && !allowcolumnstabilization)
    Run_Exceptioon("Dynamic HG requires the public constant-k loaded GPU column; observer-only and private-flag HG combinations remain unsupported.");
  if(allowartvisco && Visco!=0.f && (!std::isfinite(Visco) || Visco<0.f
    || !std::isfinite(ViscoBoundFactor) || ViscoBoundFactor<0.f))
    Run_Exceptioon("Dynamic artificial viscosity requires finite nonnegative constant coefficients.");
  if(!HydroMech || (!Simulate2D && !freebody) || TStep!=STEP_Symplectic || PartBegin || (PorosityFeedback && CaseNpb && !DynamicPoreWall && !freebody) || CaseNmoving
    || InOut || Shifting || (NoPenetration && !(container && IsGravityPreloadHandoff())) || Symmetry || (StrainSoftening && !IsDynamicPorePlasticConfig()) || UseDEM
    || Damping || RelaxZones || AccInput || (!loadedcolumn && !freebody && !container && SoilDamping)
    || !std::isfinite(Gravity.x) || !std::isfinite(Gravity.y) || !std::isfinite(Gravity.z) || Gravity.y!=0
    || (PorosityFeedback && !DynamicPorePressure && (Gravity.x || Gravity.z))
    || (!loadedcolumn && !freebody && (HydroMechDrainage || HydroMechTopLoadMode!=HMLOAD_None))
    || (HydroMechInitMode!=HMINIT_None && !(container && HydroMechInitMode==HMINIT_ConstantZ))
    || !PoreCompressionGradCorr || PoreCompressionSourceMode!=0 || PeriY)
    Run_Exceptioon("GPU porosity observer requires fresh bounded elastic Symplectic corrected-pair fixtures without shifting; damping/load/drainage require the constant-k column or admitted 3-D free body; in-plane gravity with feedback requires the complete dynamic-rate model.");
  if(!(SoilCte.Porosity>0 && SoilCte.Porosity<1) || !PoroJg || !PoroThetag)
    Run_Exceptioon("GPU porosity observer requires 0<n0<1 and allocated double state.");
  if(DynamicPoreConductivity && !std::isfinite(1./((1.-double(SoilCte.Porosity))*DynamicPoreConductivityCk)))
    Run_Exceptioon("GPU variable conductivity exponent scale must be representable.");
  if(PorosityFeedback && ((TKernel!=KERNEL_Wendland && TKernel!=KERNEL_Cubic) || (!DynamicPorePressure && SoilCte.HydraulicConductivity!=0) || (Visco!=0 && !allowartvisco)
    || TVisco!=VISCO_Artificial || TDensity!=DDT_None || (ArtificialStress && !container)
    || (SoilBoundaryDerivativeSPR && !allowcolumnstabilization) || !SoilStressRateGradCorr
    || (PoreShepardRegularization && !(container && HydroMechInitMode==HMINIT_ConstantZ))
    || !(SoilCte.PoreWaterBulkModulus>0) || !(SoilCte.PoreWaterRho>0)
    || !(RhopZero>SoilCte.Porosity*SoilCte.PoreWaterRho)))
    Run_Exceptioon(DynamicPorePressure?
      "GPU porosity feedback requires bounded complete Darcy Wendland/Cubic elastic fixtures; artificial viscosity permits the constant-k column, free body or fixed gravity container; HG/SPR remain column-only, with corrected stress gradients and positive mixture inertia.":
      "GPU porosity feedback requires a private k=0 Wendland/Cubic elastic fixture without viscosity/DDT/artificial stress/SPR/Shepard, with corrected stress gradients and positive mixture inertia.");
  if(PorosityFeedback && (CaseNfloat || (!DynamicPoreWall && !freebody && (!PeriX || !PeriZ))
    || !std::isfinite(SoilCte.PoreWaterBulkModulus) || !std::isfinite(SoilCte.PoreWaterRho)
    || !std::isfinite(RhopZero) || !std::isfinite(MassFluid) || !(MassFluid>0)
    || !std::isfinite(SoilCte.ModulusK) || !(SoilCte.ModulusK>0)
    || !std::isfinite(SoilCte.ModulusG) || SoilCte.ModulusG<0
    || !std::isfinite(KernelH) || !(KernelH>0) || !std::isfinite(CFLnumber) || !(CFLnumber>0)
    || !std::isfinite(DtMin) || DtMin<0))
    Run_Exceptioon("GPU porosity feedback requires finite saturated elastic material and step parameters, with supported walls/periodicity or an admitted free body and no floating particles.");
  const bool conductivitymodelok=(HydroMechDynamicSeepage?
    (HydroMechConductivityModel==unsigned(DynamicPoreConductivity)
      && (!DynamicPoreConductivity || DynamicPoreConductivityCk==HydroMechConductivityCk)):
    HydroMechConductivityModel==0);
  if(DynamicPorePressure && (!std::isfinite(SoilCte.HydraulicConductivity) || SoilCte.HydraulicConductivity<0
    || !conductivitymodelok || !std::isfinite(PoreDtSafety) || !(PoreDtSafety>0)
    || PeriXinc.y!=0 || PeriXinc.z!=0 || PeriZinc.x!=0 || PeriZinc.y!=0
    || (!freebody && (!DynamicPoreWall || PeriX) && (!std::isfinite(PeriXinc.x) || PeriXinc.x==0))
    || (!freebody && (!DynamicPoreWall || PeriZ) && (!std::isfinite(PeriZinc.z) || PeriZinc.z==0))))
    Run_Exceptioon("GPU dynamic pore pressure requires finite k0>=0, consistent conductivity options and PoreDtSafety>0, with supported rectangular periodicity/walls or an admitted free body.");
  if(DynamicPorePressure && SoilDamping)Log->Printf("Dynamic soil damping rate: %.9g s^-1 (reference intrinsic solid density)",double(GetDynamicSoilDampingRate()));
  for(unsigned p=0;p<Np;p++){PoroJ[p]=1.;PoroTheta[p]=0.;}
  cudaMemcpy(PoroJg,PoroJ,sizeof(double)*Np,cudaMemcpyHostToDevice);
  cudaMemset(PoroThetag,0,sizeof(double)*Np);
  Check_CudaErroor("Failed initialising GPU porosity observer.");
}

//==============================================================================
/// Advances the shared J state; the observer alone does not feed physical operators.
//==============================================================================
void JSphGpu::ComputeSymplecticPorosity(bool corrector,double dt){
  if(!PorosityObserver)return;
  if(!corrector){
    PoroJPreg=ArraysGpu->ReserveDouble();
    swap(PoroJPreg,PoroJg);
  }
  unsigned invalid=Np;
  unsigned *invalidg=ArraysGpu->ReserveUint();
  cudaMemcpy(invalidg,&invalid,sizeof(unsigned),cudaMemcpyHostToDevice);
  cusph::UpdatePorosityObserver(Np,Npb,corrector,dt,1.-double(SoilCte.Porosity)
    ,Codeg,(corrector && IsDynamicPorePlasticConfig()? NULL: Kplasticg),PoroJPreg,PoroThetag,PoroJg,invalidg);
  cudaMemcpy(&invalid,invalidg,sizeof(unsigned),cudaMemcpyDeviceToHost);
  ArraysGpu->Free(invalidg);
  Check_CudaErroor("Failed advancing GPU porosity observer.");
  if(invalid<Np)Run_Exceptioon("GPU porosity observer requires finite saturated states and elastic or admitted periodic radial material.");
  if(corrector){ArraysGpu->Free(PoroJPreg);PoroJPreg=NULL;}
}

//==============================================================================
/// Necessary k=0 acoustic scale from the current native J; not a stability proof.
//==============================================================================
double JSphGpu::GetPorosityStepWaveGpu(){
  if(!std::isfinite(AceMax) || AceMax<0 || !std::isfinite(VelMax) || VelMax<0
    || !std::isfinite(ViscDtMax) || ViscDtMax<0)
    Run_Exceptioon("GPU porosity step requires finite nonnegative force-stage maxima.");
  double cu2max=0;
  unsigned invalid=Np;
  double *cu2g=ArraysGpu->ReserveDouble();
  unsigned *invalidg=ArraysGpu->ReserveUint();
  cudaMemset(cu2g,0,sizeof(double));
  cudaMemcpy(invalidg,&invalid,sizeof(unsigned),cudaMemcpyHostToDevice);
  const double m=double(SoilCte.ModulusK)+4.*double(SoilCte.ModulusG)/3.;
  cusph::ComputePorosityWaveSpeed2(Np,Npb,1.-double(SoilCte.Porosity),double(RhopZero)
    ,double(SoilCte.PoreWaterRho),m,double(SoilCte.PoreWaterBulkModulus),Codeg,PoroJg,cu2g,invalidg);
  cudaMemcpy(&cu2max,cu2g,sizeof(double),cudaMemcpyDeviceToHost);
  cudaMemcpy(&invalid,invalidg,sizeof(unsigned),cudaMemcpyDeviceToHost);
  ArraysGpu->Free(cu2g);
  ArraysGpu->Free(invalidg);
  Check_CudaErroor("Failed computing GPU porosity acoustic scale.");
  if(invalid<Np || !std::isfinite(cu2max) || !(cu2max>0))
    Run_Exceptioon("GPU porosity step requires finite saturated native J, porosity and mixture inertia.");
  return(double(KernelH)/(max(sqrt(cu2max),VelMax*10.)+double(KernelH)*ViscDtMax));
}

//==============================================================================
/// Builds a force-stage owner map and extends the newly computed native C.
//==============================================================================
unsigned* JSphGpu::PrepareDynamicPorePeriodicGpu(){
  if(!DynamicPorePressure || !PeriActive)return(NULL);
  if(CaseNp>GpuParticlesSize)Run_Exceptioon("GPU dynamic owner map exceeds its allocated capacity.");
  unsigned *ridpg=NULL,*invalidg=NULL;
  unsigned invalid=Np;
  try{
    ridpg=ArraysGpu->ReserveUint();invalidg=ArraysGpu->ReserveUint();
    cudaMemcpy(invalidg,&invalid,sizeof(unsigned),cudaMemcpyHostToDevice);
    cusph::CalcRidp(true,Np-Npb,Npb,CaseNpb,CaseNp,Codeg,Idpg,ridpg);
    cusph::ExtendDynamicPorePeriodic(Np,Npb,CaseNpb,CaseNp,Codeg,Idpg,ridpg,CorrMatg,NULL,NULL,NULL,invalidg
      ,IsHydroMechDrainageActive()? PorePressg: NULL);
    cudaMemcpy(&invalid,invalidg,sizeof(unsigned),cudaMemcpyDeviceToHost);
    Check_CudaErroor("Failed extending GPU dynamic periodic matrices.");
    if(invalid<Np)Run_Exceptioon("GPU dynamic periodic copy has no valid normal-fluid native owner.");
  }
  catch(...){if(invalidg)ArraysGpu->Free(invalidg);if(ridpg)ArraysGpu->Free(ridpg);throw;}
  ArraysGpu->Free(invalidg);
  return(ridpg);
}

//==============================================================================
/// Replaces the complete rate after all force contributions; consumes ridpg.
//==============================================================================
void JSphGpu::ComputeDynamicPorePressureRateGpu(unsigned *ridpg){
  DynamicConductivitySpeedMax=0.;
  if(!DynamicPorePressure){if(ridpg)ArraysGpu->Free(ridpg);return;}
  unsigned *invalidg=NULL;
  double *maxspeedg=NULL,maxspeed=0.;
  unsigned invalid=Np;
#ifdef C08_STAGE_TRACE
  bool c08tracerhs=false;
#endif
  try{
    invalidg=ArraysGpu->ReserveUint();
    if(DynamicPoreConductivity && SoilCte.HydraulicConductivity>0){maxspeedg=ArraysGpu->ReserveDouble();cudaMemset(maxspeedg,0,sizeof(double));}
    cudaMemcpy(invalidg,&invalid,sizeof(unsigned),cudaMemcpyHostToDevice);
    if(ridpg)cusph::ExtendDynamicPorePeriodic(Np,Npb,CaseNpb,CaseNp,Codeg,Idpg,ridpg,NULL,Aceg,PoroThetag,NULL,invalidg);
    if(DynamicPoreWall)ComputeDynamicPoreWallAccelerationGpu(invalidg);
    const double rhow=SoilCte.PoreWaterRho,gamma=rhow*9.80665;
#ifdef C08_STAGE_TRACE
#ifdef C08_CAUSAL_TRACE
    c08tracerhs=C08TraceBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,0.,C08_TRACE_RHS,Idpg,FSTypeg,PorePressRateg,Rsigmag);
#else
    c08tracerhs=C08TraceBegin(unsigned(Nstep),TimeStep,unsigned(InterStep),SymplecticDtPre,0.,C08_TRACE_RHS,Idpg,FSTypeg,PorePressRateg);
#endif
#endif
    cusph::ComputeDynamicPorePressureRate(Np,Npb,DivData,Dcellg,Posxyg,Poszg,Codeg,CorrMatg,Aceg
      ,PoroJg,PoroThetag,PorePressg,PorePressRateg,1.-double(SoilCte.Porosity),double(SoilCte.PoreWaterBulkModulus)
      ,rhow,double(SoilCte.HydraulicConductivity),gamma,double(MassFluid)/double(RhopZero),invalidg
      ,DynamicPoreConductivity,DynamicPoreConductivityCk,maxspeedg,DynamicPoreWall,BoundModeg
      ,FSTypeg,FSNormalg,IsHydroMechDrainageActive(),HydroMechDrainage && !IsHydroMechDrainageActive(),HydroMechTopLoadMode
      ,DynamicPoreBodyCentre,(DynamicPoreFreeBody? DynamicPoreBodyRadius2: 0.),TKernel,HydroMechFreeSeepage);
    if(ridpg)cusph::ExtendDynamicPorePeriodic(Np,Npb,CaseNpb,CaseNp,Codeg,Idpg,ridpg,NULL,NULL,NULL,PorePressRateg,invalidg);
    cudaMemcpy(&invalid,invalidg,sizeof(unsigned),cudaMemcpyDeviceToHost);
    if(maxspeedg)cudaMemcpy(&maxspeed,maxspeedg,sizeof(double),cudaMemcpyDeviceToHost);
  }
  catch(...){if(maxspeedg)ArraysGpu->Free(maxspeedg);if(invalidg)ArraysGpu->Free(invalidg);if(ridpg)ArraysGpu->Free(ridpg);throw;}
  if(maxspeedg)ArraysGpu->Free(maxspeedg);
  ArraysGpu->Free(invalidg);
  if(ridpg)ArraysGpu->Free(ridpg);
  Check_CudaErroor("Failed computing GPU dynamic pore-pressure rate.");
  if(invalid<Np)Run_Exceptioon(DynamicPoreFreeBody?
    "GPU dynamic free body lost its inactive-DBC separation envelope or produced an invalid Darcy rate.":
    "GPU dynamic pore pressure requires valid periodic owners and finite saturated pressure rates.");
  if(!std::isfinite(maxspeed) || maxspeed<0)Run_Exceptioon("GPU dynamic conductivity-gradient speed must remain finite and nonnegative.");
  DynamicConductivitySpeedMax=maxspeed;
#ifdef C08_STAGE_TRACE
  C08TraceEnd(c08tracerhs,DirOut); //-Existing CUDA/physical-rate guards have already passed.
#endif
}

//==============================================================================
/// Same-stage acoustic/diffusion necessary bounds and positive-k decay domain.
//==============================================================================
void JSphGpu::GetDynamicStepScalesGpu(double &wave,double &pore){
  if(!std::isfinite(AceMax) || AceMax<0 || !std::isfinite(VelMax) || VelMax<0
    || !std::isfinite(ViscDtMax) || ViscDtMax<0 || !std::isfinite(PoreDtSafety) || !(PoreDtSafety>0)
    || GpuParticlesSize<2)
    Run_Exceptioon("GPU dynamic step requires finite force maxima, positive pore safety and reduction capacity.");
  double values[2]={0,0};
  unsigned invalid=Np;
  double *maxg=ArraysGpu->ReserveDouble(); //-Two scalars in a full particle-capacity array.
  unsigned *invalidg=ArraysGpu->ReserveUint();
  cudaMemset(maxg,0,sizeof(values));
  cudaMemcpy(invalidg,&invalid,sizeof(unsigned),cudaMemcpyHostToDevice);
  const double m=double(SoilCte.ModulusK)+4.*double(SoilCte.ModulusG)/3.;
  const double gamma=double(SoilCte.PoreWaterRho)*9.80665;
  cusph::ComputePorosityWaveSpeed2(Np,Npb,1.-double(SoilCte.Porosity),double(RhopZero)
    ,double(SoilCte.PoreWaterRho),m,double(SoilCte.PoreWaterBulkModulus),Codeg,PoroJg,maxg,invalidg
    ,double(SoilCte.HydraulicConductivity),gamma,maxg+1,DynamicPoreConductivity,DynamicPoreConductivityCk);
  cudaMemcpy(values,maxg,sizeof(values),cudaMemcpyDeviceToHost);
  cudaMemcpy(&invalid,invalidg,sizeof(unsigned),cudaMemcpyDeviceToHost);
  ArraysGpu->Free(maxg);ArraysGpu->Free(invalidg);
  Check_CudaErroor("Failed computing GPU dynamic step scales.");
  if(invalid<Np || !std::isfinite(values[0]) || !(values[0]>0) || !std::isfinite(values[1]) || values[1]<0)
    Run_Exceptioon("GPU dynamic step requires finite saturated native states and a strict positive-k continuous decay domain; reducing dt cannot repair a domain failure.");
  wave=double(KernelH)/(max(sqrt(values[0]),VelMax*10.)+double(KernelH)*ViscDtMax);
  pore=(values[1]>0? double(PoreDtSafety)*double(KernelH)*KernelH/values[1]: DBL_MAX);
}

//==============================================================================
/// Computes the variable Dt.
/// Calcula un Dt variable.
//==============================================================================
double JSphGpu::DtVariable(bool final){
  //-dt1 depends on force per unit mass.
  const double acemax=sqrt(double(AceMax));
  const double dt1=(AceMax? (sqrt(double(KernelH)/AceMax)): DBL_MAX); 
  //-dt2 combines the Courant and the viscous time-step controls.
  double dt2=double(KernelH)/(max(Cs0,VelMax*10.)+double(KernelH)*ViscDtMax);
  if(PorosityFeedback && !DynamicPorePressure)dt2=GetPorosityStepWaveGpu();
  //-dtw limits the explicit pore-pressure diffusion update in u-pw PR formulation.
  double dtw=DBL_MAX;
  if(DynamicPorePressure){
    GetDynamicStepScalesGpu(dt2,dtw);
    //-Additional same-stage necessary scale, not a variable-coefficient stability proof.
    if(DynamicPoreConductivity && DynamicConductivitySpeedMax>0)
      dtw=min(dtw,double(PoreDtSafety)*double(KernelH)/DynamicConductivitySpeedMax);
  }
  else if(HydroMech && SoilCte.HydraulicConductivity>0.f){
    const double gnorm=sqrt(double(Gravity.x)*Gravity.x+double(Gravity.y)*Gravity.y+double(Gravity.z)*Gravity.z);
    const double ghyd=(gnorm>0? gnorm: 9.80665);
    const double kwn=double(SoilCte.PoreWaterBulkModulus)/double(SoilCte.Porosity);
    const double cw=double(SoilCte.PoreWaterRho)*ghyd/kwn;
    dtw=double(PoreDtSafety)*cw*double(KernelH)*double(KernelH)/double(SoilCte.HydraulicConductivity);
  }
  //-dt new value of time step.
  double dt=CFLnumber*min(dt1,dt2);
  if(PorosityFeedback){
    //-Reject the already locked step before either Pre or Corr; never clip it.
    const double bound=min(dt,dtw);
    if(!std::isfinite(bound) || !(bound>0) || !std::isfinite(SymplecticDtPre) || !(SymplecticDtPre>0)
      || double(DtMin)>bound || SymplecticDtPre>bound)
      Run_Exceptioon(fun::PrintStr("GPU porosity current step or DtMin exceeds its necessary bound: step=%u current=%.17g bound=%.17g DtMin=%.17g; final=%u force=%.17g wave_visc=%.17g pore=%.17g k_gradient=%.17g AceMax=%.17g VelMax=%.17g ViscDtMax=%.17g conductivity_speed=%.17g.",Nstep,SymplecticDtPre,bound,DtMin,unsigned(final),CFLnumber*dt1,CFLnumber*dt2,dtw,(DynamicPoreConductivity && DynamicConductivitySpeedMax>0? double(PoreDtSafety)*double(KernelH)/DynamicConductivitySpeedMax: DBL_MAX),AceMax,VelMax,ViscDtMax,DynamicConductivitySpeedMax));
    dt=(FixedDt? FixedDt->GetDt(TimeStep,bound): bound);
    if(!std::isfinite(dt) || !(dt>0) || dt>bound || dt<double(DtMin))
      Run_Exceptioon(fun::PrintStr("GPU porosity requested step=%g is outside bound=%g or DtMin=%g; no clipping or DtMin uplift is allowed.",dt,bound,DtMin));
  }
  else{
    if(FixedDt)dt=FixedDt->GetDt(TimeStep,dt);
    else dt=min(dt,dtw);
  }
  if(fun::IsNAN(dt) || fun::IsInfinity(dt))Run_Exceptioon(fun::PrintStr("The computed Dt=%f (from AceMax=%f, VelMax=%f, ViscDtMax=%f) is NaN or infinity at nstep=%u.",dt,AceMax,VelMax,ViscDtMax,Nstep));
  if(dt<double(DtMin)){ 
    dt=double(DtMin); DtModif++;
    if(DtModif>=DtModifWrn){
      Log->PrintfWarning("%d DTs adjusted to DtMin (t:%g, nstep:%u)",DtModif,TimeStep,Nstep);
      DtModifWrn*=10;
    }
  }
  //-Saves information about dt.
  if(final){
    if(PartDtMin>dt)PartDtMin=dt;
    if(PartDtMax<dt)PartDtMax=dt;
    //-Saves detailed information about dt in SaveDt object.
    if(SaveDt)SaveDt->AddValues(TimeStep,dt,dt1*CFLnumber,min(dt2*CFLnumber,dtw),AceMax,ViscDtMax,VelMax);
  }
  return(dt);
}

//==============================================================================
/// Computes final shifting distance for the particle position.
/// Calcula Shifting final para posicion de particulas.
//==============================================================================
void JSphGpu::RunShifting(double dt){
  Timersg->TmStart(TMG_SuShifting,false);
  Shifting->RunGpu(Np-Npb,Npb,dt,Velrhopg,ShiftPosfsg);
  Timersg->TmStop(TMG_SuShifting,false);
}

//==============================================================================
/// Calculates predefined movement of boundary particles.
/// Calcula movimiento predefinido de boundary particles.
//==============================================================================
void JSphGpu::CalcMotion(double stepdt){
  Timersg->TmStart(TMG_SuMotion,false);
  JSph::CalcMotion(stepdt);
  Timersg->TmStop(TMG_SuMotion,false);
}

//==============================================================================
/// Processes boundary particle movement.
/// Procesa movimiento de boundary particles.
//==============================================================================
void JSphGpu::RunMotion(double stepdt){
  Timersg->TmStart(TMG_SuMotion,false);
  float3 *boundnormal=NULL;
  boundnormal=BoundNormalg;
  const bool motsim=true;
  BoundChanged=false;
  //-Add motion from automatic wave generation.
  if(WaveGen)CalcMotionWaveGen(stepdt);
  //-Process particles motion.
  if(DsMotion->GetActiveMotion()){
    cusph::CalcRidp(PeriActive!=0,Npb,0,CaseNfixed,CaseNfixed+CaseNmoving,Codeg,Idpg,RidpMoveg);
    BoundChanged=true;
    const unsigned nref=DsMotion->GetNumObjects();
    for(unsigned ref=0;ref<nref;ref++){
      const StMotionData& m=DsMotion->GetMotionData(ref);
      if(m.type==MOTT_Linear){//-Linear movement.
        if(motsim)cusph::MoveLinBound   (PeriActive,m.count,m.idbegin-CaseNfixed,m.linmov,ToTFloat3(m.linvel),RidpMoveg,Posxyg,Poszg,Dcellg,Velrhopg,Codeg);
        //else    cusph::MoveLinBoundAce(PeriActive,m.count,m.idbegin-CaseNfixed,m.linmov,ToTFloat3(m.linvel),ToTFloat3(m.linace),RidpMoveg,Posxyg,Poszg,Dcellg,Velrhopg,Codeg);
      }
      if(m.type==MOTT_Matrix){//-Matrix movement (for rotations).
        if(motsim)cusph::MoveMatBound   (PeriActive,Simulate2D,m.count,m.idbegin-CaseNfixed,m.matmov,stepdt,RidpMoveg,Posxyg,Poszg,Dcellg,Velrhopg,Codeg,boundnormal);
        //else    cusph::MoveMatBoundAce(PeriActive,Simulate2D,m.count,m.idbegin-CaseNfixed,m.matmov,m.matmov2,stepdt,RidpMoveg,Posxyg,Poszg,Dcellg,Velrhopg,Codeg);
      }      
    }
  }
  //-Management of Multi-Layer Pistons.
  if(MLPistons){
    if(!BoundChanged)cusph::CalcRidp(PeriActive!=0,Npb,0,CaseNfixed,CaseNfixed+CaseNmoving,Codeg,Idpg,RidpMoveg);
    BoundChanged=true;
    if(MLPistons->GetPiston1dCount()){//-Process motion for pistons 1D.
      MLPistons->CalculateMotion1d(TimeStep+MLPistons->GetTimeMod()+stepdt);
      cusph::MovePiston1d(PeriActive!=0,CaseNmoving,0,Dp,MLPistons->GetPoszMin(),MLPistons->GetPoszCount(),MLPistons->GetPistonIdGpu(),MLPistons->GetMovxGpu(),MLPistons->GetVelxGpu(),RidpMoveg,Posxyg,Poszg,Dcellg,Velrhopg,Codeg);
    }
    for(unsigned cp=0;cp<MLPistons->GetPiston2dCount();cp++){//-Process motion for pistons 2D.
      JMLPistons::StMotionInfoPiston2D mot=MLPistons->CalculateMotion2d(cp,TimeStep+MLPistons->GetTimeMod()+stepdt);
      cusph::MovePiston2d(PeriActive!=0,mot.np,mot.idbegin-CaseNfixed,Dp,mot.posymin,mot.poszmin,mot.poszcount,mot.movyz,mot.velyz,RidpMoveg,Posxyg,Poszg,Dcellg,Velrhopg,Codeg);
    }
  }
  if(MotionVelg)cusph::CopyMotionVel(CaseNmoving,RidpMoveg,Velrhopg,MotionVelg);
  Timersg->TmStop(TMG_SuMotion,false);
}

//==============================================================================
/// Applies RelaxZone to selected particles.
/// Aplica RelaxZone a las particulas indicadas.
//==============================================================================
void JSphGpu::RunRelaxZone(double dt){
  Timersg->TmStart(TMG_SuMotion,false);
  byte* rzid=NULL; 
  float* rzfactor=NULL; 
  RelaxZones->SetFluidVelGpu(TimeStep,dt,Np-Npb,Npb,(const tdouble2*)Posxyg
    ,Poszg,Idpg,(tfloat4*)Velrhopg,rzid,rzfactor);
  Timersg->TmStop(TMG_SuMotion,false);
}

//==============================================================================
/// Applies Damping to indicated particles.
/// Aplica Damping a las particulas indicadas.
//==============================================================================
void JSphGpu::RunDamping(double dt,unsigned np,unsigned npb,const double2 *posxy
  ,const double *posz,const typecode *code,float4 *velrhop)
{
  const typecode *codeptr=(CaseNfloat || PeriActive? code: NULL);
  Damping->ComputeDampingGpu(TimeStep,dt,np-npb,npb,posxy,posz,codeptr,velrhop);
}

//==============================================================================
/// Save VTK file with particle data (debug).
/// Graba fichero VTK con datos de las particulas (debug).
//==============================================================================
void JSphGpu::SaveVtkNormalsGpu(std::string filename,int numfile,unsigned np,unsigned npb
  ,const double2 *posxyg,const double *poszg,const unsigned *idpg,const float3 *boundnormalg)
{
  //-Allocates memory.
  const unsigned n=(UseNormalsFt? np: npb);
  tdouble3 *pos=fcuda::ToHostPosd3(0,n,posxyg,poszg);
  unsigned *idp=fcuda::ToHostUint(0,n,idpg);
  tfloat3  *nor=fcuda::ToHostFloat3(0,n,boundnormalg);
  //-Generates VTK file.
  SaveVtkNormals(filename,numfile,np,npb,pos,idp,nor,1.f);
  //-Frees memory.
  delete[] pos;
  delete[] idp;
  delete[] nor;
}

//==============================================================================
/// Saves VTK file with particle data (degug).
/// Graba fichero VTK con datos de las particulas (degug).
//==============================================================================
void JSphGpu::DgSaveVtkParticlesGpu(std::string filename,int numfile,unsigned pini,unsigned pfin
 ,const double2 *posxyg,const double *poszg,const typecode *codeg,const unsigned *idpg
 ,const float4 *velrhopg)const
{
  const unsigned np=pfin-pini;
  //-Copy data to CPU memory.
  tdouble3 *posh=fcuda::ToHostPosd3(pini,np,posxyg,poszg);
  #ifdef CODE_SIZE4
    typecode *codeh=fcuda::ToHostUint(pini,np,codeg);
  #else
    typecode *codeh=fcuda::ToHostWord(pini,np,codeg);
  #endif
  unsigned *idph=fcuda::ToHostUint(pini,np,idpg);
  tfloat4  *velrhoph=fcuda::ToHostFloat4(pini,np,velrhopg);
  //-Creates VTK file.
  DgSaveVtkParticlesCpu(filename,numfile,0,np,posh,codeh,idph,velrhoph);
  //-Deallocates memory.
  delete[] posh;  
  delete[] codeh;
  delete[] idph;
  delete[] velrhoph;
}

//==============================================================================
/// Saves VTK file with particle data (debug).
/// Graba fichero vtk con datos de las particulas (debug).
//==============================================================================
void JSphGpu::DgSaveVtkParticlesGpu(std::string filename,int numfile,unsigned pini,unsigned pfin,unsigned cellcode
  ,const double2 *posxyg,const double *poszg,const unsigned *idpg,const unsigned *dcelg
  ,const typecode *codeg,const float4 *velrhopg,const float4 *velrhopm1g,const float3 *aceg)
{
  //-Allocates memory.
  const unsigned n=pfin-pini;
  //-Loads position.
  tfloat3 *pos=new tfloat3[n];
  {
    tdouble2 *pxy=new tdouble2[n];
    double *pz=new double[n];
    cudaMemcpy(pxy,posxyg+pini,sizeof(double2)*n,cudaMemcpyDeviceToHost);
    cudaMemcpy(pz,poszg+pini,sizeof(double)*n,cudaMemcpyDeviceToHost);
    for(unsigned p=0;p<n;p++)pos[p]=TFloat3(float(pxy[p].x),float(pxy[p].y),float(pz[p]));
    delete[] pxy;
    delete[] pz;
  }
  //-Loads idp.
  unsigned *idp=NULL;
  if(idpg){
    idp=new unsigned[n];
    cudaMemcpy(idp,idpg+pini,sizeof(unsigned)*n,cudaMemcpyDeviceToHost);
  }
  //-Loads dcel.
  tuint3 *dcel=NULL;
  if(dcelg){
    dcel=new tuint3[n];
    unsigned *aux=new unsigned[n];
    cudaMemcpy(aux,dcelg+pini,sizeof(unsigned)*n,cudaMemcpyDeviceToHost);
    for(unsigned p=0;p<n;p++)dcel[p]=TUint3(unsigned(DCEL_Cellx(cellcode,aux[p])),unsigned(DCEL_Celly(cellcode,aux[p])),unsigned(DCEL_Cellz(cellcode,aux[p])));
    delete[] aux;
  }
  //-Loads vel and rhop.
  tfloat3 *vel=NULL;
  float *rhop=NULL;
  if(velrhopg){
    vel=new tfloat3[n];
    rhop=new float[n];
    tfloat4 *aux=new tfloat4[n];
    cudaMemcpy(aux,velrhopg+pini,sizeof(float4)*n,cudaMemcpyDeviceToHost);
    for(unsigned p=0;p<n;p++){ vel[p]=TFloat3(aux[p].x,aux[p].y,aux[p].z); rhop[p]=aux[p].w; }
    delete[] aux;
  }
  //-Loads velm1 and rhopm1.
  tfloat3 *velm1=NULL;
  float *rhopm1=NULL;
  if(velrhopm1g){
    velm1=new tfloat3[n];
    rhopm1=new float[n];
    tfloat4 *aux=new tfloat4[n];
    cudaMemcpy(aux,velrhopm1g+pini,sizeof(float4)*n,cudaMemcpyDeviceToHost);
    for(unsigned p=0;p<n;p++){ velm1[p]=TFloat3(aux[p].x,aux[p].y,aux[p].z); rhopm1[p]=aux[p].w; }
    delete[] aux;
  }
  //-Loads ace.
  tfloat3 *ace=NULL;
  if(aceg){
    ace=new tfloat3[n];
    cudaMemcpy(ace,aceg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  }
  //-Loads type.
  byte *type=NULL;
  if(codeg){
    type=new byte[n];
    typecode *aux=new typecode[n];
    cudaMemcpy(aux,codeg+pini,sizeof(typecode)*n,cudaMemcpyDeviceToHost);
    for(unsigned p=0;p<n;p++){ 
      const typecode cod=aux[p];
      byte tp=99;
      if(CODE_IsFixed(cod))tp=0;
      else if(CODE_IsMoving(cod))tp=1;
      else if(CODE_IsFloating(cod))tp=2;
      else if(CODE_IsFluid(cod))tp=3;
      if(CODE_IsNormal(cod))tp+=0;
      else if(CODE_IsPeriodic(cod))tp+=10;
      else if(CODE_IsOutIgnore(cod))tp+=20;
      else tp+=30;
      type[p]=tp;
    }
    delete[] aux;
  }
  //-Saves VTK file.
  JDataArrays arrays;
  arrays.AddArray("Pos",n,pos,true);
  if(idp)   arrays.AddArray("Idp"   ,n,idp   ,true);
  if(dcel)  arrays.AddArray("Dcel"  ,n,dcel  ,true);
  if(vel)   arrays.AddArray("Vel"   ,n,vel   ,true);
  if(rhop)  arrays.AddArray("Rhop"  ,n,rhop  ,true);
  if(velm1) arrays.AddArray("Velm1" ,n,velm1 ,true);
  if(rhopm1)arrays.AddArray("Rhopm1",n,rhopm1,true);
  if(ace)   arrays.AddArray("Ace"   ,n,ace   ,true);
  if(type)  arrays.AddArray("Typex" ,n,type  ,true);
  JVtkLib::SaveVtkData(fun::FileNameSec(filename,numfile),arrays,"Pos");
  arrays.Reset();
}

//==============================================================================
/// Save VTK file with particle data (debug).
/// Graba fichero VTK con datos de las particulas (debug).
//==============================================================================
void JSphGpu::DgSaveVtkParticlesGpu(std::string filename,int numfile,unsigned pini,unsigned pfin,bool idp,bool vel,bool rhop,bool code)
{
  if(numfile>=0)filename=fun::FileNameSec(filename,numfile);
  if(Log->GetMpiRank()>=0)filename=string("p")+fun::IntStr(Log->GetMpiRank())+"_"+filename;
  filename=DirDataOut+filename;
  //-Allocates memory.
  const unsigned n=pfin-pini;
  ParticlesDataDown(n,pini,code,false);
  tfloat3 *pos=new tfloat3[n];
  for(unsigned p=0;p<n;p++)pos[p]=ToTFloat3(AuxPos[p]);
  byte *type=new byte[n];
  for(unsigned p=0;p<n;p++){
    const typecode cod=Code[p];
    byte tp=99;
    if(CODE_IsFixed(cod))tp=0;
    else if(CODE_IsMoving(cod))tp=1;
    else if(CODE_IsFloating(cod))tp=2;
    else if(CODE_IsFluid(cod))tp=3;
    if(CODE_IsNormal(cod))tp+=0;
    else if(CODE_IsPeriodic(cod))tp+=10;
    else if(CODE_IsOutIgnore(cod))tp+=20;
    else tp+=30;
    type[p]=tp;
  }
  //-Saves VTK file.
  JDataArrays arrays;
  arrays.AddArray("Pos",n,pos,true);
  if(idp) arrays.AddArray("Idp"  ,n,Idp    ,false);
  if(type)arrays.AddArray("Typex",n,type   ,true);
  if(vel) arrays.AddArray("Vel"  ,n,AuxVel ,false);
  if(rhop)arrays.AddArray("Rhop" ,n,AuxRhop,false);
#ifdef CODE_SIZE4
  if(code)arrays.AddArray("Code" ,n,(unsigned*)Code,false);
#else
  if(code)arrays.AddArray("Code" ,n,(word*)    Code,false);
#endif
  JVtkLib::SaveVtkData(filename,arrays,"Pos");
  arrays.Reset();
}

//==============================================================================
/// Save VTK file with particle data (debug).
/// Graba fichero VTK con datos de las particulas (debug).
//==============================================================================
void JSphGpu::DgSaveVtkParticlesGpu(std::string filename,int numfile,unsigned pini,unsigned pfin,const float3 *posg,const byte *checkg,const unsigned *idpg,const float3 *velg,const float *rhopg){
  //-Allocates memory.
  const unsigned n=pfin-pini;
  tfloat3 *pos=new tfloat3[n];
  byte *check=NULL;
  unsigned *idp=NULL;
  tfloat3 *vel=NULL;
  float *rhop=NULL;
  if(checkg)check=new byte[n];
  if(idpg)idp=new unsigned[n];
  if(velg)vel=new tfloat3[n];
  if(rhopg)rhop=new float[n];
  //-Copies data from GPU.
  cudaMemcpy(pos,posg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  if(checkg)cudaMemcpy(check,checkg+pini,sizeof(byte)*n,cudaMemcpyDeviceToHost);
  if(idpg)cudaMemcpy(idp,idpg+pini,sizeof(unsigned)*n,cudaMemcpyDeviceToHost);
  if(velg)cudaMemcpy(vel,velg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  if(rhopg)cudaMemcpy(rhop,rhopg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  //-Generates VTK file.
  DgSaveVtkParticlesCpu(filename,numfile,0,n,pos,check,idp,vel,rhop);
  //-Frees memory.
  delete[] pos;
  delete[] check;
  delete[] idp;
  delete[] vel;
  delete[] rhop;
}

//==============================================================================
/// Save CSV file with particle data (debug).
/// Graba fichero CSV con datos de las particulas (debug).
//==============================================================================
void JSphGpu::DgSaveCsvParticlesGpu(std::string filename,int numfile,unsigned pini,unsigned pfin,std::string head,const float3 *posg,const unsigned *idpg,const float3 *velg,const float *rhopg,const float *arg,const float3 *aceg,const float3 *vcorrg){
  //-Allocates memory.
  const unsigned n=pfin-pini;
  unsigned *idp=NULL;  if(idpg)idp=new unsigned[n];
  tfloat3 *pos=NULL;   if(posg)pos=new tfloat3[n];
  tfloat3 *vel=NULL;   if(velg)vel=new tfloat3[n];
  float *rhop=NULL;    if(rhopg)rhop=new float[n];
  float *ar=NULL;      if(arg)ar=new float[n];
  tfloat3 *ace=NULL;   if(aceg)ace=new tfloat3[n];
  tfloat3 *vcorr=NULL; if(vcorrg)vcorr=new tfloat3[n];
  //-Copies data from GPU.
  if(idpg)cudaMemcpy(idp,idpg+pini,sizeof(unsigned)*n,cudaMemcpyDeviceToHost);
  if(posg)cudaMemcpy(pos,posg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  if(velg)cudaMemcpy(vel,velg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  if(rhopg)cudaMemcpy(rhop,rhopg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  if(arg)cudaMemcpy(ar,arg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  if(aceg)cudaMemcpy(ace,aceg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  if(vcorrg)cudaMemcpy(vcorr,vcorrg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  Check_CudaErroor("Failed copying data from GPU.");
  //-Generates CSV file.
  DgSaveCsvParticlesCpu(filename,numfile,0,n,head,pos,idp,vel,rhop,ar,ace,vcorr);
  //-Frees memory.
  delete[] idp;
  delete[] pos;
  delete[] vel;
  delete[] rhop;
  delete[] ar;
  delete[] ace;
  delete[] vcorr;
}

//==============================================================================
/// Save CSV file with particle data (debug).
/// Graba fichero CSV con datos de las particulas (debug).
//==============================================================================
void JSphGpu::DgSaveCsvParticlesGpu2(std::string filename,int numfile,unsigned pini,unsigned pfin,std::string head,const float3 *posg,const unsigned *idpg,const float3 *velg,const float *rhopg,const float4 *pospresg,const float4 *velrhopg){
  //-Allocates memory.
  const unsigned n=pfin-pini;
  unsigned *idp=NULL;  if(idpg)idp=new unsigned[n];
  tfloat3 *pos=NULL;   if(posg)pos=new tfloat3[n];
  tfloat3 *vel=NULL;   if(velg)vel=new tfloat3[n];
  float *rhop=NULL;    if(rhopg)rhop=new float[n];
  tfloat4 *pospres=NULL;  if(pospresg)pospres=new tfloat4[n];
  tfloat4 *velrhop=NULL;  if(velrhopg)velrhop=new tfloat4[n];
  //-Copies data from GPU.
  if(idpg)cudaMemcpy(idp,idpg+pini,sizeof(unsigned)*n,cudaMemcpyDeviceToHost);
  if(posg)cudaMemcpy(pos,posg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  if(velg)cudaMemcpy(vel,velg+pini,sizeof(float3)*n,cudaMemcpyDeviceToHost);
  if(rhopg)cudaMemcpy(rhop,rhopg+pini,sizeof(float)*n,cudaMemcpyDeviceToHost);
  if(pospresg)cudaMemcpy(pospres,pospresg+pini,sizeof(float4)*n,cudaMemcpyDeviceToHost);
  if(velrhopg)cudaMemcpy(velrhop,velrhopg+pini,sizeof(float4)*n,cudaMemcpyDeviceToHost);
  Check_CudaErroor("Failed copying data from GPU.");
  //-Generates CSV file.
  DgSaveCsvParticles2(filename,numfile,0,n,head,pos,idp,vel,rhop,pospres,velrhop);
  //-Frees memory.
  delete[] idp;
  delete[] pos;
  delete[] vel;
  delete[] rhop;
  delete[] pospres;
  delete[] velrhop;
}

//==============================================================================
/// Save CSV file with particle data (debug).
/// Graba fichero CSV con datos de las particulas (debug).
//==============================================================================
void JSphGpu::DgSaveCsvParticles2(std::string filename,int numfile,unsigned pini,unsigned pfin,std::string head,const tfloat3 *pos,const unsigned *idp,const tfloat3 *vel,const float *rhop,const tfloat4 *pospres,const tfloat4 *velrhop){
  int mpirank=Log->GetMpiRank();
  if(mpirank>=0)filename=string("p")+fun::IntStr(mpirank)+"_"+filename;
  if(numfile>=0)filename=fun::FileNameSec(filename,numfile);
  filename=DirDataOut+filename;
  //-Generates CSV file.
  ofstream pf;
  pf.open(filename.c_str());
  if(pf){
    if(!head.empty())pf << head << endl;
    pf << "Num";
    if(idp)pf << ";Idp";
    if(pos)pf << ";PosX;PosY;PosZ";
    if(vel)pf << ";VelX;VelY;VelZ";
    if(rhop)pf << ";Rhop";
    if(pospres)pf << ";Px;Py;Pz;Pp";
    if(velrhop)pf << ";Vx;Vy;Vz;Vr";
    pf << endl;
    const char fmt1[]="%f"; //="%24.16f";
    const char fmt3[]="%f;%f;%f"; //="%24.16f;%24.16f;%24.16f";
    for(unsigned p=pini;p<pfin;p++){
      pf << fun::UintStr(p-pini);
      if(idp)pf << ";" << fun::UintStr(idp[p]);
      if(pos)pf << ";" << fun::Float3Str(pos[p],fmt3);
      if(vel)pf << ";" << fun::Float3Str(vel[p],fmt3);
      if(rhop)pf << ";" << fun::FloatStr(rhop[p],fmt1);
      if(pospres)pf << ";" <<  fun::FloatStr(pospres[p].x,fmt1) << ";" << fun::FloatStr(pospres[p].y,fmt1) << ";" << fun::FloatStr(pospres[p].z,fmt1) << ";" << fun::FloatStr(pospres[p].w,fmt1);
      if(velrhop)pf << ";" <<  fun::FloatStr(velrhop[p].x,fmt1) << ";" << fun::FloatStr(velrhop[p].y,fmt1) << ";" << fun::FloatStr(velrhop[p].z,fmt1) << ";" << fun::FloatStr(velrhop[p].w,fmt1);
      pf << endl;
    }
    if(pf.fail())Run_ExceptioonFile("Failed writing to file.",filename);
    pf.close();
  }
  else Run_ExceptioonFile("File could not be opened.",filename);
}


